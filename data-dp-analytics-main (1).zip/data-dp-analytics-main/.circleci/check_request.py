"""
Poll check. Runs on every scheduled pipeline, must stay cheap.

Reads the control cells on the remittance sheet. If a run has been
requested, claims it (so a later poll does not pick it up again) and
writes /tmp/run_request.json for main.py. If nothing is pending, exits
without creating /tmp/proceed, and the CircleCI step halts the job.

Control cells on the CONTROL_TAB:
  B2  run date, set by the person clicking the button
  B4  status: REQUESTED | RUNNING | DONE | FAILED | (blank)
  B5  email of whoever requested it
  B6  timestamp the request or claim was written
"""

import os
import json
import base64
import datetime

import pygsheets

SHEET_KEY   = "1RLULkU7f_0Wy-6ISh-a4ICXVnS1txBwcfxaULtp1qA0"        # remittance emails sheet;- same as main.py
CONTROL_TAB = "Remittance Date"

CELL_DATE   = "B2"
CELL_STATUS = "B4"
CELL_WHO    = "B5"
CELL_TIME   = "B6"

SA_PATH  = "/tmp/service_account.json"
PROCEED  = "/tmp/proceed"
REQUEST  = "/tmp/run_request.json"

# A claim older than this is treated as an abandoned run.
STALE_CLAIM_MINUTES = 15


def now():
    return datetime.datetime.now(datetime.timezone.utc)


def sheets_client():
    raw = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON_B64", "")
    if not raw.strip():
        raise RuntimeError("GOOGLE_SERVICE_ACCOUNT_JSON_B64 is missing or empty")
    with open(SA_PATH, "w") as f:
        f.write(base64.b64decode(raw).decode())
    os.chmod(SA_PATH, 0o600)
    return pygsheets.authorize(service_account_file=SA_PATH)


def parse_stamp(value):
    try:
        return datetime.datetime.fromisoformat(str(value).strip())
    except Exception:
        return None


def main():
    gc = sheets_client()
    ws = gc.open_by_key(SHEET_KEY).worksheet_by_title(CONTROL_TAB)

    status = (ws.get_value(CELL_STATUS) or "").strip().upper()

    if status == "RUNNING":
        claimed = parse_stamp(ws.get_value(CELL_TIME))
        if claimed and (now() - claimed) < datetime.timedelta(minutes=STALE_CLAIM_MINUTES):
            print("A run is already in flight. Nothing to do.")
            return
        print("Found a stale RUNNING claim. Taking it over.")
    elif status != "REQUESTED":
        print(f"No pending request (status: {status or 'blank'}).")
        return

    run_date = str(ws.get_value(CELL_DATE) or "").strip()[:10]
    if not run_date:
        raise RuntimeError("A run was requested but the date cell is empty")

    requested_by = (ws.get_value(CELL_WHO) or "unknown").strip()

    # Claim it before doing anything expensive.
    ws.update_value(CELL_STATUS, "RUNNING")
    ws.update_value(CELL_TIME, now().isoformat(timespec="seconds"))

    with open(REQUEST, "w") as f:
        json.dump({"run_date": run_date, "triggered_by": requested_by}, f)

    open(PROCEED, "w").close()
    print(f"Claimed request: {run_date} for {requested_by}")


if __name__ == "__main__":
    main()
