"""Printing the job folder named in the webhook payload, or the default to ensure restriction of folders to run."""
import json

DEFAULT = "jobs/spresso-remittance"
ALLOWED = {
    "jobs/spresso-remittance",
    "jobs/alto-remittance",
}

try:
    with open("/tmp/trigger.json") as f:
        job_dir = (json.load(f).get("job_dir") or "").strip()
except Exception:
    job_dir = ""

print(job_dir if job_dir in ALLOWED else DEFAULT)
