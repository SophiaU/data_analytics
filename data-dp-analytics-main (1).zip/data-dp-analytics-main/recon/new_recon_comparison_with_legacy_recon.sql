
-----RECON COMPARISON: LEGACY & MART WEEKLY RECON---
WITH
combined AS (
   SELECT
       COALESCE(a.drn, b.drn) AS drn,
       COALESCE(a.week, b.recon_week) AS week,
       a.country AS country_originalrecon,
       b.country AS country_martweeklyrecon,
       a.uber_id AS uber_id_originalrecon,
       b.uber_id AS uber_id_martweeklyrecon,
       NVL(a.effective_days,0.0) AS effective_days_originalrecon,
       NVL(b.effective_days ,0.0)AS effective_days_martweeklyrecon,
       NVL(a.effective_days,0.0)  -  NVL(b.effective_days,0.0) as effective_days_gap,
       NVL(a.days_off,0.0) AS ineffective_days_originalrecon,
       NVL(b.ineffective_days, 0.0) AS ineffective_days_martweeklyrecon,
       NVL(a.days_off,0.0) - NVL(b.ineffective_days, 0.0) as ineffective_days_gap,
       NVL(a.trips, 0.0) AS trips_originalrecon,
       NVL(b.trips, 0.0) AS trips_martweeklyrecon,
       NVL(a.trips, 0.0) - NVL(b.trips, 0.0) as trips_gap,
       NVL(a.supply_hours, 0.0) AS supply_hours_originalrecon,
       NVL(b.supply_hours, 0.0) AS supply_hours_martweeklyrecon,
       NVL(a.supply_hours, 0.0) - NVL(b.supply_hours, 0.0) as supply_hours_gap,
       NVL(a.uber_balance, 0.0) AS uber_balance_originalrecon,
       NVL(b.uber_balance, 0.0) AS uber_balance_martweeklyrecon,
       NVL(a.uber_balance, 0.0) - NVL(b.uber_balance, 0.0) as uber_balance_gap,
       NVL(a.bank_statement, 0.0) AS payins_originalrecon,
       NVL(b.payins, 0.0) AS payins_martweeklyrecon,
       NVL(a.bank_statement, 0.0) - NVL(b.payins, 0.0) as payins_gap,
       NVL(a.adjustment_amount, 0.0) AS adjustment_amount_originalrecon,
       NVL(b.adjustments, 0.0) AS adjustment_amount_martweeklyrecon,
       NVL(a.adjustment_amount, 0.0) + NVL(b.adjustments, 0.0) as adjustment_gap,
       NVL(a.extra_charges, 0.0) AS extracharges_originalrecon,
       (NVL(b.extra_charges,0.0) + NVL(b.passthrough_costs, 0.0)) AS extracharges_martweeklyrecon,   
       NVL(a.extra_charges, 0.0) + (NVL(b.extra_charges,0.0) + NVL(b.passthrough_costs, 0.0)) as extracharges_gap,
      NVL(a.remittance, 0.0) AS remittance_originalrecon,
      NVL( b.driver_remit_for_the_period, 0.0) AS remittance_martweeklyrecon,
       NVL(a.remittance, 0.0) + NVL( b.driver_remit_for_the_period, 0.0) as remittance_gap,
       NVL(a.outstanding, 0.0) AS balance_forthe_period_originalrecon,
       NVL(b.driver_balance_for_the_period, 0.0) AS balance_forthe_period_martweeklyrecon,
       NVL(a.outstanding, 0.0) + NVL(b.driver_balance_for_the_period, 0.0) as balance_forthe_period_gap,
       0 AS security_deposit_credited_from_recon_originalrecon,
       NVL(b.security_deposit_contribution, 0.0) AS security_deposit_credited_from_recon_martweeklyrecon,
       0 - NVL(b.security_deposit_contribution, 0.0) as security_deposit_credited_from_recon_gap,
       NVL(a.payouts, 0.0) AS payouts_originalrecon,
       NVL(b.payouts, 0.0) AS payouts_martweeklyrecon,
       NVL(a.payouts, 0.0) + NVL(b.payouts, 0.0) as payouts_gap,
       NVL(a.prev_outstanding, 0.0) AS opening_balance_originalrecon,
       NVL(b.driver_opening_balance, 0.0) AS opening_balance_martweeklyrecon,
       NVL(a.prev_outstanding, 0.0)  + NVL(b.driver_opening_balance, 0.0) as opening_balance_gap,
       NVL(a.cum_outstanding, 0.0) as closing_balance_originalrecon,
       NVL(b.driver_closing_balance, 0.0) AS closing_balance_martweeklyrecon,
       NVL(a.cum_outstanding, 0.0) + NVL(b.driver_closing_balance, 0.0)  as closing_balance_gap,
       CASE
           WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
           WHEN b.drn IS NULL THEN 'DRN Missing in Mart Weekly Recon'
           WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
           WHEN b.uber_id IS NULL THEN 'UberID Missing in Mart Weekly Recon'
           ELSE 'DRN and UberID Present in all'
       END AS record_status,
       ----Flag rows that have UberID difference
       CASE
           WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
           ELSE 'No'
       END AS has_uberid_difference,
       ----Flag rows that have Opening Balance difference
       CASE
           WHEN ROUND(a.prev_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
           ELSE 'No'
       END AS has_driver_opening_balance_difference,
       ----Flag rows that have Closing Balance difference
       CASE
           WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
           ELSE 'No'
       END AS has_driver_closing_balance_difference,
       ----Flag rows that have any column difference
       CASE
           WHEN a.country IS DISTINCT FROM b.country
             OR a.effective_days IS DISTINCT FROM b.effective_days
             OR a.uber_balance IS DISTINCT FROM b.uber_balance
             OR a.bank_statement IS DISTINCT FROM b.payins
             or a.days_off is distinct from b.ineffective_days
             or a.extra_charges is distinct from (b.extra_charges + b.passthrough_costs)
             OR a.remittance IS DISTINCT FROM b.driver_remit_for_the_period
             OR a.prev_outstanding IS DISTINCT FROM b.driver_opening_balance
             OR a.trips IS DISTINCT FROM b.trips
             OR a.adjustment_amount IS DISTINCT FROM b.adjustments
           THEN 'Yes'
           ELSE 'No'
       END AS has_difference_other_columns
   FROM (select * from recon_south_africa.reconciliation where week = '2025-11-03' ) a
   FULL OUTER JOIN (select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-11-03'
   ) b
       ON a.drn = b.drn AND a.week = b.recon_week
)
SELECT *
FROM combined
WHERE
   (record_status != 'DRN and UberID Present in all'
   OR has_uberid_difference = 'Yes'
   OR has_driver_opening_balance_difference = 'Yes'
   OR has_driver_closing_balance_difference = 'Yes'
   OR has_difference_other_columns = 'Yes')
   and country_martweeklyrecon is not null
order by drn;

