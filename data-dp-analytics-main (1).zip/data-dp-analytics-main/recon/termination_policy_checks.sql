----TERMINATION WINDOW CATEGORISATION----
----1. Count of Drivers per Termination Window
with base as (
SELECT
country, recon_week, drn,
contract_start_date, contract_end_date, debt_lock_end_date, collection_period_end_date, termination_activity_start_date,
recon_contract_status,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window,
DATEDIFF(day, contract_end_date, debt_lock_end_date) AS expected_days_in_lock,
DATEDIFF(day, contract_end_date, collection_period_end_date) AS expected_days_to_collection_end
FROM core_dimensions.mart_driver_weekly_recon_draft where recon_week ='2026-09-14' and country = 'South Africa'
),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
)
select termination_window,
count(distinct drn), 
min(days_in_term_window)min_days_in_term_window, max(days_in_term_window)max_days_in_term_window,
max(expected_days_in_lock)max_expected_days_in_lock, max(expected_days_to_collection_end)max_expected_days_to_collection_end
from term_category
group by termination_window order by termination_window ;



----TERMINATION WINDOW CATEGORISATION BY CONTRACT STATUS----
---2. Checking Termination Window vs Contract Status
with base as (
SELECT
country, recon_week, drn,
contract_start_date, contract_end_date, debt_lock_end_date, collection_period_end_date, termination_activity_start_date,
recon_contract_status,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window,
DATEDIFF(day, contract_end_date, debt_lock_end_date) AS expected_days_in_lock,
DATEDIFF(day, contract_end_date, collection_period_end_date) AS expected_days_to_collection_end
FROM core_dimensions.mart_driver_weekly_recon_draft where recon_week ='2026-09-14' and country = 'South Africa'
),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
)
--select * from term_category --where termination_window = 'active_or_open' and recon_contract_status = 'COMPLETED';
--where days_in_term_window is null and contract_end_date is not null
select recon_contract_status, termination_window,
count(distinct drn), 
min(days_in_term_window)min_days_in_term_window, max(days_in_term_window)max_days_in_term_window,
max(expected_days_in_lock)max_expected_days_in_lock, max(expected_days_to_collection_end)max_expected_days_to_collection_end
from term_category
group by recon_contract_status, termination_window order by termination_window, recon_contract_status ;




---3. Charges in the collection window (should return 0 rows)
with base as (
SELECT drn, recon_week,contract_status, adjustments,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window,
contract_end_date, debt_lock_end_date, collection_period_end_date,
extra_charges, additional_charges, passthrough_costs, repair_charges, termination_fee
FROM core_dimensions.mart_driver_weekly_recon
where country = 'South Africa' and  recon_week = '2026-09-14'),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
)
select * from term_category
where termination_window = 'collection'
AND (
NULLIF(extra_charges, 0) <> 0
OR NULLIF(additional_charges, 0) <> 0
OR NULLIF(passthrough_costs, 0) <> 0
OR NULLIF(repair_charges, 0) <> 0
OR NULLIF(adjustments, 0) < 0  ---there should be no charges via adjustments on the ODI for drivers in collection window
--OR NULLIF(termination_fee, 0) <> 0  -- except the post_dec fee that posts *on* lock close
)
order by drn;






----4. CHECKING FOR TIMELY BUNDLED EXTRA CHARGES ----
with base as (
SELECT
country, recon_week, drn, extra_charges, passthrough_costs, repair_charges, termination_fee,
adjustments_breakdown, extra_charges_breakdown, passthrough_costs_breakdown, repair_charges_breakdown, all_extra_charges_breakdown,
payouts, driver_balance_for_the_period, driver_opening_balance, driver_closing_balance,
deposit_opening_balance, security_deposit_contribution, 
contract_start_date, contract_end_date, debt_lock_end_date, collection_period_end_date, termination_activity_start_date,
contract_status,
vehicle_assignment_status,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window,
DATEDIFF(day, contract_end_date, termination_activity_start_date) AS days_to_term_activity_start
FROM core_dimensions.mart_driver_weekly_recon_draft where recon_week ='2026-09-14' and country = 'South Africa'
),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
),
-----Checking for Bundled Extra Charges---
extra_charges_base as (
select *
from term_category
where --termination_window = 'debt_lock' and 
all_extra_charges_breakdown is not null 
and recon_week >= termination_activity_start_date  ---bundled extra charges occurs 10-14 days termination date (contract end date), which is where termination_activity_start_date starts
order by days_to_term_activity_start),
extra_charges_breakdown as (
---Validate the drivers extra charges installment remaining.
    SELECT 
        y.drn, 
        y.country, 
        b.driver_id, 
        b.status, 
        a.charge_date, 
        SUM(a.amount) AS weekly_amount, 
        b.charge_type
    FROM core_dimensions.fact_extra_charge_details a
    INNER JOIN core_dimensions.fact_driver_extra_charges b 
        ON a.charge_id = b.charge_id 
        AND b.status = 'APPROVED'
    INNER JOIN core_dimensions.dim_driver y 
        ON b.driver_id = y.driver_id 
        AND y.country = 'South Africa'
--    WHERE a.charge_date >= '2026-08-31' 
--    and y.drn = 'MVS24337'
    GROUP BY 
        y.drn, 
        y.country, 
        b.driver_id, 
        b.status, 
        a.charge_date, 
        b.charge_type
)
----Any Large Sum is considered a Bundled Extra Charge (possibly >1000). We don't have an identifier for such on Recon for now.---
select a.country, recon_week, a.drn, contract_start_date, contract_end_date, debt_lock_end_date, collection_period_end_date, termination_activity_start_date,
contract_status, vehicle_assignment_status,
days_in_term_window, days_to_term_activity_start, termination_window,
extra_charges, passthrough_costs, repair_charges, termination_fee,
all_extra_charges_breakdown,
COUNT(b.weekly_amount) as count_of_remaining_extra_charges_weekly_amount,
SUM(b.weekly_amount) as sum_of_remaining_extra_charges_weekly_amount
from extra_charges_base a
left join extra_charges_breakdown b
on a.drn = b.drn
where charge_date >= a.recon_week
group by a.country, recon_week, a.drn, contract_start_date, contract_end_date, debt_lock_end_date, collection_period_end_date, termination_activity_start_date,
contract_status, vehicle_assignment_status,
days_in_term_window, days_to_term_activity_start, termination_window,
extra_charges, passthrough_costs, repair_charges, termination_fee,
all_extra_charges_breakdown;






-------------------------------------
---5A. VALIDATING: Remit are not charged during Debt lock & Collection period
with Base as(SELECT drn, recon_week, contract_end_date, driver_remit_for_the_period, payouts,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE recon_week ='2026-09-14' and country = 'South Africa'
and contract_end_date IS NOT null
),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
)
--Check that no remit was charged in 'debt_lock' and 'collection' periods---
select * from term_category 
where termination_window in ('debt_lock', 'collection')
AND recon_week > contract_end_date
AND NULLIF(driver_remit_for_the_period, 0) <> 0; 




-------------------------------------
---5B. VALIDATING: Payouts are not made for drivers during Debt lock period
with Base as(SELECT drn, recon_week, contract_end_date, driver_remit_for_the_period, payouts,driver_closing_balance,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE recon_week ='2026-09-14' and country = 'South Africa'
and contract_end_date IS NOT null
),
term_category as (
select *,
case
	when days_in_term_window is null and contract_end_date is null then 'active_or_open'
	when days_in_term_window is null and contract_end_date is not null then 'post_collection'
	when days_in_term_window >0 and days_in_term_window <=30 then 'debt_lock'
	when days_in_term_window >30 and days_in_term_window <=60 then 'collection'
	when days_in_term_window >60 then 'post_collection'
end as
termination_window 
from base 
)
---Check that no payout was made in the 'debt_lock' period
select * from term_category 
where termination_window = 'debt_lock'
AND recon_week > contract_end_date
AND (NULLIF(payouts, 0) <> 0  ---Check that no payout was made
---Also check for drivers with positive driver_closing_balance---
or NULLIF(driver_closing_balance, 0) > 0);






----------------------------------------------------------------------
--"6. Check Tenure at Termination - SIMPLE OVERVIEW COUNT
---------------------------------------------------------------------
with term_fee_base as (
SELECT
drn, recon_contract_status,
contract_start_date,
contract_end_date,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
termination_fee,
deposits_refunds,
recon_week,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
and contract_end_date IS NOT null
and recon_contract_status = 'TERMINATED'
---and contract_end_date > '2026-09-01' ---When the policy was released
)
---SIMPLE OVERVIEW---
select count(distinct drn)drn, recon_contract_status, term_fee_cohort 
from term_fee_base 
group by term_fee_cohort, recon_contract_status
order by term_fee_cohort;





----------------------------------------------------------------------
--"6A. Check Tenure at Termination
--If  `contract_start_date` < 2025-12-01 and tenure 6–12 months:
-- Termination fee = non-refundable part of deposit (20% of SD). Charged same week as termination+1, not at day 30 "
----------------------------------------------------
---`termination_fee` posted on the termination recon week; amount ≈ 20% of original deposit (2 dp). Not delayed to `debt_lock_end_date` 
with term_fee_base as (
SELECT
drn, recon_contract_status,
contract_start_date,
contract_end_date,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
termination_fee,
deposits_refunds, adjustments,adjustment_type,
recon_week,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
and contract_end_date between (recon_week - interval '7 day')::date  and (recon_week + interval '6 day')::date   ---Checking they terminated in the currect recon week +1. The termination fee is charged between termination week and termination week+1.
and recon_contract_status = 'TERMINATED'
--and contract_end_date > '2026-09-01'  ---Starting from when the termination policy was released.
),
sd_details as (
select
drn, start_date, end_date,
debt_lock_end_date, collection_period_end_date, status,  security_deposit,
nvl (refundable_security_deposit, 0 ) as refundable_security_deposit , 
nvl(security_deposit - nvl (refundable_security_deposit, 0 )  ) as non_refundable_security_deposit
from core_dimensions.fact_contract_daily a
left join core_dimensions.dim_driver b on a.driver_sk = b.driver_sk
where a.country = 'South Africa'
and date = '2026-09-14'
)
---6A: If  `contract_start_date` < 2025-12-01 and tenure 6–12 months:
-- Termination fee = non-refundable part of deposit (20% ). Charged same week +1 as termination, not at day 30 "
select 
a.drn, recon_week, contract_start_date, contract_end_date, tenure_months, tenure_days,
recon_contract_status, term_fee_cohort, termination_fee, adjustments, adjustment_type, non_refundable_security_deposit, 
COALESCE(a.termination_fee + coalesce(b.non_refundable_security_deposit,0) ,0) as check_gap,
security_deposit, refundable_security_deposit,
deposits_refunds, days_in_term_window 
from term_fee_base a
left join sd_details b
on a.drn = b.drn
where term_fee_cohort = 'pre_dec_6_12_fee_charged_in_term_week'
and b.security_deposit <> 0
--and days_in_term_window >5;--Term fee will reflect 10-14 days post termination. We aligned on Aug 19 with SA ops - Alignment - Showcase driver debt on termination week + 1 rather than terminated week 
and COALESCE(a.termination_fee + coalesce(b.non_refundable_security_deposit,0) ,0) <>0;
---Check that the driver has not been charged termination fee before--



----------------------------------------------------------------------
--"6B. Check Tenure at Termination
--Contract start date < 2025-12-01 and tenure outside 6–12 months:
--No termination fee.
--Remaining refundable deposit paid back ~1 week after debt lock closes, if no debt."
with term_fee_base as (
SELECT
drn, recon_contract_status,
contract_start_date,
contract_end_date, 
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance,
deposit_opening_balance, security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
termination_fee,
recon_week,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
and contract_end_date IS NOT null
and recon_contract_status = 'TERMINATED'
),
sd_details as (
select
drn, status,  security_deposit,
nvl (refundable_security_deposit, 0 ) as refundable_security_deposit , 
nvl(security_deposit - nvl (refundable_security_deposit, 0 )  ) as non_refundable_security_deposit
from core_dimensions.fact_contract_daily a
left join core_dimensions.dim_driver b on a.driver_sk = b.driver_sk
where a.country = 'South Africa'
and date = '2026-09-14'
)
--Check that Remaining refundable deposit paid back ~1 week after debt lock closes, if no debt.
select 
a.drn, a.recon_week, a.days_in_term_window, contract_start_date, contract_end_date, tenure_months, tenure_days,
recon_contract_status, term_fee_cohort, 
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance, 
a.deposit_opening_balance, a.security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
termination_fee, non_refundable_security_deposit, 
--COALESCE(a.termination_fee - coalesce(b.non_refundable_security_deposit * (-1),0) ,0) as check_gap,
security_deposit, refundable_security_deposit 
from term_fee_base a
left join sd_details b
on a.drn = b.drn
where term_fee_cohort = 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
and b.security_deposit <> 0
and days_in_term_window >=30
and refundable_security_deposit <>0
--and amount_credit_from_sd_to_recon <> 0
--and driver_closing_balance <=0;
order by a.days_in_term_window;






----------------------------------------------------------------------
--"6C. Check Tenure at Termination
--Contract start date ≥ 2025-12-01:
--Entire deposit becomes termination fee when debt lock window closes. No partial refund."
with term_fee_base as (
SELECT
drn, recon_contract_status,
contract_start_date,
contract_end_date, debt_lock_end_date , collection_period_end_date ,adjustments, adjustment_type,
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance,
deposit_opening_balance, security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
termination_fee,
recon_week,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
and contract_end_date IS NOT null
and recon_contract_status = 'TERMINATED'
---and contract_end_date > '2026-09-01'  ---Starting from when the termination policy was released.
),
sd_details as (
select
drn, status,  security_deposit,
nvl (refundable_security_deposit, 0 ) as refundable_security_deposit , 
nvl(security_deposit - nvl (refundable_security_deposit, 0 )  ) as non_refundable_security_deposit
from core_dimensions.fact_contract_daily a
left join core_dimensions.dim_driver b on a.driver_sk = b.driver_sk
where a.country = 'South Africa'
and date = '2026-09-14'
)
--Entire deposit becomes termination fee when debt lock window closes. No partial refund.
select 
a.drn, a.recon_week, a.days_in_term_window, contract_start_date, contract_end_date, tenure_months, tenure_days,
recon_contract_status, term_fee_cohort, adjustments,adjustment_type,
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance, termination_fee,
a.deposit_opening_balance, a.security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
non_refundable_security_deposit,
security_deposit, refundable_security_deposit 
from term_fee_base a
left join sd_details b
on a.drn = b.drn
where term_fee_cohort = 'post_dec_full_deposit_as_term_fee_at_lock_end'
and b.security_deposit <> 0
and days_in_term_window >=30
and (recon_week -  contract_end_date) <=30  ---drivers entering the debt lock period this week.
order by deposit_opening_balance;






--"7&8A. VALIDATE: Security Deposit <> Recon Money Movement
-- - Money moves from SD to Recon reduces SD closing balance and increases Recon closing balance by the same amount   
--- Balances Check
with term_fee_base as (
select *,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
--and contract_end_date IS NOT null
--and recon_contract_status = 'TERMINATED'
--and contract_end_date > '2026-09-01'  ---Starting from when the termination policy was released.
),
sd_details as (
select
drn, status,  security_deposit,
nvl (refundable_security_deposit, 0 ) as refundable_security_deposit , 
nvl(security_deposit - nvl (refundable_security_deposit, 0 )  ) as non_refundable_security_deposit
from core_dimensions.fact_contract_daily a
left join core_dimensions.dim_driver b on a.driver_sk = b.driver_sk
where a.country = 'South Africa'
and date = '2026-09-14'
),
--Check money flow from SD to Recon & vice versa---
money_flow as (
select 
a.drn, a.recon_week, a.days_in_term_window, contract_start_date, contract_end_date, tenure_months, tenure_days,
recon_contract_status, term_fee_cohort, 
a.deposit_opening_balance, a.security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
COALESCE((deposit_opening_balance + amount_credit_from_recon_to_sd+ amount_debit_from_sd_to_recon+ deposits_inflow+ deposits_refunds),0) as sd_balance_calc_check,
COALESCE((uber_balance + payins + incentives + driver_remit_for_the_period + extra_charges + passthrough_costs +adjustments + payouts  
+ additional_charges + repair_charges+ security_deposit_contribution +amount_credit_from_sd_to_recon +termination_fee),0) as calc_check_balance_for_the_period,
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance,
COALESCE((uber_balance + payins + incentives + driver_remit_for_the_period + extra_charges + passthrough_costs +adjustments + payouts  
+ additional_charges + repair_charges+ security_deposit_contribution +amount_credit_from_sd_to_recon +termination_fee + driver_opening_balance),0) as recon_balance_calc_check,
termination_fee, non_refundable_security_deposit,
security_deposit, refundable_security_deposit 
from term_fee_base a
left join sd_details b
on a.drn = b.drn
where amount_debit_from_sd_to_recon is not null
and amount_debit_from_sd_to_recon <> 0
order by contract_end_date)
select *, 
COALESCE(ROUND((sd_balance_calc_check - deposit_closing_balance),-1),0) as gap_check_sd_balance,
COALESCE(ROUND((calc_check_balance_for_the_period - driver_balance_for_the_period),-1),0) as gap_check_balance_for_the_period,
COALESCE(ROUND((recon_balance_calc_check - driver_closing_balance),-1),0) as gap_check_closing_balance
from money_flow ;







--"7&8B. VALIDATE: Security Deposit <> Recon Money Movement
-- - Money moves from Recon to SD reduces SD closing balance and increases Recon closing balance by the same amount  
--- Balances Check
with term_fee_base as (
select *,
DATEDIFF(month, contract_start_date, contract_end_date) AS tenure_months,
DATEDIFF(day, contract_start_date, contract_end_date) AS tenure_days,
CASE
WHEN contract_start_date >= '2025-12-01' THEN 'post_dec_full_deposit_as_term_fee_at_lock_end'
WHEN (contract_start_date < '2025-12-01' 
and DATEDIFF(day, contract_start_date, contract_end_date) > 180
and DATEDIFF(day, contract_start_date, contract_end_date) < 365)
THEN 'pre_dec_6_12_fee_charged_in_term_week'
ELSE 'pre_dec_sd_bal_refund_2Recon_after_debtlock'
END AS term_fee_cohort,
CASE 
    WHEN debt_lock_end_date IS NOT NULL OR collection_period_end_date IS NOT NULL THEN
        DATEDIFF(day, contract_end_date, 
            CASE 
                WHEN recon_week <= debt_lock_end_date THEN LEAST(debt_lock_end_date, (recon_week + interval '6 day')::date) 
                WHEN recon_week > debt_lock_end_date AND recon_week <= collection_period_end_date THEN LEAST(collection_period_end_date, (recon_week + interval '6 day')::date) 
                ELSE (recon_week + interval '6 day')::date 
            END
        )
    ELSE NULL
END AS days_in_term_window
FROM core_dimensions.mart_driver_weekly_recon_draft
WHERE country = 'South Africa' and recon_week = '2026-09-14'
--and contract_end_date IS NOT null
--and recon_contract_status = 'TERMINATED'
--and contract_end_date > '2026-09-01'  ---Starting from when the termination policy was released.
),
sd_details as (
select
drn, status,  security_deposit,
nvl (refundable_security_deposit, 0 ) as refundable_security_deposit , 
nvl(security_deposit - nvl (refundable_security_deposit, 0 )  ) as non_refundable_security_deposit
from core_dimensions.fact_contract_daily a
left join core_dimensions.dim_driver b on a.driver_sk = b.driver_sk
where a.country = 'South Africa'
and date = '2026-09-14'
),
--Check money flow from Recon to SD & vice versa---
money_flow as (
select 
a.drn, a.recon_week, a.days_in_term_window, contract_start_date, contract_end_date, tenure_months, tenure_days,
recon_contract_status, term_fee_cohort, 
a.deposit_opening_balance, a.security_deposit_contribution, 
amount_credit_from_recon_to_sd, amount_debit_from_sd_to_recon, 
amount_debit_from_recon_to_sd, amount_credit_from_sd_to_recon, 
deposits_inflow, deposits_refunds, deposit_closing_balance,
COALESCE((deposit_opening_balance + amount_credit_from_recon_to_sd+ amount_debit_from_sd_to_recon+ deposits_inflow+ deposits_refunds),0) as sd_balance_calc_check,
COALESCE((uber_balance + payins + incentives + driver_remit_for_the_period + extra_charges + passthrough_costs +adjustments + payouts  
+ additional_charges + repair_charges+ security_deposit_contribution +amount_credit_from_sd_to_recon +termination_fee),0) as calc_check_balance_for_the_period,
driver_balance_for_the_period, driver_opening_balance, driver_closing_balance,
COALESCE((uber_balance + payins + incentives + driver_remit_for_the_period + extra_charges + passthrough_costs +adjustments + payouts  
+ additional_charges + repair_charges+ security_deposit_contribution +amount_credit_from_sd_to_recon +termination_fee + driver_opening_balance),0) as recon_balance_calc_check,
termination_fee, non_refundable_security_deposit,
security_deposit, refundable_security_deposit 
from term_fee_base a
left join sd_details b
on a.drn = b.drn
where amount_debit_from_recon_to_sd is not null
and amount_debit_from_recon_to_sd <> 0
order by contract_end_date)
select *, 
COALESCE(ROUND((sd_balance_calc_check - deposit_closing_balance),-1),0) as gap_check_sd_balance,
COALESCE(ROUND((calc_check_balance_for_the_period - driver_balance_for_the_period),-1),0) as gap_check_balance_for_the_period,
COALESCE(ROUND((recon_balance_calc_check - driver_closing_balance),-1),0) as gap_check_closing_balance
from money_flow ;







