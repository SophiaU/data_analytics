-------------------------------------------------
-----RECON 2.0 ADDITIONAL POST RECON CHECKS------
-----December 16, 2025----
-------------------------------------------------


----CHECK 1  ---Inputs vs Applied Inputs on Recon--------------
--===UBER EARNINGS====-----
with uber_input as (select distinct duuid,drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2025-12-08'
and duuid not in 
---Moove Fleet IDs
('943a1d1f-d1d4-4acd-b7f9-10b17344ab1f',
'64bed3ed-12a2-4eec-b5f2-f453202b3f33',
'945eaa40-b215-48d4-9e51-9fb10781e6a3',
'009c1303-82b5-4930-bdae-b6f2e6526a7e',
'686c4863-876a-4b7e-9a44-15c899ceafa7',
'd25a67d5-f772-4529-b78c-a4449240c8aa',
'f828fe43-fc6c-4cfe-aacb-1190a2e85b12',
'c8a568ab-1f4f-4c6a-8184-2dcdbc6820ba',
'16811eca-a0ac-45f2-9cba-f5a2df2b191d',
'a29a4936-53df-466f-900c-dfdc476cc3c8',
'feb26b3a-c134-41d0-9600-02a76f4aad11',
'44db17e2-f7c6-4259-b9da-528dd8cdbbe5',
'c6b0d226-8336-4b4b-bad1-5c1fff553ad7',
'8ef0ada4-f2df-4417-a3f8-669c7399846f',
'b8cc7e08-8a97-4b46-a631-485d211e111a',
'03bfa0f3-5cb0-4dce-b491-040659f67a1b',
'ae00c14d-c207-4378-8a11-aa9495d7b2c7',
'19c079b7-fe94-4066-9a4d-f5db237a5de8',
'0120e89a-fab5-4e59-9c56-44b51ca24166',
'63847379-edec-45e1-9094-f540854b72e6',
'ef4658ed-acf6-4c7a-a379-7fa2cf0138ed',
'7f0eee71-d1d6-4bd1-ab74-435a12911f62',
'848330a9-7852-4aef-9729-43ac3b2b6cc7',
'bbe787cd-f70b-407d-afe9-4fbe57a13bce',
'0bc556a9-c75e-4590-af18-e8025790a1d0',
'e260de13-1cde-439d-b6ea-cae0e552be6b',
'428c7180-b0a5-4b0d-9d6e-af9e15a5ff16',
'035f9c4f-becf-41b1-846e-becae97541e4',
'cab123a4-c3e0-490f-85f0-d3eeec1c2e91',
'4cec0c4d-1182-494a-b508-23989b190c57',
'50f6d72b-e3bb-4263-9a52-6678e1d8f988',
'85c889eb-34c4-4939-9081-63342034b76a',
'4d10a11f-45cd-409c-bf46-bfc1b5274ca6',
'3e26ade0-c5aa-48f0-8a54-8298ccd64bc9',
'841ef0cc-21b0-4227-b7a3-a8a877ab028c',
'00000000-0000-0000-0000-000000000000')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
and drn is not null
group by duuid,drn  order by drn),
uber_recon as (
select distinct uber_id, drn, sum(net_earnings)net_earnings from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by uber_id, drn  order by drn
),
uber_earnings_check as (select a.duuid, a.drn, ROUND(a.net_earnings,2) as input_net_earnings, ROUND(b.net_earnings,2) as recon_net_earnings,
(ROUND(b.net_earnings,2) - ROUND(a.net_earnings,2)) as gap,
   case
       when ABS(ABS(ROUND(b.net_earnings,2)) - ABS(ROUND(a.net_earnings,2))) <= 1 then 'ok'
       else 'fail'
   end as uber_earnings_check
from uber_input a
left join uber_recon b
ON a.drn = b.drn
)
select * from uber_earnings_check ---where drn = 'MVS20604';
where uber_earnings_check = 'fail'
order by drn;



----CHECK 2  ---Inputs vs Applied Inputs on Recon--------------
--===Ineffective Days====-----
with ineffective_days_input as (select distinct drn, sum(ineffective_days) as input_ineffective_days from reconciliation_data.recon_inputs__ineffective_days --limit 10;
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__ineffective_days 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn
order by drn),
ineffective_days_recon as (
select distinct drn, sum(ineffective_days) as recon_ineffective_days from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
ineffective_days_check as (select a.drn, ROUND(a.input_ineffective_days,2) as input_ineffective_days, ROUND(b.recon_ineffective_days,2) as recon_ineffective_days,
(ROUND(b.recon_ineffective_days,2) - ROUND(a.input_ineffective_days,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_ineffective_days,2)) - ABS(ROUND(a.input_ineffective_days,2))) = 0 then 'ok'
       else 'fail'
   end as ineffective_days_check
from ineffective_days_input a
left join ineffective_days_recon b
ON a.drn = b.drn
)
select * from ineffective_days_check ---where drn = 'MVS20604';
where ineffective_days_check = 'fail'
order by drn;




----CHECK 3  ---Inputs vs Applied Inputs on Recon--------------
--===Extra Charges + Passthrough Cost====-----
with extracharges_passthrough_input as (select distinct drn, (NVL(sum(extra_charges),0) + NVL(SUM(passthrough_costs),0)) as input_extracharges_passthrough from reconciliation_data.recon_inputs__extra_charges
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__extra_charges 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE')
group by drn
order by drn),
extracharges_passthrough_recon as (
select distinct drn, (NVL(sum(extra_charges),0) + NVL(SUM(passthrough_costs),0)) as recon_extracharges_passthrough from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
extracharges_passthrough_check as (select a.drn, ROUND(a.input_extracharges_passthrough,2) as input_extracharges_passthrough, ROUND(b.recon_extracharges_passthrough,2) as recon_extracharges_passthrough,
(ROUND(b.recon_extracharges_passthrough,2) - ROUND(a.input_extracharges_passthrough,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_extracharges_passthrough,2)) - ABS(ROUND(a.input_extracharges_passthrough,2))) <= 1 then 'ok'
       else 'fail'
   end as extracharges_passthrough_check
from extracharges_passthrough_input a
left join extracharges_passthrough_recon b
ON a.drn = b.drn
)
select * from extracharges_passthrough_check ---where drn = 'MVS20604';
where extracharges_passthrough_check = 'fail'
order by drn;




----CHECK 4  ---Inputs vs Applied Inputs on Recon--------------
--===Adjustments====-----
with adjustments_input as (select distinct drn, sum(adjustment_amount) as input_adjustments from reconciliation_data.recon_inputs__adjustments --limit 10;
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__adjustments 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn order by drn),
adjustments_recon as (
select distinct drn, sum(adjustments) as recon_adjustments from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
adjustments_check as (select a.drn, ROUND(a.input_adjustments,2) as input_adjustments, ROUND(b.recon_adjustments,2) as recon_adjustments,
(ROUND(b.recon_adjustments,2) - ROUND(a.input_adjustments,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_adjustments,2)) - ABS(ROUND(a.input_adjustments,2))) <= 1 then 'ok'
       else 'fail'
   end as adjustments_check
from adjustments_input a
left join adjustments_recon b
ON a.drn = b.drn
)
select * from adjustments_check ---where drn = 'MVS20604';
where adjustments_check = 'fail'
order by drn;




----CHECK 5  ---Inputs vs Applied Inputs on Recon--------------
--===Payins====-----
with payins_input as (
SELECT distinct drn, NVL(sum(input_payins),0) as input_payins from (
----input_payins_bank----
select distinct drn, NVL(sum(payins),0) as input_payins from reconciliation_data.recon_inputs__payins 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__payins 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn
union all
---input_payments_aggregator
select distinct drn, NVL(sum(payments_aggregator_payins),0) as input_payins from reconciliation_data.recon_inputs__payments_aggregator_payins 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__payments_aggregator_payins 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn
  ) group by drn  order by drn 
),
payins_recon as (
select distinct drn, NVL(sum(payins),0.0) as recon_payins from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
payins_check as (select a.drn, ROUND(a.input_payins,2) as input_payins, ROUND(b.recon_payins,2) as recon_payins,
(ROUND(b.recon_payins,2) - ROUND(a.input_payins,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_payins,2)) - ABS(ROUND(a.input_payins,2))) <=1 then 'ok'
       else 'fail'
   end as payins_check
from payins_input a
left join payins_recon b
ON a.drn = b.drn
)
select * from payins_check
where payins_check = 'fail'
order by drn;



----CHECK 6  ---Inputs vs Applied Inputs on Recon--------------
--===Payouts====-----
with payouts_input as (
select distinct drn, NVL(sum(payouts),0) as input_payouts from reconciliation_data.recon_inputs__payouts 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__payouts 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
 group by drn  order by drn 
),
payouts_recon as (
select distinct drn, NVL(sum(payouts),0.0) as recon_payouts from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
payouts_check as (select a.drn, ROUND(a.input_payouts,2) as input_payouts, ROUND(b.recon_payouts,2) as recon_payouts,
(ROUND(b.recon_payouts,2) - ROUND(a.input_payouts,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_payouts,2)) - ABS(ROUND(a.input_payouts,2))) <=1 then 'ok'
       else 'fail'
   end as payouts_check
from payouts_input a
left join payouts_recon b
ON a.drn = b.drn
)
select * from payouts_check
--where payouts_check = 'fail'
order by drn;




----CHECK 7  ---Inputs vs Applied Inputs on Recon--------------
--===Security Deposit Inflow====-----
with deposits_inflow_input as (
select distinct drn, NVL(sum(deposits),0) as input_deposits_inflow from reconciliation_data.recon_inputs__deposits
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__deposits
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn order by drn 
),
deposits_inflow_recon as (
select distinct drn, NVL(sum(deposits_inflow),0.0) as recon_deposits_inflow from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
deposits_inflow_check as (select a.drn, ROUND(a.input_deposits_inflow,2) as input_deposits_inflow, ROUND(b.recon_deposits_inflow,2) as recon_deposits,
(ROUND(b.recon_deposits_inflow,2) - ROUND(a.input_deposits_inflow,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_deposits_inflow,2)) - ABS(ROUND(a.input_deposits_inflow,2))) <=1 then 'ok'
       else 'fail'
   end as deposits_inflow_check
from deposits_inflow_input a
left join deposits_inflow_recon b
ON a.drn = b.drn
)
select * from deposits_inflow_check
where deposits_inflow_check = 'fail'
order by drn;



----CHECK 8  ---Inputs vs Applied Inputs on Recon--------------
--===Security Deposit Refunds====-----
with deposit_refunds_input as (
select distinct drn, NVL(sum(deposit_refunds),0) as input_deposit_refunds from reconciliation_data.recon_inputs__deposit_refunds
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__deposit_refunds
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly')
----Considering only active contract---
and drn in 
(select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' )
group by drn order by drn 
),
deposit_refunds_recon as (
select distinct drn, NVL(sum(deposits_refunds),0.0) as recon_deposit_refunds from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by drn  order by drn
),
deposit_refunds_check as (select a.drn, ROUND(a.input_deposit_refunds,2) as input_deposit_refunds, ROUND(b.recon_deposit_refunds,2) as recon_deposits,
(ROUND(b.recon_deposit_refunds,2) - ROUND(a.input_deposit_refunds,2)) as gap,
   case
       when ABS(ABS(ROUND(b.recon_deposit_refunds,2)) - ABS(ROUND(a.input_deposit_refunds,2))) <=1 then 'ok'
       else 'fail'
   end as deposit_refunds_check
from deposit_refunds_input a
left join deposit_refunds_recon b
ON a.drn = b.drn
)
select * from deposit_refunds_check
where deposit_refunds_check = 'fail'
order by drn;



----CHECK 9 
---Checks for drivers with Active Contracts, Unassigned But Still Charged.
with recon_data as (
 select drn,
        effective_days,
        driver_remit_for_the_period as remittance,
        driver_closing_balance
 from core_dimensions.mart_driver_weekly_recon
 where lower(country) = 'south africa' and recon_week = '2025-12-08'),
 latest_assignment AS (
 SELECT
   drn,
   vehicle_assignment_start_date,
   vehicle_assignment_end_date
 FROM (
   SELECT
     drn,
     vehicle_assignment_start_date,
     vehicle_assignment_end_date,
     ROW_NUMBER() OVER (PARTITION BY drn ORDER BY vehicle_assignment_end_date DESC) AS rn
   FROM dbt.core__vehicle_driver_assignment
 ) t
 WHERE rn = 1
)
select rd.drn,
      rd.effective_days,
      rd.remittance,
      rd.driver_closing_balance,
      date(la.vehicle_assignment_start_date) as vehicle_assignment_start_date,
      date(la.vehicle_assignment_end_date) as vehicle_assignment_end_date
   from latest_assignment  la
join recon_data rd
on la.drn = rd.drn
where la.vehicle_assignment_end_date < '2025-12-08' and rd.effective_days <>0; ---enter current recon week


----CHECK 10
---Check to compare daily vs weekly recon drn list---
select * from core_dimensions.fact_recon_daily where lower(country) = 'south africa' and recon_week = '2025-12-08'
and drn not in (select distinct drn from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-12-08');





----CHECK 11 
--===UBERID MAPPING====-----
with uber_input as (select distinct duuid,drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2025-12-08'
and duuid not in 
---Moove Fleet IDs
('943a1d1f-d1d4-4acd-b7f9-10b17344ab1f',
'64bed3ed-12a2-4eec-b5f2-f453202b3f33',
'945eaa40-b215-48d4-9e51-9fb10781e6a3',
'009c1303-82b5-4930-bdae-b6f2e6526a7e',
'686c4863-876a-4b7e-9a44-15c899ceafa7',
'd25a67d5-f772-4529-b78c-a4449240c8aa',
'f828fe43-fc6c-4cfe-aacb-1190a2e85b12',
'c8a568ab-1f4f-4c6a-8184-2dcdbc6820ba',
'16811eca-a0ac-45f2-9cba-f5a2df2b191d',
'a29a4936-53df-466f-900c-dfdc476cc3c8',
'feb26b3a-c134-41d0-9600-02a76f4aad11',
'44db17e2-f7c6-4259-b9da-528dd8cdbbe5',
'c6b0d226-8336-4b4b-bad1-5c1fff553ad7',
'8ef0ada4-f2df-4417-a3f8-669c7399846f',
'b8cc7e08-8a97-4b46-a631-485d211e111a',
'03bfa0f3-5cb0-4dce-b491-040659f67a1b',
'ae00c14d-c207-4378-8a11-aa9495d7b2c7',
'19c079b7-fe94-4066-9a4d-f5db237a5de8',
'0120e89a-fab5-4e59-9c56-44b51ca24166',
'63847379-edec-45e1-9094-f540854b72e6',
'ef4658ed-acf6-4c7a-a379-7fa2cf0138ed',
'7f0eee71-d1d6-4bd1-ab74-435a12911f62',
'848330a9-7852-4aef-9729-43ac3b2b6cc7',
'bbe787cd-f70b-407d-afe9-4fbe57a13bce',
'0bc556a9-c75e-4590-af18-e8025790a1d0',
'e260de13-1cde-439d-b6ea-cae0e552be6b',
'428c7180-b0a5-4b0d-9d6e-af9e15a5ff16',
'035f9c4f-becf-41b1-846e-becae97541e4',
'cab123a4-c3e0-490f-85f0-d3eeec1c2e91',
'4cec0c4d-1182-494a-b508-23989b190c57',
'50f6d72b-e3bb-4263-9a52-6678e1d8f988',
'85c889eb-34c4-4939-9081-63342034b76a',
'4d10a11f-45cd-409c-bf46-bfc1b5274ca6',
'3e26ade0-c5aa-48f0-8a54-8298ccd64bc9',
'841ef0cc-21b0-4227-b7a3-a8a877ab028c',
'00000000-0000-0000-0000-000000000000')
group by duuid,drn  order by drn),
uber_recon as (
select distinct uber_id, drn, sum(net_earnings)net_earnings from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-08'
group by uber_id, drn  order by drn
),
uberid_mapping_check as (select a.duuid, a.drn, ROUND(a.net_earnings,2) as input_net_earnings, ROUND(b.net_earnings,2) as recon_net_earnings,
(ROUND(b.net_earnings,2) - ROUND(a.net_earnings,2)) as gap,
   case
       when ABS(ABS(ROUND(b.net_earnings,2)) - ABS(ROUND(a.net_earnings,2))) <= 1 then 'ok'
       else 'fail'
   end as uberid_mapping_check
from uber_input a
left join uber_recon b
ON a.drn = b.drn
)
select * from uberid_mapping_check ---where drn = 'MVS20604';
where drn is null
order by drn;



----CHECK 12 
---Assigned but with no Active contract, so not reflecting on Recon----
with recon_data as (
 select distinct drn
 from core_dimensions.mart_driver_weekly_recon
 where lower(country) = 'south africa' and recon_week = '2025-12-08'),
contract as (
select distinct d.drn
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where status = 'ACTIVE' 
),
 latest_assignment AS (
 SELECT
   drn,
   vehicle_assignment_start_date,
   vehicle_assignment_end_date
 FROM (
   SELECT
     drn,
     vehicle_assignment_start_date,
     vehicle_assignment_end_date,
     ROW_NUMBER() OVER (PARTITION BY drn ORDER BY vehicle_assignment_end_date DESC) AS rn
   FROM dbt.core__vehicle_driver_assignment
   where UPPER(drn) ilike '%MVS%'
 ) t
 WHERE rn = 1
)
select * from latest_assignment
where vehicle_assignment_end_date is null
and drn not in (select distinct drn from recon_data)
and drn not in (select distinct drn from contract);






