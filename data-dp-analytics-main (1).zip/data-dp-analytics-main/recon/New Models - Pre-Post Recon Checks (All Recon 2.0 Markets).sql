
-----====PRE-POST RECON CHECKS======--------
-----August 24, 2026--------

--The Format: Country | Date | DRN | UberID | Pre | Post | Gap ---For each metric.

----UBER----
WITH pre_uber AS (
    SELECT 
        country, 
        effective_date, 
        uber_driver_id, 
        paidtoyou AS uber_balance
    FROM core_dimensions.fact_uber_aggr_driver_daily 
    WHERE effective_date BETWEEN '2026-08-24' AND '2026-08-30'
      AND country IN ('southafrica', 'ghana', 'colombia')
),
post_uber AS (
    SELECT 
        day, 
        uber_id, 
        drn, 
        uber_payments_partner_balance
    FROM core_dimensions.fact_recon_daily_draft
    WHERE day BETWEEN '2026-08-24' AND '2026-08-30'
),
comparison AS (
    SELECT 
        a.country, 
        a.effective_date AS input_day, 
        b.day AS recon_day, 
        a.uber_driver_id AS uber_id, 
        b.drn, 
        a.uber_balance AS pre_uber_balance, 
        b.uber_payments_partner_balance AS post_uber_balance,
        (COALESCE(a.uber_balance, 0) - COALESCE(b.uber_payments_partner_balance, 0)) AS gap_uber_balance
    FROM pre_uber a
    LEFT JOIN post_uber b
        ON a.uber_driver_id = b.uber_id 
        AND a.effective_date = b."day"
)
SELECT * 
FROM comparison c
WHERE gap_uber_balance <> 0
  AND NOT EXISTS (
      SELECT 1 
      FROM fivetran_gsheets.moove_fleet_uberids f 
      WHERE f.duuid = c.uber_id
  )
ORDER BY country, input_day;







---EXTRA CHARGES---
WITH pre_extra_charges AS (
    SELECT 
        y.drn, 
        y.country, 
        b.driver_id, 
        b.status, 
        a.charge_date, 
        SUM(a.amount) AS weekly_amount, 
        b.charge_type,
        z.start_date AS contract_start_date, 
        z.end_date AS contract_end_date, 
        z.status AS contract_status
    FROM core_dimensions.fact_extra_charge_details a
    INNER JOIN core_dimensions.fact_driver_extra_charges b 
        ON a.charge_id = b.charge_id 
        AND b.status = 'APPROVED'
    INNER JOIN core_dimensions.dim_driver y 
        ON b.driver_id = y.driver_id 
        AND y.country IN ('South Africa', 'Ghana', 'Colombia', 'Mexico')
    LEFT JOIN core_dimensions.fact_contract_daily z 
        ON b.driver_sk = z.driver_sk 
        AND a.charge_date = z.date
    WHERE a.charge_date BETWEEN '2026-08-24' AND '2026-08-30'
    GROUP BY 
        y.drn, 
        y.country, 
        b.driver_id, 
        b.status, 
        a.charge_date, 
        b.charge_type,
        z.start_date, 
        z.end_date, 
        z.status
), 
post_extra_charges AS (
    SELECT 
        country, 
        day, 
        uber_id, 
        drn, 
        additional_charges_extra_charges, 
        (COALESCE(additional_charges_passthrough_costs, 0) + COALESCE(additional_charges_repair_charges, 0)) AS additional_charges_passthrough_costs
    FROM core_dimensions.fact_recon_daily_draft
    WHERE day BETWEEN '2026-08-24' AND '2026-08-30'
),
comparison AS (
    SELECT 
        a.country, 
        a.charge_date AS input_day, 
        b.day AS recon_day, 
        b.uber_id, 
        a.drn, 
        SUM(CASE WHEN a.charge_type = 'EXTRA_CHARGE' THEN a.weekly_amount ELSE 0 END) AS pre_extra_charges,
        SUM(CASE WHEN a.charge_type = 'PASSTHROUGH_COST' THEN a.weekly_amount ELSE 0 END) AS pre_passthrough_cost,
        MAX(b.additional_charges_extra_charges) * -1 AS post_extra_charges, 
        MAX(b.additional_charges_passthrough_costs) * -1 AS post_passthrough_costs,
        a.contract_start_date, 
        a.contract_end_date, 
        a.contract_status
    FROM pre_extra_charges a
    LEFT JOIN post_extra_charges b 
        ON a.drn = b.drn 
        AND a.charge_date = b."day"
    GROUP BY 
        a.country, 
        a.charge_date, 
        b.day, 
        b.uber_id, 
        a.drn, 
        a.contract_start_date, 
        a.contract_end_date, 
        a.contract_status
)
SELECT 
    country, 
    input_day, 
    recon_day, 
    uber_id, 
    drn, 
    pre_extra_charges, 
    post_extra_charges, 
    (COALESCE(pre_extra_charges, 0) - COALESCE(post_extra_charges, 0)) AS gap_extra_charges,
    pre_passthrough_cost, 
    post_passthrough_costs, 
    (COALESCE(pre_passthrough_cost, 0) - COALESCE(post_passthrough_costs, 0)) AS gap_passthrough_costs,
    contract_start_date, 
    contract_end_date, 
    contract_status
FROM comparison
WHERE (COALESCE(pre_extra_charges, 0) - COALESCE(post_extra_charges, 0)) <> 0 
   OR (COALESCE(pre_passthrough_cost, 0) - COALESCE(post_passthrough_costs, 0)) <> 0
ORDER BY country, input_day;




---PAYINS----
WITH pre_payments AS (
    SELECT 
        x.drn, 
        x.payment_date, 
        x.country_code, 
        (x.sheet_payins_amount + x.aggregator_payins_amount) AS pre_payins, 
        x.sheet_payouts_amount AS pre_payouts, 
        x.sheet_deposit_payins_amount AS pre_deposit_payins, 
        x.sheet_deposit_refunds_amount AS pre_deposit_refunds,
        z.start_date AS contract_start_date, 
        z.end_date AS contract_end_date, 
        z.status AS contract_status
    FROM core_dimensions.fact_bank_payments_daily x
    LEFT JOIN core_dimensions.fact_contract_daily z 
        ON x.driver_sk = z.driver_sk 
        AND x.payment_date = z.date
    WHERE x.payment_date BETWEEN '2026-08-24' AND '2026-08-30'
      AND x.country_code IN ('ZA', 'GH', 'CO', 'MX')
), 
post_payments AS (
    SELECT 
        country, 
        day, 
        uber_id, 
        drn, 
        payments_payins AS post_payins, 
        payments_payouts AS post_payouts, 
        security_deposit_bank_payins AS post_deposit_payins, 
        security_deposit_bank_refunds AS post_deposit_refunds
    FROM core_dimensions.fact_recon_daily_draft
    WHERE day BETWEEN '2026-08-24' AND '2026-08-30'
),
comparison AS (
    SELECT 
        a.country_code, 
        a.payment_date AS input_day, 
        b.day AS recon_day, 
        b.uber_id, 
        a.drn,
        a.pre_payins, 
        b.post_payins,
        (COALESCE(a.pre_payins, 0) - COALESCE(b.post_payins, 0)) AS gap_payins,
        a.pre_payouts, 
        b.post_payouts, 
        (COALESCE(a.pre_payouts, 0) - COALESCE(b.post_payouts, 0)) AS gap_payouts,
        a.pre_deposit_payins, 
        b.post_deposit_payins, 
        (COALESCE(a.pre_deposit_payins, 0) - COALESCE(b.post_deposit_payins, 0)) AS gap_deposit_payins,
        a.pre_deposit_refunds, 
        b.post_deposit_refunds,
        (COALESCE(a.pre_deposit_refunds, 0) - COALESCE(b.post_deposit_refunds, 0)) AS gap_deposit_refunds,
        a.contract_start_date, 
        a.contract_end_date, 
        a.contract_status
    FROM pre_payments a
    LEFT JOIN post_payments b 
        ON a.drn = b.drn 
        AND a.payment_date = b."day"
)
SELECT * 
FROM comparison 
WHERE gap_payins <> 0 
   OR gap_payouts <> 0 
   OR gap_deposit_payins <> 0 
   OR gap_deposit_refunds <> 0
ORDER BY country_code, input_day;




----INEFFECTIVE DAYS----
---is_effective_day = true | 1 means driver should be charged. False | 0 means driver has a reason not to be charged---
WITH pre_effective_days_all AS (
    SELECT 
        y.country, 
        y.drn, 
        a.date, 
        a.applied_rule_codes,
        CASE WHEN a.is_effective_day = TRUE THEN 1 ELSE 0 END AS effective_days,
        z.start_date AS contract_start_date, 
        z.end_date AS contract_end_date, 
        z.status AS contract_status
    FROM core_dimensions.fact_effective_days a
    INNER JOIN core_dimensions.dim_driver y 
        ON a.driver_sk = y.driver_sk
        AND y.country IN ('South Africa', 'Ghana', 'Colombia', 'Mexico')
    LEFT JOIN core_dimensions.fact_contract_daily z 
        ON a.driver_sk = z.driver_sk 
        AND a.date = z.date
    WHERE a.date BETWEEN '2026-08-24' AND '2026-08-30'
),
post_effective_days_all AS (
    SELECT 
        country, 
        day, 
        uber_id, 
        drn, 
        effective_days
    FROM core_dimensions.fact_recon_daily_draft
    WHERE day BETWEEN '2026-08-24' AND '2026-08-30'
),
comparison AS (
    SELECT 
        a.country, 
        a.date AS input_day, 
        b.day AS recon_day, 
        b.uber_id, 
        a.drn,
        a.effective_days AS pre_effective_days,
        b.effective_days AS post_effective_days,
        (COALESCE(a.effective_days, 0) - COALESCE(b.effective_days, 0)) AS gap_effective_days,
        a.contract_start_date, 
        a.contract_end_date, 
        a.contract_status
    FROM pre_effective_days_all a
    LEFT JOIN post_effective_days_all b 
        ON a.drn = b.drn 
        AND a.date = b."day"
)
SELECT * 
FROM comparison 
WHERE gap_effective_days <> 0
ORDER BY country, drn, input_day;



----ADJUSTMENTS----
WITH pre_adjustments AS (
    SELECT 
        a.driver_sk, 
        a.country_code, 
        a.adjustment_date, 
        a.drn, 
        SUM(a.adjusted_days) AS adjusted_days, 
        b.net_remittance, 
        ROUND(
        (COALESCE((b.net_remittance / 6.0) * SUM(a.adjusted_days), 0)) 
        + coalesce(sum(a.amount)),
        2) AS adjustment_amount, 
        b.start_date AS contract_start_date, 
        b.end_date AS contract_end_date, 
        b.status AS contract_status
    FROM core_dimensions.fact_recon_adjustments_breakdown a
    LEFT JOIN core_dimensions.fact_contract_daily b
        ON a.driver_sk = b.driver_sk
        AND a.adjustment_date = b.date
    WHERE a.adjustment_date BETWEEN '2026-08-24' AND '2026-08-30'
    GROUP BY 
        a.driver_sk, 
        a.country_code, 
        a.adjustment_date, 
        a.drn, 
        b.net_remittance, 
        b.start_date, 
        b.end_date, 
        b.status
),
post_adjustments AS (
    SELECT 
        country, 
        day, 
        uber_id, 
        drn, 
        adjustments
    FROM core_dimensions.fact_recon_daily_draft
    WHERE day BETWEEN '2026-08-24' AND '2026-08-30'
),
comparison AS (
    SELECT 
        a.country_code, 
        a.adjustment_date AS input_day, 
        b.day AS recon_day, 
        b.uber_id, 
        a.drn, 
        a.adjusted_days,
        a.adjustment_amount AS pre_adjustments, 
        b.adjustments AS post_adjustments,
        (COALESCE(a.adjustment_amount, 0) - COALESCE(b.adjustments, 0)) AS gap_adjustments,
        a.contract_start_date, 
        a.contract_end_date, 
        a.contract_status
    FROM pre_adjustments a
    LEFT JOIN post_adjustments b
        ON a.drn = b.drn 
        AND a.adjustment_date = b."day"
)
SELECT * 
FROM comparison 
WHERE gap_adjustments <> 0
ORDER BY country_code, input_day;




