
-----Validating & Updating the New Auto-recon Checks----

----CHECK 1: Do we have complete Org IDs?----
----Compare Daily and Weekly Transansaction Ids to Find the Org_IDs with Missing Weekly Transaction IDs--------
select daily_org_id, count(distinct daily_duuid), sum(daily_net_earnings) ---daily_duuid, daily_net_earnings ---
from (
select
a.transactionuuid as daily_transactionuuid,
a.driveruuid as daily_duuid,
a.paidtoyou__yourearnings as daily_net_earnings,
a.source_file_date as daily_source_file_date,
a.org_id as daily_org_id,
b.transactionuuid as weekly_transactionuuid,
-- b.net_earnings as weekly_net_earnings,
b.source_file_date as weekly_source_file_date
from
partners_data_daily.mv_uber_harmonized_payments_order  a left join
partners_data_weekly.mv_uber_harmonized_payments_order  b
on a.transactionuuid = b.transactionuuid
where b.transactionuuid is null and a.source_file_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week
and lower(a.country) in ('colombia', 'mexico'))
--group by daily_org_id
order by 1,2;



--CHECK 2 - Driver opening balance is 0 for DRN first day-------- 
with output as (
select * from recon.daily_recon_output dro where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
),
opening_balance_check as (select drn, week,day, contract_start_date, contract_end_date,driver_opening_balance,
    case 
    when contract_start_date > day and driver_opening_balance != 0 THEN 'fail'
      else 'ok'
      end as opening_balance_check
from output
order by drn, week, day asc)
select * from opening_balance_check where opening_balance_check = 'fail';



----Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon.daily_recon_output
    WHERE week < (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, min(day) as min_day
    FROM recon.daily_recon_output
    WHERE week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.driver_closing_balance as previous_last_driver_closing_balance, a.driver_opening_balance as this_week_driver_opening_balance,
    case 
        when b.driver_closing_balance = a.driver_opening_balance then 'ok'
        else 'fail'
    end as  balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;



--CHECK 4 - Total Week Effective Days is not greater than 7-------- 
with output as (
select drn, week, sum(effective_days)as week_effective_days 
	from recon.daily_recon_output 
	where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
group by drn, week
),
effective_days_check as (select drn, week, week_effective_days,
    case 
    when week_effective_days > 7 THEN 'fail'
      else 'ok'
      end as effective_days_check
from output
order by drn, week asc)
select * from effective_days_check where effective_days_check = 'fail';


--CHECK 5 - Ensure Opening Balance + Cash Flow = Closing Balance-------- 
with output as (
select day, drn, NVL(driver_opening_balance,0.0) as driver_opening_balance, NVL(net_earnings_post_partner_adjustments,0.0) as net_earnings_post_partner_adjustments, 
NVL(taxes,0.0) as taxes, NVL(driver_remit_for_the_period,0.0) as driver_remit_for_the_period, NVL(additional_charges,0.0) as additional_charges, 
NVL(adjustments,0) as adjustments, NVL(driver_discounts,0)as driver_discounts, NVL(payments,0.0) as payments, NVL(driver_closing_balance,0.0) as driver_closing_balance,
(NVL(driver_opening_balance,0.0) + (NVL(net_earnings_post_partner_adjustments,0.0) + NVL(taxes,0.0)+ NVL(driver_remit_for_the_period,0.0) + 
NVL(additional_charges,0.0) + NVL(adjustments,0) + NVL(driver_discounts,0) + NVL(payments,0.0) )) as check_driver_closing_balance
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
),
op_cashflow_check as (select day, drn, driver_opening_balance, net_earnings_post_partner_adjustments, taxes,
	driver_remit_for_the_period, additional_charges, adjustments, driver_discounts, payments, driver_closing_balance,check_driver_closing_balance,
    case 
    when ROUND((NVL(driver_opening_balance,0.0) + (NVL(net_earnings_post_partner_adjustments,0.0) + NVL(taxes,0.0)+ NVL(driver_remit_for_the_period,0.0) + 
    NVL(additional_charges,0.0) + NVL(adjustments,0) + NVL(driver_discounts,0) + NVL(payments,0.0) )),2) != ROUND(NVL(driver_closing_balance,0.0),2) THEN 'fail'
      else 'ok'
      end as op_cashflow_check
from output
order by day, drn desc)
select * from op_cashflow_check where op_cashflow_check = 'fail';



----CHECK 6  ---ODI Input vs Applied Inputs on Recon--------------
with driver_list as (
select drn, country, uber_id, DATE(week)week, DATE(day)as day,registration_no, assignment_start_date, assignment_end_date
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
), 
----AUTO RECON----
main_recon_output AS (
  SELECT
    country, drn, uber_id, week, day, registration_no,
    SUM(JSON_EXTRACT_PATH_TEXT(net_earnings_post_partner_adjustments_breakdown, 'gross_fare')::float) as gross_fare,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')) as dynamic_pricing_discount,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'onboarding_discount')::float) as moove_subsidies,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'driver_days_off')) as driver_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'vehicle_days_off')) as vehicle_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'extra_charges')::float) as extra_charges,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'passthrough_costs')::float) as passthrough_costs,
    SUM(adjustments) AS adjustments,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float) as payouts
    FROM recon.daily_recon_output 
    WHERE week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
  GROUP BY country, drn, uber_id, week, day, registration_no ),
  uber_perf AS (
  SELECT drn, date, duuid, SUM(gross_fare) AS ODI_gross_fare
  FROM dbt.latam_recon__uber_payments_data   ----reconciliation_data.recon_inputs__uber_payments
  WHERE date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week ---AND lower(country_code) = 'colombia')
  group by drn, date, duuid),
vehicle_days_off AS (
  SELECT vehicle_days_off_reg_no, vehicle_days_off_date, SUM(source_vehicle_days_off) AS ODI_total_vehicle_days_off
  FROM reconciliation_data.recon_inputs__vehicle_days_off
  WHERE vehicle_days_off_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week --AND lower(country_code) = 'colombia')
  group by vehicle_days_off_reg_no, vehicle_days_off_date),
driver_days_off AS (
  SELECT drn, driver_days_off_date, SUM(driver_days_off) AS ODI_days_off
  FROM reconciliation_data.recon_inputs__driver_days_off
  WHERE driver_days_off_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week --AND lower(country_code) = 'colombia')
  group by drn, driver_days_off_date),
dynamic_pricing AS (
  SELECT drn, dynamic_price_discount_date, SUM(dynamic_pricing_discount) AS Source_dynamic
  FROM reconciliation_data.recon_inputs__dynamic_pricing
  WHERE dynamic_price_discount_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week --AND lower(country_code) = 'colombia')
  group by drn, dynamic_price_discount_date),
extra_charges AS (
  select drn, extra_charges_date,
    SUM(extra_charges) AS ODI_extra_charges,
    SUM(passthrough_costs) AS ODI_passthrough_costs
  FROM reconciliation_data.recon_inputs__extra_charges
  WHERE extra_charges_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week  --AND lower(country_code) = 'colombia')
  group by drn, extra_charges_date),
adjustments AS (
  SELECT drn, adjustment_date, SUM(adjustment_amount) AS ODI_adjustments
  FROM reconciliation_data.recon_inputs__adjustments
  WHERE adjustment_date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week --AND lower(country_code) = 'colombia')
  group by drn, adjustment_date),
payments AS (
  select drn, date,
    SUM(payins) AS ODI_payins,
    SUM(payouts) AS ODI_payouts
  FROM reconciliation_data.recon_inputs__payments
  WHERE date between (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) --Monday date of last week 
and (CURRENT_DATE - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7) - INTERVAL '1 day')   ---Sunday date of last week --AND lower(country_code) = 'colombia')
  group by drn, date),
output as (
select 
dl.country, dl.week, dl.day, dl.drn, dl.registration_no, dl.assignment_start_date, dl.assignment_end_date,
  -- Gross Fare
  NVL(m.gross_fare::float, 0.0) as gross_fare,
  NVL(u.ODI_gross_fare::float,0.0) as ODI_gross_fare,
  NVL((ROUND(NVL(m.gross_fare::float,0.0),2) - ROUND(NVL(u.ODI_gross_fare::float,0.0),2))::float,0.0) AS  diff_gross_fare,
  -- Dynamic Discount
  NVL(m.dynamic_pricing_discount::float,0.0) as dynamic_pricing_discount,
  NVL(dp.Source_dynamic::float,0.0) as source_dynamic_pricing_discount,
  NVL((ROUND(NVL(m.dynamic_pricing_discount::float,0.0),2) - ROUND(NVL(dp.Source_dynamic::float,0.0),2))::float,0.0) AS diff_dynamic,
  -- Driver Days Off
  NVL(m.driver_days_off::float,0.0) as days_off,
  NVL(ddf.ODI_days_off::float,0.0) as ODI_days_off,
  NVL((ROUND(NVL(m.driver_days_off::float,0.0),2) - ROUND(NVL(ddf.ODI_days_off::float,0.0),2))::float,0.0) AS diff_days_off,
  -- Vehicle Status Days Off
  NVL(m.vehicle_days_off::float,0.0) as vehicle_days_off,
  NVL(vdf.ODI_total_vehicle_days_off::float,0.0) as ODI_total_vehicle_days_off,
  NVL((ROUND(NVL(m.vehicle_days_off::float,0.0),2) - ROUND(NVL(vdf.ODI_total_vehicle_days_off::float,0.0),2))::float,0.0) AS diff_vehicle_days_off,
  -- Extra Charges
  NVL(m.extra_charges::float,0.0) as extra_charges,
  NVL(e.ODI_extra_charges::float,0.0) as ODI_extra_charges,
  NVL((ROUND(NVL(m.extra_charges::float,0.0),2) - ROUND(NVL(e.ODI_extra_charges::float,0.0),2))::float,0.0) AS diff_extra_charges,
  -- Passthrough Costs
  NVL(m.passthrough_costs::float,0.0) as passthrough_costs,
  NVL(e.ODI_passthrough_costs::float,0.0) as ODI_passthrough_costs,
  NVL((ROUND(NVL(m.passthrough_costs::float,0.0),2) - ROUND(NVL(e.ODI_passthrough_costs::float,0.0),2))::float,0.0) AS diff_passthrough_costs,
  -- Adjustments
  NVL(m.adjustments::float,0.0) as adjustments,
  NVL(a.ODI_adjustments::float,0.0) as ODI_adjustments,
  NVL((ROUND(NVL(m.adjustments::float,0.0),2) - ROUND(NVL(a.ODI_adjustments::float,0.0),2))::float,0.0) AS diff_adjustments,
  -- Payins
  NVL(m.payins::float,0.0) as payins,
  NVL(p.ODI_payins::float,0.0) as ODI_payins,
  NVL((ROUND(NVL(m.payins::float,0.0),2) - ROUND(NVL(p.ODI_payins::float,0.0),2))::float,0.0) AS diff_payins,
  -- Payouts
  NVL(m.payouts::float,0.0) as payouts,
  NVL(p.ODI_payouts::float,0.0) as ODI_payouts,
  NVL((ROUND(NVL(m.payouts::float,0.0),2) - ROUND(NVL(p.ODI_payouts::float,0.0),2))::float,0.0) AS diff_payouts
FROM driver_list dl
left join main_recon_output m on dl.drn = m.drn and DATE(dl.day) = DATE(m.day)
LEFT JOIN uber_perf u on dl.uber_id = u.duuid and DATE(dl.day) = DATE(u.date)
LEFT JOIN driver_days_off ddf on dl.drn = ddf.drn and DATE(dl.day) = DATE(ddf.driver_days_off_date)
LEFT JOIN vehicle_days_off vdf on dl.registration_no = vdf.vehicle_days_off_reg_no and DATE(dl.day) = DATE(vdf.vehicle_days_off_date)
LEFT JOIN dynamic_pricing dp on dl.drn = dp.drn and DATE(dl.day) = DATE(dp.dynamic_price_discount_date)
LEFT JOIN extra_charges e on dl.drn = e.drn and DATE(dl.day) = DATE(e.extra_charges_date)
LEFT JOIN adjustments a on dl.drn = a.drn and DATE(dl.day) = DATE(a.adjustment_date)
LEFT JOIN payments p on dl.drn = p.drn and DATE(dl.day) = DATE(p.date)
),
output_diff as (
select country, week, day, drn, registration_no, assignment_start_date, assignment_end_date,
case
	when assignment_end_date is not null or assignment_end_date <= day then 'churned driver'
	else 'active driver'
end as driver_status,
case 
	when SUM(diff_gross_fare) != 0 then 'fail'
	else 'ok'
	end as gross_fare_check,
case
	when SUM(diff_dynamic) != 0 then 'fail'
	else 'ok'
	end as dynamic_pricing_discount_check,
case
	when SUM(diff_days_off) != 0 then 'fail'
	else 'ok'
	end as days_off_check,
case
	when SUM(diff_vehicle_days_off) != 0 then 'fail'
	else 'ok'
	end as vehicle_days_off_check,
case
	when SUM(diff_extra_charges) != 0 then 'fail'
	else 'ok'
	end as extra_charges_check,
case
	when SUM(diff_passthrough_costs) != 0 then 'fail'
	else 'ok'
	end as passthrough_costs_check,
case
	when SUM(diff_adjustments) != 0 then 'fail'
	else 'ok'
	end as adjustments_check,
case
	when SUM(diff_payins) != 0 then 'fail'
	else 'ok'
	end as payins_check,
case
	when SUM(diff_payouts) != 0 then 'fail'
	else 'ok'
	end as payouts_check
from output
group by country, week, day, drn, registration_no, assignment_start_date, assignment_end_date
) --select * from output where drn = 'MVMX00125';
select * from output_diff ----where lower(country) = 'mexico' 
order by day, drn desc; 



--CHECK 7: Trips & No Earnings----
with output as (
select drn, week, sum(trips)as week_trips, sum(net_earnings_post_partner_adjustments)as week_earnings 
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
group by drn, week
),
trips_no_earnings_check as (select drn, week, week_trips, week_earnings,
    case 
    when week_trips > 0 and week_earnings <= 0 THEN 'fail'
      else 'ok'
      end as trips_no_earnings_check
from output
order by drn, week asc)
select * from trips_no_earnings_check where trips_no_earnings_check = 'fail';



--CHECK 8: Earnings & No Trips----
with output as (
select drn, week, country, sum(trips)as week_trips, sum(net_earnings_post_partner_adjustments)as week_earnings 
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
group by drn, week, country
),
earnings_no_trips_check as (select drn, week, week_trips, week_earnings,
    case 
    when week_earnings > 0 and week_trips <= 0 THEN 'fail'
      else 'ok'
      end as earnings_no_trips_check
from output
order by drn, week, country asc)
select * from earnings_no_trips_check where earnings_no_trips_check = 'fail';





--CHECK 9: Opening Balance <> Payout ----
----I'm using FLOOR as the payout amount with the decimals does not exactly match the opening balance-----
with output as (
select drn, week, country, NVL(SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float),0.0) as payouts
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
group by drn, week,country
),
week_earliest_op as (
select r.drn, r.week, r.day, NVL(r.driver_opening_balance,0.0) as driver_opening_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, min(day) as min_day
    FROM recon.daily_recon_output
    WHERE week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
order by drn
),
op_payout_check as (select o.drn, o.week, o.country, FLOOR(op.driver_opening_balance)driver_opening_balance, FLOOR(ABS(o.payouts))payouts,
    case 
    when ROUND(op.driver_opening_balance,2) > 0 and FLOOR(op.driver_opening_balance) != FLOOR(ABS(o.payouts)) THEN 'fail'
      else 'ok'
      end as opening_balance_payout_check
from output o join week_earliest_op op
on o.drn = op.drn and o.week = op.week
order by drn, week, country asc)
select * from op_payout_check where opening_balance_payout_check = 'fail';




--CHECK 10 - If driver is churned then effective days equals 0 -------- 
with output as (
select drn, week, day, contract_start_date, contract_end_date, effective_days 
	from recon.daily_recon_output 
	where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
),
churned_driver_effective_days_check as (select drn, week, day, contract_start_date,contract_end_date, effective_days,
    case 
    when contract_end_date <= day AND effective_days != 0 THEN 'fail'
      else 'ok'
      end as churned_driver_effective_days_check
from output
order by drn, week asc)
select * from churned_driver_effective_days_check where churned_driver_effective_days_check = 'fail';



--CHECK 11 - Duplicate DRNs in Reconciliation -------- 
with output as (
select country, week, day, drn, count(drn)drn_count
from recon.daily_recon_output where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7))
group by country, week, day, drn
),
duplicate_drn_check as (select country, week, day, drn,
    case 
    when drn_count > 1 THEN 'fail'
      else 'ok'
      end as duplicate_drn_check
from output
order by country, week, day, drn desc)
select * from duplicate_drn_check where duplicate_drn_check = 'fail';








