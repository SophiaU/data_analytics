----------------------------------------------------
---======PRE-CHECKS BEFORE RECON RUNS=====----

--ONE--
----Checking for missing Org ids - DAILY vs WEEKLY---
WITH missing_transactions AS (
    SELECT weekly.org_id
         , weekly.vsreporting
         , weekly.transactionuuid
    FROM partners_data_weekly.mv_uber_harmonized_payments_order weekly
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order daily
                   ON
                       weekly.transactionuuid = daily.transactionuuid
    WHERE daily.transactionuuid IS NULL
      AND weekly.source_file_date >= '2025-07-28'
      AND weekly.vsreporting < (SYSDATE - 1)
)
SELECT DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions;



--===TWO===---
---MISISNG ORG IDS ON PAYMENT DATA---
WITH missing_ORGID AS (
    SELECT previous.org_id
         , previous.source_file_date as previous_day_date
         , yesterday.source_file_date as yesterday_day_date
    FROM (select * from partners_data_daily.mv_uber_harmonized_payments_order
    where source_file_date = '2025-08-07' ---between '2025-08-06' and '2025-08-06'
    ) previous
         LEFT JOIN (select * from partners_data_daily.mv_uber_harmonized_payments_order
         where source_file_date = '2025-08-08') yesterday
                   ON
                       previous.org_id = yesterday.org_id
    WHERE yesterday.org_id IS NULL
)
SELECT DISTINCT org_id, previous_day_date, yesterday_day_date
FROM missing_ORGID
order by previous_day_date,org_id desc;



---MISISNG ORG IDS ON DRIVER QUALITY DATA---
WITH missing_ORGID AS (
    SELECT previous.org_id
         , previous.source_file_date as previous_day_date
         , yesterday.source_file_date as yesterday_day_date
    FROM (select * from partners_data_daily.mv_uber_harmonized_driver_quality
    where source_file_date = '2025-08-07' ---between '2025-08-06' and '2025-08-07'
    ) previous
         LEFT JOIN (select * from partners_data_daily.mv_uber_harmonized_driver_quality 
         where source_file_date = '2025-08-08') yesterday
                   ON
                       previous.org_id = yesterday.org_id
    WHERE yesterday.org_id IS NULL
      --AND yesterday.source_file_date = '2025-08-08'
      --AND previous.vsreporting < (SYSDATE - 1)
)
SELECT DISTINCT org_id, previous_day_date, yesterday_day_date
FROM missing_ORGID
order by previous_day_date,org_id desc;


---MISISNG ORG IDS ON DRIVER ACTIVITY DATA---
WITH missing_ORGID AS (
    SELECT previous.org_id
         , previous.source_file_date as previous_day_date
         , yesterday.source_file_date as yesterday_day_date
    FROM (select * from partners_data_daily.mv_uber_harmonized_driver_activity
    where source_file_date = '2025-08-07'  ----between '2025-08-06' and '2025-08-07'
    ) previous
         LEFT JOIN (select * from partners_data_daily.mv_uber_harmonized_driver_activity
         where source_file_date = '2025-08-08') yesterday
                   ON
                       previous.org_id = yesterday.org_id
    WHERE yesterday.org_id IS NULL
)
SELECT DISTINCT org_id, previous_day_date, yesterday_day_date
FROM missing_ORGID
order by previous_day_date,org_id desc;




--===THREE===---
----CHECK FOR PAYMENT TRANSANCTION IDS COUNT TREND----
---This will help you know when to be concerned about an org id have little to no transactions--
select distinct org_id,source_file_date,count(transactionuuid)transactionuuid
from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date >= '2025-08-01'
and org_id like '%NGA%'
group by org_id, source_file_date
order by org_id, source_file_date desc;



--===FOUR===---
--Confirming available Uber data for the day---
select * from partners_data_daily.mv_uber_harmonized_payments_order
where source_file_date = '2025-08-08'
and lower(country) = 'nigeria' limit 200;

select * from partners_data_daily.mv_uber_harmonized_payments_order
where source_file_date = '2025-08-08'
and lower(country) = 'ghana' limit 200;



--===FIVE===---
---Confirming recon data now present in the Table--- 
select * from recon_nigeria.reconciliation_spresso
where day = '2025-08-08'; 

select * from recon_nigeria.reconciliation_alto
where day = '2025-08-08'; 

select * from recon_ghana.reconciliation
where day = '2025-08-08';

select * from recon_india.daily_reconciliation
where day = '2025-08-08';




--===SIX===---
---Confirm the daily Uber data trend ----Extend to other metrics---
---NG SPRESSO--
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_nigeria.reconciliation_spresso
group by day 
order by day desc;


---NG ALTOS---
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_nigeria.reconciliation_alto
group by day 
order by day desc;


---GHANA---
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_ghana.reconciliation
--where day = '2025-08-03'  ---drn = 'MVG10347' and 
group by day 
order by day desc;






------------------------------------------------------------------
----August 14 2025---

----===Checking for missing transaction ids - WEEKLY vs DAILY====---
WITH missing_transactions AS (
    SELECT weekly.org_id
         , weekly.vsreporting
         , weekly.transactionuuid
    FROM partners_data_weekly.mv_uber_harmonized_payments_order weekly
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order daily
                   ON
                       weekly.transactionuuid = daily.transactionuuid
    WHERE daily.transactionuuid IS NULL
      AND weekly.source_file_date >= '2025-08-04'
      AND weekly.vsreporting < (SYSDATE - 1)
)
SELECT *---DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions


---------------------------------------------------------------------------------------
--====Compare Count of Transanction IDs on Weekly vs Daily: Week of Aug 4===----

---====COUNT OF TRANSACTION IDS BY ORG IDS FOR DAILY UBER DATA====----
---DAILY----
----CHECK FOR PAYMENT TRANSANCTION IDS COUNT TREND----
---This will help you know when to be concerned about an org id have little to no transactions--
select distinct org_id,to_date(vsreporting, 'yyyy-mm-dd'), count(transactionuuid)transactionuuid
from partners_data_daily.mv_uber_harmonized_payments_order where to_date(vsreporting, 'yyyy-mm-dd') = '2025-08-09'
and org_id like '%GHA%'
group by 1,2
order by org_id desc;


---====COUNT OF TRANSACTION IDS BY ORG IDS FOR WEEKLY UBER DATA====----
----WEEKLY---
----CHECK FOR PAYMENT TRANSANCTION IDS COUNT TREND----
---This will help you know when to be concerned about an org id have little to no transactions--
select distinct org_id,source_file_date,to_date(vsreporting, 'yyyy-mm-dd'), count(transactionuuid)transactionuuid
from partners_data_weekly.mv_uber_harmonized_payments_order where to_date(vsreporting, 'yyyy-mm-dd') = '2025-08-09'
and org_id like '%GHA%'
group by 1,2,3
order by org_id, source_file_date desc;
---------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------
--====Compare Count of Transanction IDs on Weekly vs Daily: Week of Jul 28====----
---====COUNT OF TRANSACTION IDS BY ORG IDS FOR DAILY UBER DATA====----
---DAILY----
----CHECK FOR PAYMENT TRANSANCTION IDS COUNT TREND----
---This will help you know when to be concerned about an org id have little to no transactions--
select distinct org_id,to_date(vsreporting, 'yyyy-mm-dd'), count(transactionuuid)transactionuuid
from partners_data_daily.mv_uber_harmonized_payments_order where to_date(vsreporting, 'yyyy-mm-dd') between '2025-07-28' and '2025-08-03'
and org_id like '%GHA%'
group by 1,2
order by 2,1;


---====COUNT OF TRANSACTION IDS BY ORG IDS FOR DAILY UBER DATA====----
----WEEKLY---
----CHECK FOR PAYMENT TRANSANCTION IDS COUNT TREND----
---This will help you know when to be concerned about an org id have little to no transactions--
select distinct org_id,to_date(vsreporting, 'yyyy-mm-dd'), count(transactionuuid)transactionuuid
from partners_data_weekly.mv_uber_harmonized_payments_order where to_date(vsreporting, 'yyyy-mm-dd') between '2025-07-28' and '2025-08-03'
and org_id like '%GHA%'
group by 1,2
order by org_id;
---------------------------------------------------------------------------------------



------------------------------------------------------
---Additional Checks for Missing Org IDs within daily & weekly files----
--ONE--
---Checks for missing org ids within the weekly file---
WITH processing_dates AS (
    SELECT DISTINCT source_file_date AS processing_date
    FROM partners_data_weekly.mv_uber_harmonized_payments_order
    WHERE source_file_name LIKE 'payments_order__%'
),
     expected_orgs AS (
         SELECT DISTINCT org_id
         FROM partners_data_weekly.mv_uber_harmonized_payments_order
         WHERE org_id NOT LIKE '%KEN_NBO%'
     ),
     org_first_appearance AS (
         SELECT
             org_id,
             MIN(source_file_date) AS first_appearance_date
         FROM partners_data_weekly.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
           AND org_id NOT LIKE '%KEN_NBO%'
         GROUP BY org_id
     ),
     org_last_appearance AS (
         SELECT
             org_id,
             MAX(source_file_date) AS last_appearance_date
         FROM partners_data_weekly.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
           AND org_id NOT LIKE '%KEN_NBO%'
         GROUP BY org_id
     ),
     expected_combinations AS (
         SELECT
             eo.org_id,
             pd.processing_date,
             'payments_order__' || eo.org_id || '__' || pd.processing_date AS expected_filename
         FROM expected_orgs eo
                  CROSS JOIN processing_dates pd
                  INNER JOIN org_first_appearance ofa ON eo.org_id = ofa.org_id
         WHERE pd.processing_date >= ofa.first_appearance_date
     ),
     existing_files AS (
         SELECT DISTINCT source_file_name
         FROM partners_data_weekly.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
     )
SELECT
    ec.org_id,
    ec.processing_date,
    ec.expected_filename AS missing_file,
    ofa.first_appearance_date,
    ofl.last_appearance_date,
    DATEDIFF(day, ofl.last_appearance_date, CURRENT_DATE) AS days_since_last_appearance
FROM expected_combinations ec
         LEFT JOIN existing_files ef ON ec.expected_filename = ef.source_file_name
         LEFT JOIN org_first_appearance ofa ON ec.org_id = ofa.org_id
         LEFT JOIN org_last_appearance ofl ON ec.org_id = ofl.org_id
WHERE ef.source_file_name IS NULL
ORDER BY ec.processing_date DESC, ec.org_id;



--TWO--
---Checks for missing org ids within the weekly file---
WITH processing_dates AS (
    SELECT DISTINCT source_file_date AS processing_date
    FROM partners_data_daily.mv_uber_harmonized_payments_order
    WHERE source_file_name LIKE 'payments_order__%'
),
     expected_orgs AS (
         SELECT DISTINCT org_id
         FROM partners_data_daily.mv_uber_harmonized_payments_order
         WHERE org_id NOT LIKE '%KEN_NBO%'
     ),
     org_first_appearance AS (
         SELECT
             org_id,
             MIN(source_file_date) AS first_appearance_date
         FROM partners_data_daily.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
           AND org_id NOT LIKE '%KEN_NBO%'
         GROUP BY org_id
     ),
     org_last_appearance AS (
         SELECT
             org_id,
             MAX(source_file_date) AS last_appearance_date
         FROM partners_data_daily.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
           AND org_id NOT LIKE '%KEN_NBO%'
         GROUP BY org_id
     ),
     expected_combinations AS (
         SELECT
             eo.org_id,
             pd.processing_date,
             'payments_order__' || eo.org_id || '__' || pd.processing_date AS expected_filename
         FROM expected_orgs eo
                  CROSS JOIN processing_dates pd
                  INNER JOIN org_first_appearance ofa ON eo.org_id = ofa.org_id
         WHERE pd.processing_date >= ofa.first_appearance_date
     ),
     existing_files AS (
         SELECT DISTINCT source_file_name
         FROM partners_data_daily.mv_uber_harmonized_payments_order
         WHERE source_file_name LIKE 'payments_order__%'
     )
SELECT
    ec.org_id,
    ec.processing_date,
    ec.expected_filename AS missing_file,
    ofa.first_appearance_date,
    ofl.last_appearance_date,
    DATEDIFF(day, ofl.last_appearance_date, CURRENT_DATE) AS days_since_last_appearance
FROM expected_combinations ec
         LEFT JOIN existing_files ef ON ec.expected_filename = ef.source_file_name
         LEFT JOIN org_first_appearance ofa ON ec.org_id = ofa.org_id
         LEFT JOIN org_last_appearance ofl ON ec.org_id = ofl.org_id
WHERE ef.source_file_name IS NULL
ORDER BY ec.processing_date DESC, ec.org_id, days_since_last_appearance;

----------------------------------------------------------------------------------------------






