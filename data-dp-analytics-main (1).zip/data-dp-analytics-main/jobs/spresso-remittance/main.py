"""
Spresso remittance advice loader.

SQL and all transformation logic are unchanged. 
List of things I changed:

  - Colab secrets      -> environment variables
  - auth.authenticate_user() + Drive download of the service account JSON
                       -> service account JSON supplied as an env variable
  - !ssh shell command -> managed subprocess with a readiness check
  - days_back variable -> RUN_DATE env variable (defaults to yesterday)
  - clear-then-write   -> fetch everything first, only touch the sheet once
                          the full dataset is in hand

Required environment variables:
  SSH_PRIVATE_KEY              contents of the .pem used for the tunnel
  REDSHIFT_PASSWORD            password for the read-all user
  GOOGLE_SERVICE_ACCOUNT_JSON  contents of the service account JSON file
Optional:
  RUN_DATE                     YYYY-MM-DD. Defaults to yesterday.
  TRIGGERED_BY                 email of whoever started the run, for the log
"""

import os
import sys
import time
import socket
import datetime
import subprocess
import traceback

import pandas as pd
import psycopg2
import pygsheets

# ---------------------------------------------------------------------------
# Circle CI Configuration.
# ---------------------------------------------------------------------------
import base64
import json as _json

def _trigger_payload():
    """Read the webhook body CircleCI wrote out, if there is one."""
    try:
        with open("/tmp/run_request.json") as f:
            data = _json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception:
        return {}

TRIGGER = _trigger_payload()

# ---------------------------------------------------------------------------
# Configuration.
# ---------------------------------------------------------------------------
SHEET_KEY       = "1RLULkU7f_0Wy-6ISh-a4ICXVnS1txBwcfxaULtp1qA0"            # <-- CHECK: full sheet ID
WORKSHEET_TITLE = "ubergoDTO48SPresso_advice"            # <-- CHECK: test sheet tab
LOG_WORKSHEET   = "Run log"

CONTROL_TAB = "Remittance Date"
CELL_STATUS = "B4"
CELL_TIME   = "B6"

RECON_TABLE  = "reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout"
DATA_START   = (5, 2)        # row 5, column B
CLEAR_FIRST_COL = "B"
CLEAR_LAST_COL  = "AE"
STATUS_CELL  = "A1"          # <-- this cell must be empty in the emails sheet

SSH_HOST  = "sshtunnel.moovedata.io"
SSH_USER  = "google_collab"
SSH_PORT  = "45022"
DB_HOST   = "dwh.moovedata.io"
DB_PORT   = 5439
DB_NAME   = "dev"
DB_USER   = "read-all"

KEY_PATH  = "/tmp/tunnel_key.pem"
SA_PATH   = "/tmp/service_account.json"


def log(msg):
    print(f"[{datetime.datetime.now():%H:%M:%S}] {msg}", flush=True)


# ---------------------------------------------------------------------------
# Inputs
# ---------------------------------------------------------------------------

def resolve_run_date():
    """RUN_DATE if supplied and sane, otherwise yesterday (the old days_back=1)."""
    #raw = os.environ.get("RUN_DATE", "").strip() #github workflow/actions getting the remittance date
    raw = (TRIGGER.get("run_date") or os.environ.get("RUN_DATE", "")).strip() #circeci webhook getting the remittance date
    if not raw:
        d = datetime.date.today() - datetime.timedelta(days=1)
        log(f"RUN_DATE not set, defaulting to yesterday: {d}")
        return d

    try:
        d = datetime.date.fromisoformat(raw)
    except ValueError:
        raise ValueError(f"RUN_DATE '{raw}' is not in YYYY-MM-DD format")

    if d > datetime.date.today():
        raise ValueError(f"RUN_DATE {d} is in the future")
    if d < datetime.date.today() - datetime.timedelta(days=365):
        raise ValueError(f"RUN_DATE {d} is more than a year old, refusing")
    return d


def require_env(name):
    value = os.environ.get(name, "")
    if not value.strip():
        raise RuntimeError(f"Environment variable {name} is missing or empty")
    return value


# ---------------------------------------------------------------------------
# SSH tunnel
# ---------------------------------------------------------------------------

def open_tunnel():
    """Reproducing the porting tunnel ssh -fNL, but waiting until the port is live."""
    # with open(KEY_PATH, "w") as f:
    #     f.write(require_env("SSH_PRIVATE_KEY").strip() + "\n")
    raw = require_env("SSH_PRIVATE_KEY_B64")
    key = base64.b64decode(raw).decode()
    with open(KEY_PATH, "w") as f:
        f.write(key.strip() + "\n")
    os.chmod(KEY_PATH, 0o600)

    cmd = [
        "ssh", "-i", KEY_PATH,
        "-p", SSH_PORT,
        "-o", "StrictHostKeyChecking=no",
        "-o", "UserKnownHostsFile=/dev/null",
        "-o", "ExitOnForwardFailure=yes",
        "-o", "ServerAliveInterval=30",
        "-N",
        "-L", f"127.0.0.1:{DB_PORT}:{DB_HOST}:{DB_PORT}",
        f"{SSH_USER}@{SSH_HOST}",
    ]
    log("Opening SSH tunnel")
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    # Poll the local port instead of guessing with sleep()
    for _ in range(30):
        if proc.poll() is not None:
            err = proc.stderr.read().decode(errors="replace")
            raise RuntimeError(f"SSH tunnel exited immediately: {err.strip()}")
        with socket.socket() as s:
            s.settimeout(1)
            if s.connect_ex(("127.0.0.1", DB_PORT)) == 0:
                log("Tunnel is up")
                return proc
        time.sleep(1)

    proc.terminate()
    raise RuntimeError("SSH tunnel did not come up within 30 seconds")


def close_tunnel(proc):
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            proc.kill()
    if os.path.exists(KEY_PATH):
        os.remove(KEY_PATH)


# ---------------------------------------------------------------------------
# Redshift
# ---------------------------------------------------------------------------

def redshift(query, params=None):
    """helper function, but with parameterised queries."""
    conn = psycopg2.connect(
        host="127.0.0.1",
        port=DB_PORT,
        database=DB_NAME,
        user=DB_USER,
        password=require_env("REDSHIFT_PASSWORD"),
        connect_timeout=60,
    )
    try:
        return pd.read_sql(query, conn, params=params)
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Transformations. notebook logic, unchanged except where noted with "FIX".
# ---------------------------------------------------------------------------

def build_remittance(run_date):
    date_str = run_date.strftime("%Y-%m-%d")

    log(f"Querying {RECON_TABLE} for {date_str}")
    db_recon = redshift(
        f"SELECT * FROM {RECON_TABLE} WHERE day = %s",
        params=(date_str,),
    )
    log(f"Recon rows returned: {len(db_recon)}")

    if db_recon.empty:
        raise ValueError(
            f"No reconciliation rows for {date_str}. "
            "The sheet has been left untouched."
        )

    db_recon["day"] = pd.to_datetime(db_recon.day, format="%Y-%m-%d").apply(
        lambda x: datetime.datetime.strftime(x, format="%d/%m/%Y"))
    db_recon["week"] = pd.to_datetime(db_recon["week"], format="%Y-%m-%d").apply(
        lambda x: datetime.datetime.strftime(x, format="%d/%m/%Y"))

    db_recon["product"] = db_recon["product"].apply(
        lambda x: "Drive-To-Own 48 S-Presso"
        if str(x).strip() == "UberGo DTO 48 [S-Presso]"
        else " Drive-To-Own 28 S-Presso"
        if str(x).strip() == "UberGo_DTO48_[S-Presso]_28Months"
        else "Drive-To-Own 48 S-Presso")

    db_recon["hash1"] = ""
    db_recon["hash2"] = ""

    remittance = db_recon.loc[:, [
        "day", "drn", "uber_name", "vehicle_type", "product", "trips",
        "supply_hours", "acceptance_rate", "net_earnings", "cash_collected",
        "hash1", "uber_balance", "va_amount", "incentives", "payouts",
        "moove_balance", "hash2", "daily_remittance", "extra_charges",
        "prev_outstanding", "amount_due", "cumm_outstanding"]]

    remittance["moove_cares_program_incentive"] = remittance["incentives"]
    remittance["outstanding_balance_at_start_of_moove_cares_program"] = 0.0
    remittance["change_in_ balance_ since_program_started"] = 0.0
    remittance["final_cumm_outstanding"] = remittance["cumm_outstanding"].apply(
        lambda x: 0 if x < 0 else round(x, 2))
    remittance["income_payable"] = remittance["cumm_outstanding"].apply(
        lambda x: -x if x < -500 else 0)
    remittance["other_incentives"] = (
        remittance["incentives"] - remittance["moove_cares_program_incentive"])
    remittance["june_economic_relief"] = (
        remittance["incentives"] - remittance["moove_cares_program_incentive"])

    remittance["acceptance_rate"] = 0.00
    remittance["vehicle_type"] = "Suzuki S-Presso"

    numeric_cols = remittance.select_dtypes(include="number").columns
    remittance[numeric_cols] = remittance[numeric_cols].round(2)
    for col in remittance.columns:
        if col in numeric_cols:
            remittance[col] = remittance[col].apply(lambda x: f"{x:.2f}")
        else:
            remittance[col] = remittance[col].astype(str)

    # --- emails -------------------------------------------------------------
    log("Querying driver_domain for emails")
    emails_df = redshift("""
        SELECT drn, email
        FROM   dbt.core__driver_domain
        WHERE  drn LIKE '%DRN%'
    """)

    blank = (emails_df["email"].astype(str).str.strip() == "").sum()
    log(f"Drivers with no email on file: {blank} of {len(emails_df)}")

    # FIX: the notebook had .drop(0) here;- this left over from when the emails data came
    # from a Google Sheet whose first row was a header. Coming from Redshift,
    # row 0 is a real driver, so .drop(0) silently deleted one driver's email
    # on every run. 
    # Removed.
    emails_df = emails_df[emails_df["drn"].astype(str).str.strip() != ""]
    email_map = dict(zip(emails_df["drn"], emails_df["email"]))

    if "email" not in remittance.columns:
        remittance.insert(0, "email", remittance.drn.map(email_map))

    missing = remittance["email"].isna().sum()
    if missing:
        log(f"WARNING: {missing} rows have no matching email")

    remittance.sort_values("uber_name", inplace=True)
    remittance = remittance.drop_duplicates().reset_index(drop=True)

    log(f"Final remittance shape: {remittance.shape}")
    return remittance


# ---------------------------------------------------------------------------
# Sheets
# ---------------------------------------------------------------------------

def sheets_client():
    raw = base64.b64decode(require_env("GOOGLE_SERVICE_ACCOUNT_JSON_B64")).decode()
    with open(SA_PATH, "w") as f:
        f.write(raw)
    os.chmod(SA_PATH, 0o600)
    return pygsheets.authorize(service_account_file=SA_PATH)


def set_status(ws, text):
    try:
        ws.update_value(STATUS_CELL, text)
    except Exception:
        log(f"Could not write status cell: {text}")

def set_request_status(gc, value):
    """Release the claim. Must never affect the run's outcome."""
    try:
        ctl = gc.open_by_key(SHEET_KEY).worksheet_by_title(CONTROL_TAB)
        ctl.update_value(CELL_STATUS, value)
        ctl.update_value(CELL_TIME, now_iso())
    except Exception:
        log(f"Could not set request status to {value}")

def write_to_sheet(gc, remittance, run_date, triggered_by):
    sh = gc.open_by_key(SHEET_KEY)
    ws = sh.worksheet_by_title(WORKSHEET_TITLE)

    stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    set_status(ws, f"RUNNING - do not share - started {stamp}")

    df_rows = remittance.shape[0]
    sheet_rows = ws.rows
    original_sheet_rows = sheet_rows

    if sheet_rows < df_rows:
        ws.add_rows(df_rows - sheet_rows)
    elif sheet_rows > df_rows and df_rows > 0:
        start_row = df_rows + 1
        if start_row <= sheet_rows:
            ws.delete_rows(start_row, sheet_rows - df_rows)

    log("Clearing old data")
    ws.clear(
        start=f"{CLEAR_FIRST_COL}5",
        end=f"{CLEAR_LAST_COL}{original_sheet_rows}",
    )

    log("Writing new data")
    ws.set_dataframe(remittance, DATA_START, copy_head=False, nan="")

    set_status(ws, (
        f"READY - {run_date:%d/%m/%Y} - {df_rows} rows - "
        f"run by {triggered_by} at {stamp}"
    ))
    log(">>> Remittance advice loaded successfully <<<")
    return df_rows


def append_run_log(gc, run_date, triggered_by, status, detail):
    """Best effort. Must never change the outcome of the run."""
    try:
        sh = gc.open_by_key(SHEET_KEY)
        try:
            ws = sh.worksheet_by_title(LOG_WORKSHEET)
        except Exception:
            ws = sh.add_worksheet(LOG_WORKSHEET, rows=1000, cols=6)
            ws.update_row(1, ["timestamp", "triggered_by", "run_date",
                              "status", "detail"])

        row = [
            datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            triggered_by,
            run_date.strftime("%Y-%m-%d") if run_date else "",
            status,
            str(detail)[:500],
        ]

        # First empty row in column A, growing the sheet if needed.
        col_a = ws.get_col(1, include_tailing_empty=False)
        target = len(col_a) + 1
        if target > ws.rows:
            ws.add_rows(target - ws.rows + 10)
        ws.update_row(target, row)

    except Exception:
        log("Could not append to run log")
        traceback.print_exc()


# ---------------------------------------------------------------------------

def main():
    #triggered_by = os.environ.get("TRIGGERED_BY", "scheduled") #github action source
    triggered_by = TRIGGER.get("triggered_by") or os.environ.get("TRIGGERED_BY", "scheduled") #circleCI source
    run_date = resolve_run_date()
    tunnel = None
    gc = None

    try:
        gc = sheets_client()
        tunnel = open_tunnel()

        # Bit to ensure Everything that can fail happens before the sheet is touched.
        remittance = build_remittance(run_date)

        rows = write_to_sheet(gc, remittance, run_date, triggered_by)
        append_run_log(gc, run_date, triggered_by, "PASS", f"{rows} rows")
        set_request_status(gc, "DONE")
        return 0

    except Exception as exc:
        detail = f"{type(exc).__name__}: {exc}"
        log(f"FAILED: {detail}")
        traceback.print_exc()

        if gc is not None:
            try:
                ws = gc.open_by_key(SHEET_KEY).worksheet_by_title(WORKSHEET_TITLE)
                stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
                set_status(ws, f"FAILED - do not share - {detail} - {stamp}")
            except Exception:
                traceback.print_exc()
            append_run_log(gc, run_date, triggered_by, "FAIL", detail)
            append_run_log(gc, run_date, triggered_by, "FAIL", detail)
            set_request_status(gc, "FAILED")
        return 1

    finally:
        try:
            close_tunnel(tunnel)
        except Exception:
            traceback.print_exc()
        if os.path.exists(SA_PATH):
            os.remove(SA_PATH)


if __name__ == "__main__":
    sys.exit(main())
