----------------------------------------------------------
----June 2ND 2026-----
---HISTORICAL BUNDLED ADJUSTMENTS CLEANUP---
----GHANA---
with base_adjustments as (
select country, recon_week, drn,adjustments, adjustment_type --1st get distinct adjustment_type and dissect/clean
from core_dimensions.mart_driver_weekly_recon--core_dimensions.fact_recon_daily--core_dimensions.mart_driver_weekly_recon
where
    -- Caught by the exclusion filter (contains at least one of types 2-8)
    (adjustment_type ilike  '%Advanced Remit%' or  adjustment_type ilike  '%Agreement of Debt Adjustments%'
        OR adjustment_type ilike  '%Driver Remit Adjustment%'  -- covers for Days, Driver Days Off, Other, Vehicle Assignment, Vehicle Unavailable
    )
    -- But also contains at least one of the non-excluded adjustment types (collateral damage)
    and (adjustment_type ilike  '%Additional Services Adjustment%'
        or adjustment_type ilike  '%Extra Charges Adjustment%'
        or adjustment_type ilike  '%Historical Records Correction%'
        or adjustment_type ilike  '%Impoundment Credit from Uber%'
        or adjustment_type ilike  '%Moove Subsidies Adjustment%'
        or adjustment_type ilike  '%Partner Balance Adjustment%'
        or adjustment_type ilike  '%Passthrough Cost%'           -- covers single/multiple passthrough variant
        or adjustment_type ilike  '%Payments Adjustment%'       -- covers both payin/payout variants
        or adjustment_type ilike  '%Repair Fund%'               -- covers Repayment Adjustment and Settlement
    )
    and lower(country) in ('ghana') and recon_week >= '2026-03-09'
order by recon_week desc),
adjustment_breakdown as (select * from reconciliation_data.adjustments where approval_status = 'Approved' and adjustment_date >= '2026-03-09'),
loanbook as (select *
    from  dbt_emad.mart_driver_paid_to_date  ----core_dimensions.mart_driver_paid_to_date
    where week >= '2026-03-09'
    )
select ba.country, ba.recon_week, ba.drn, ba.adjustments, ba.adjustment_type,lb.adjustment_amount as lb_adjustment_amount, 
lb.adjustment_type as lb_adjustment_type
from base_adjustments ba
join (select drn, week, adjustment_amount,adjustment_type from loanbook) lb
on ba.drn=lb.drn and ba.recon_week=lb.week;



---HISTORICAL BUNDLED ADJUSTMENTS CLEANUP---
----SOUTH AFRICA---
with base_adjustments as (
select country, recon_week, drn,adjustments, adjustment_type --1st get distinct adjustment_type and dissect/clean
from core_dimensions.mart_driver_weekly_recon--core_dimensions.fact_recon_daily--core_dimensions.mart_driver_weekly_recon
where
    -- Caught by the exclusion filter (contains at least one of types 2-8)
    (adjustment_type ilike  '%Advanced Remit%' or  adjustment_type ilike  '%Agreement of Debt Adjustments%'
        OR adjustment_type ilike  '%Driver Remit Adjustment%'  -- covers for Days, Driver Days Off, Other, Vehicle Assignment, Vehicle Unavailable
    )
    -- But also contains at least one of the non-excluded adjustment types (collateral damage)
    and (adjustment_type ilike  '%Additional Services Adjustment%'
        or adjustment_type ilike  '%Extra Charges Adjustment%'
        or adjustment_type ilike  '%Historical Records Correction%'
        or adjustment_type ilike  '%Impoundment Credit from Uber%'
        or adjustment_type ilike  '%Moove Subsidies Adjustment%'
        or adjustment_type ilike  '%Partner Balance Adjustment%'
        or adjustment_type ilike  '%Passthrough Cost%'           -- covers single/multiple passthrough variant
        or adjustment_type ilike  '%Payments Adjustment%'       -- covers both payin/payout variants
        or adjustment_type ilike  '%Repair Fund%'               -- covers Repayment Adjustment and Settlement
    )
    and lower(country) in ('south africa') and recon_week >= '2025-11-03'
order by recon_week desc),
adjustment_breakdown as (select * from reconciliation_data.adjustments where approval_status = 'Approved' and adjustment_date >= '2025-11-03'),
loanbook as (select *
    from  dbt_emad.mart_driver_paid_to_date  ----core_dimensions.mart_driver_paid_to_date
    where week >= '2025-11-03'
    )
select ba.country, ba.recon_week, ba.drn, ba.adjustments, ba.adjustment_type,lb.adjustment_amount as lb_adjustment_amount, 
lb.adjustment_type as lb_adjustment_type
from base_adjustments ba
join (select drn, week, adjustment_amount,adjustment_type from loanbook) lb
on ba.drn=lb.drn and ba.recon_week=lb.week;


-----Check for Last Time Loan Sheet Was in Use---

select week, sum(historical_total_received)historical_total_received
from core_dimensions.mart_driver_paid_to_date
where country = 'Ghana' ---'South Africa'
group by week
order by week;


