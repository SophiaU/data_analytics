-- India recon: daily + historical weekly, combined
--
-- Notes on the date windows:
--   * Weekly recon (recon_india.reconciliation) runs from 2022-07-11. We keep weeks up to
--     2024-01-15, so it covers through 2024-01-21.
--   * Daily recon (recon_india.daily_reconciliation) picks up from 2024-01-22.
--   * 2023-11-01 in the daily table is an opening balance rollup, so it's skipped.
--   * 2023-11-20 to 2024-01-15 in the daily table is the trial period (few rows). Retained.
with daily_recon as (
    select
        'current'                          as source,
        'India'                            as country,
        initcap(city)                      as city,
        week,
        day,
        drn,
        uber_id,
        case when product = 'DTR' then  'DTR' else 'DTO' end as product, 
        vehicle_type,
        case when trim(vehicle_plate) in ('', '0') then null else trim(vehicle_plate) end as vehicle_plate,
        --effective_days,
        case when remittance <> 0 then effective_days else 0 end as effective_days,
        coalesce(refund_and_expenses, 0)   as refund_and_expenses,
        coalesce(tax_credit_from_uber, 0)  as tax_credit_from_uber,
        coalesce(toll, 0)                  as toll,
        coalesce(uber_balance, 0)          as uber_balance,
        coalesce(bank_statement, 0)        as bank_statement,
        coalesce(incentives, 0)            as incentives,
        coalesce(adjustment_amount, 0)     as adjustment_amount,
        coalesce(remittance, 0)            as remittance,
        coalesce(extra_charges, 0)         as extra_charges,
        coalesce(prev_outstanding, 0)      as prev_outstanding,
        coalesce(cum_outstanding, 0)       as cumm_outstanding,
        coalesce(payouts, 0)               as payouts,
        coalesce(payables, 0)              as payables,
        coalesce(va_account, 0)            as va_account,
        -- TDS is India only: 1% of (net earning + refunds + tax credit - remittance), floored at 0
        greatest(
            coalesce(net_earning, 0)
            + coalesce(refund_and_expenses, 0)
            + coalesce(tax_credit_from_uber, 0)
            - coalesce(remittance, 0),
            0
        ) * 0.01                           as tds,
        0                                  as additional_services,  -- Ghana only
        null::varchar                      as adjustment_type,
        'recon_india'                      as schema_name,
        'daily_reconciliation'             as table_name,
        'Daily'                            as recon_period
    from recon_india.daily_reconciliation
    where city in ('Bangalore', 'Hyderabad', 'Mumbai', 'Delhi NCR')
      and (day between '2023-11-20' and '2024-01-15' or day > '2024-01-28')
),
weekly_recon as (
    select
        'historical'                       as source,
        'India'                            as country,
        initcap(city)                      as city,
        week,
        week                               as day,
        drn,
        uber_id,
        'DTO'                              as product,
        vehicle_type,
        --case when trim(vehicle_plate) in ('', '0') then null else trim(vehicle_plate) end as 
        null                                 as vehicle_plate,
        effective_days,
        coalesce(refund_and_expenses, 0)   as refund_and_expenses,
        coalesce(tax_credit_from_uber, 0)  as tax_credit_from_uber,
        0                                  as toll,
        coalesce(uber_balance, 0)          as uber_balance,
        coalesce(bank_statement, 0)        as bank_statement,
        coalesce(incentives, 0)            as incentives,
        0                                  as adjustment_amount,
        coalesce(weekly_remittance, 0)     as remittance,
        coalesce(extra_charges, 0)         as extra_charges,
        coalesce(prev_outstanding, 0)      as prev_outstanding,
        coalesce(cumm_outstanding, 0)      as cumm_outstanding,
        coalesce(payouts, 0)               as payouts,
        coalesce(payables, 0)              as payables,
        coalesce(va_account, 0)            as va_account,
        coalesce(tds, 0)                   as tds,
        0                                  as additional_services,
        null::varchar                      as adjustment_type,
        'recon_india'                      as schema_name,
        'reconciliation'                   as table_name,
        'Weekly'                           as recon_period
    from recon_india.reconciliation
    where week <= '2024-01-22'
)
,india_recon as (
    select * from daily_recon
    union all
    select * from weekly_recon
)
--select drn, sum(effective_days ) as n
--from india_recon
--where drn in  ('MVIN27492','MVIN27470','MVIN27471','MVIN27472','MVIN27473','MVIN27474',
--'MVIN27475','MVIN27477')
--group by drn, day
--having count(*) > 1;
,recon_with_plates as (
    -- fill missing plates with the previous plate for that driver,
    -- and if there's nothing before, use the next one that shows up
    select
        r.*,
        coalesce(
            last_value(vehicle_plate) ignore nulls over (
                partition by drn order by day, case when source = 'current' then 1 else 0 end
                rows between unbounded preceding and current row
            ),
            first_value(vehicle_plate) ignore nulls over (
                partition by drn  order by day, case when source = 'current' then 1 else 0 end
                rows between current row and unbounded following
            )
        ) as plate_filled
    from india_recon r
),
latest_outstanding as (
    -- latest cumm_outstanding per DRN; daily row wins if it lands on the same day as a weekly one
    select drn, cumm_outstanding, day as cumm_outstanding_date
    from (
        select
            drn, cumm_outstanding,
            day,
            row_number() over (
                partition by drn order by day desc, case when source = 'current' then 0 else 1 end
            ) as rn
        from india_recon
    ) x
    where rn = 1
),
--latest_assignment as (
--    select drn, registration_no, effective_start_date, effective_end_date
--    from (
--        select
--            drn,
--            registration_no,
--            vehicle_assignment_start_date as effective_start_date,
--            vehicle_assignment_end_date   as effective_end_date,
--            row_number() over (
--                partition by drn
--                order by vehicle_assignment_start_date desc
--            ) as rn
--        from dbt.core__vehicle_driver_assignment
--        where drn like 'MVIN%'
--    ) x
--    where rn = 1
latest_assignment as (
    select x.drn, x.registration_no, x.effective_start_date, x.effective_end_date, p.plates_assigned
    from (
        select
            drn,
            registration_no,
            vehicle_assignment_start_date as effective_start_date,
            vehicle_assignment_end_date   as effective_end_date,
            row_number() over (
                partition by drn
                order by vehicle_assignment_start_date desc
            ) as rn
        from dbt.core__vehicle_driver_assignment
        where drn like 'MVIN%'
    ) x
    join (
        -- all time count of distinct plates per driver
        select drn, count(distinct registration_no) as plates_assigned
        from dbt.core__vehicle_driver_assignment
        where drn like 'MVIN%'
        group by drn
    ) p on p.drn = x.drn
    where x.rn = 1
)
select
    r.drn,
    r.product,
    r.vehicle_type,
    r.plate_filled               as recon_vehicle_plate,
    a.registration_no            as last_assigned_plate,
    a.plates_assigned            as #plates_assigned,
    a.effective_start_date       as assignment_start_date,
    a.effective_end_date         as assignment_end_date,
    sum(r.effective_days)        as total_effective_days,
    sum(r.uber_balance)          as total_uber_balance,
    sum(r.va_account) * -1       as total_va_account,
    sum(r.bank_statement)        as total_bank_statement,
    sum(r.tax_credit_from_uber)  as tax_credit_from_uber,
    sum(r.incentives)            as total_incentives,
    sum(r.remittance) * -1       as total_remittance_charged,
    sum(r.payouts) * -1          as total_payouts,
    sum(r.extra_charges) * -1    as total_extra_charges,   -- already negative in source
    sum(r.toll) * -1             as total_toll,
    sum(r.tds) * -1              as total_tds,
    sum(r.adjustment_amount)* -1 as total_adjustment_amount,
    l.cumm_outstanding           as latest_cumm_outstanding,
    l.cumm_outstanding_date      as latest_cumm_outstanding_date
from recon_with_plates r
left join latest_assignment a on a.drn = r.drn
left join latest_outstanding l on l.drn = r.drn
where r.product = 'DTO' --r.drn in ('MVIN00191', 'MVIN00384', 'MVIN03576', 'MVIN00933')
group by
    r.drn, r.product, r.vehicle_type, r.plate_filled,
    a.registration_no,a.plates_assigned, a.effective_start_date, a.effective_end_date,
    l.cumm_outstanding, l.cumm_outstanding_date
--having sum(r.effective_days) >= 1400
    order by r.drn, min(r.day);
