--########################################################################################
--**************** Repair charge BYNX vs Repair Fund table
with ghana_plates as (
--select distinct registration_no as plates
--from dbt.core__vehicle_driver_assignment
--where drn like 'MVG%'
select b.drn, c.source_registration_no as plates
from core_dimensions.dim_driver_contract a 
join core_dimensions.dim_driver b on a.driver_id = b.driver_id 
join core_dimensions.dim_vehicle c on a.vehicle_id  = c.vehicle_id
where a.status = 'ACTIVE' and b.country = 'Ghana'
),
ghana_bynx_repairs as (
select reg_no, sum(total_job_cost) as total_job_cost
from core_dimensions.dim_bynx_vehicle_maintenance_hist bynxhist
left join ghana_plates gp on bynxhist.reg_no = gp.plates --keeping only gh plates
where bynxhist.status = 'CLOSED' and DATE_TRUNC('week', bynxhist.end_date)::date = '2026-04-20'
and bynxhist.type_of_maintenance IN ('WEAR & TEAR', 'Major Repairs')
and gp.plates IS NOT null
group by reg_no),
recon_repair_costs as(
select registration_no, sum(repair_fund_spent_via_maintenance) as repair_fund_spent_via_maintenance
from core_dimensions.fact_repair_fund_weekly_costs
where country ilike 'ghana' and  recon_week = '2026-04-20'
and repair_fund_spent_via_maintenance <> 0
group by registration_no )
select gbr.reg_no, gbr.total_job_cost, rrc.repair_fund_spent_via_maintenance,
gbr.total_job_cost + rrc.repair_fund_spent_via_maintenance as diff
from ghana_bynx_repairs gbr
full outer join recon_repair_costs rrc on gbr.reg_no = rrc.registration_no

--Repair Fund balance
--TO_DO : cut off drn only categorization to ingestion date and thereafter use both drn & reg_no
--> 10k overspent
with cumulative as (
    select
        drn
        , sum(contract_repair_fund
            + repair_fund_contribution_via_extra_charges
            + repair_fund_contribution_via_remit)   as total_contribution
        , sum(repair_fund_spent_via_maintenance)     as total_spent
    from core_dimensions.fact_repair_fund_weekly_costs
    where recon_week <= '2026-04-20'
    group by drn
)
, week_reg as (
    select
        drn
        , registration_no
    from core_dimensions.fact_repair_fund_weekly_costs
    where recon_week = '2026-04-20'
)
select
    c.drn
    , w.registration_no
    , c.total_contribution
    , c.total_spent
    , c.total_contribution + c.total_spent  as repair_fund_bal
from week_reg w 
left join cumulative c
    on w.drn = c.drn
where c.total_contribution + c.total_spent < -10000
order by c.drn




-- Contract DRN <> plate mapping 
select b.drn, c.source_registration_no as plates
from core_dimensions.dim_driver_contract a 
join core_dimensions.dim_driver b on a.driver_id = b.driver_id 
join core_dimensions.dim_vehicle c on a.vehicle_id  = c.vehicle_id
where a.status = 'ACTIVE' and b.country = 'Ghana'



--**************** daily total received -- calculate recon vs loans 
with raw_recon as (
    select
        drn,
        sum(coalesce(uber_balance, 0)) as uber_balance,
        sum(coalesce(payins, 0)) as payins,
        sum(case when adjustment_type not ilike '%driver remit adjustment%' then coalesce(adjustments, 0) else 0 end) as loan_adjustments,
        sum(case when adjustment_type ilike '%driver remit adjustment%' then coalesce(adjustments, 0) else 0 end) as remit_adjustments,
        sum(coalesce(extra_charges, 0)) as regular_extra_charges,
        sum(coalesce(passthrough_costs , 0)) as passthrough_extra_charges,
        sum(coalesce(repair_charges, 0)) as repair_fund_extra_charges,
        sum(coalesce(additional_charges, 0)) as addon_extra_charges
    from core_dimensions.mart_driver_daily_recon
    where country ilike 'ghana' and recon_week = date '2026-08-24'
    group by drn
),parsed_adjustments AS (
select frd.recon_week, frd.drn, JSON_PARSE(frd.adjustments_breakdown) AS breakdown_obj
from core_dimensions.fact_recon_daily frd
where frd.country in ('Ghana') and frd.recon_week = '2026-08-24'
and frd.adjustments_breakdown is not null 
and TRIM(frd.adjustments_breakdown) <> ''and IS_VALID_JSON(frd.adjustments_breakdown)
),individual_adjustments as (
SELECT DATE_TRUNC('week', recon_week) as week_start,
drn, key as category, value::float8 as amount
from parsed_adjustments t, unpivot t.breakdown_obj as value at key
where value::float8 <> 0
order by week_start, drn, category
),drn_adjustments as(
select drn, sum(case when (lower(category) ilike '%days%' or lower(category) ilike '%remit%') then amount else 0 end) as  remit_adjustments
, sum(case when (lower(category) not ilike '%days%' and lower(category) not ilike '%remit%') then amount else 0 end) as  loan_adjustments
from individual_adjustments
group by drn 
),loandata as (
    select drn
    ,uber_balance as ptd_uber_balance
    ,bank_statement as ptd_payins
    ,adjustment_amount_included as ptd_loan_adjustments
    ,adjustment_amount_excluded as ptd_remit_adjustments
    ,extra_charges as ptd_regular_extra_charges
    ,toll as ptd_passthrough_extra_charges --ensure proper replacement of 'toll' with "passthrough_costs" once rolled out
    ,additional_charges as ptd_addon_extra_charges
    ,repair_charges as ptd_repair_fund_extra_charges
    , coalesce( recon_total_received, 0) as week_total_received
    , contract_status as status --week_total_received, last_contract_status /recon_total_received,contract_status
    from core_dimensions.mart_driver_paid_to_date--_v2
    where country ilike 'ghana' and week = date '2026-08-24')
select
    coalesce(rr.drn, ld.drn) as drn
    ,rr.uber_balance, ld.ptd_uber_balance
    ,rr.payins,ld.ptd_payins
    ,da.loan_adjustments,ld.ptd_loan_adjustments
    ,da.remit_adjustments,ld.ptd_remit_adjustments
    ,rr.regular_extra_charges,ld.ptd_regular_extra_charges
    ,rr.passthrough_extra_charges, ld.ptd_passthrough_extra_charges
    , rr.repair_fund_extra_charges , ld.ptd_repair_fund_extra_charges
    , rr.addon_extra_charges, ld.ptd_addon_extra_charges
    ,coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0)+ coalesce(da.loan_adjustments, 0) + coalesce(rr.regular_extra_charges, 0) 
    + coalesce(rr.repair_fund_extra_charges, 0) + coalesce(rr.addon_extra_charges, 0) as recon_weekly_received,
    ld.week_total_received,
    (coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0) + coalesce(da.loan_adjustments, 0)
      + coalesce(rr.regular_extra_charges, 0) + coalesce(rr.repair_fund_extra_charges, 0) 
      + coalesce(rr.addon_extra_charges, 0)) 
      - coalesce(ld.week_total_received, 0) as diff
from raw_recon rr
full outer join loandata ld on rr.drn = ld.drn --full join to include any driver on loans & not on recon
left join drn_adjustments da on rr.drn = da.drn
where (coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0) + coalesce(da.loan_adjustments, 0)
      + coalesce(rr.regular_extra_charges, 0) + coalesce(rr.repair_fund_extra_charges, 0) 
      + coalesce(rr.addon_extra_charges, 0) + rr.passthrough_extra_charges) --= 0 --and rr.drn is not null and ld.status = 'ACTIVE'
      - coalesce(ld.week_total_received, 0) not between -1 and 1


--***************** Drivers by payment category 
-->> paid, nothing paid, -ve payment
select
    -- paid
    count(case when week_total_received > 0 then 1 end)                     as paid_count
    , sum(case when week_total_received > 0 then week_total_received end)   as paid_sum
    , avg(case when week_total_received > 0 then week_total_received end)   as paid_avg
    -- nothing paid
    , count(case when week_total_received = 0 then 1 end)                   as nothing_paid_count
    , sum(case when week_total_received = 0 then week_total_received end)   as nothing_paid_sum
    , avg(case when week_total_received = 0 then week_total_received end)   as nothing_paid_avg
    -- negative
    , count(case when week_total_received < 0 then 1 end)                   as negative_count
    , sum(case when week_total_received < 0 then week_total_received end)   as negative_sum
    , avg(case when week_total_received < 0 then week_total_received end)   as negative_avg
from (
    select mdptd.drn, coalesce(mdptd.week_total_received, 0) as week_total_received
    from core_dimensions.mart_driver_paid_to_date mdptd
    left join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
    where mdptd.country ilike 'ghana'
      and mdptd.week = date '2026-04-20'
      and ddc.status = 'ACTIVE'
      QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 
) sub


--Disecting for Active Drivers Only
select mdptd.week, mdptd.drn, mdptd.week_total_received as week_total_received,ddc.status  -- count(mdptd.drn)
from core_dimensions.mart_driver_paid_to_date mdptd
inner join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
where mdptd.country ilike 'ghana' 
and mdptd.week = date '2026-04-20' 
and mdptd.week_total_received = 0 
and ddc.status = 'ACTIVE'
QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1

--Disecting for Inactive Drivers Only
select mdptd.drn, coalesce(mdptd.week_total_received, 0) as week_total_received
,ddc.end_date
,ddc.status
from core_dimensions.mart_driver_paid_to_date mdptd
left join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
where mdptd.country ilike 'ghana'
      and mdptd.week = date '2026-04-20'
      and ddc.status <> 'ACTIVE'
      and mdptd.week_total_received = 0
order by ddc.end_date desc

--*************** Total loan amount
-- calculated recon remit * tenure vs paid_to_date loan amount
with raw_metrics as (
  select
    mdwr.drn, (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 as weekly_remit, ddc.tenure
  from core_dimensions.mart_driver_weekly_recon mdwr
  left join core_dimensions.dim_driver_contract ddc on mdwr.driver_id = ddc.driver_id
  where lower(mdwr.country) = 'ghana'
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-04-13'
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, contract_required_remittance as loan_amount
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'ghana' and week = '2026-04-13')
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.loan_amount, round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount <> 0 --not between -10 and 10
order by diff desc


--added loan 2.0 tenure and remit columns
with raw_metrics as (
  select
    mdwr.drn, (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 as weekly_remit, ddc.tenure
  from core_dimensions.mart_driver_weekly_recon mdwr
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id -- core_dimensions.dim_driver_contract core_dimensions.dim_driver_contract_hist 
  where lower(mdwr.country) = 'ghana'
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-04-20'
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, tenure AS ptd_tenure, TOTAL_REMITTANCE * 6 AS ptd_weely_remit, ghana_trial_threshold, contract_required_remittance as loan_amount
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'ghana' and week = '2026-04-20')
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.ptd_weely_remit, la.ptd_tenure, la.ghana_trial_threshold, la.loan_amount, round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount not between -10 and 10
order by diff desc


--****************  Paid to date comparison
-- t-1 published paid_to_date vs t paid_to_date
with weekly_comparison as (
  select drn, 
    max(case when week = '2026-04-13' then driver_total_received end) as prev_total_received,
    max(case when week = '2026-04-20' then driver_total_received end) as current_total_received,
    max(case when week = '2026-04-20' then week_total_received end) as week_total_received -- value responsible for change
    ,max(case when week = '2026-03-13' then ghana_trial_week::int end)::boolean as ghana_trial_week
  from core_dimensions.mart_driver_paid_to_date
  where week in ('2026-04-20', '2026-04-13')
  group by drn)
select
  drn,  prev_total_received, current_total_received,
  current_total_received - prev_total_received as diff,
  week_total_received,
  current_total_received - prev_total_received - week_total_received as balancer,
  ghana_trial_week
from weekly_comparison
where current_total_received - prev_total_received - week_total_received <> 0
and ghana_trial_week is false

-- investigating DRN on paid to date
select week, drn,week_total_received, driver_total_received,ghana_trial_week, *
from core_dimensions.mart_driver_paid_to_date
where drn = 'MVG10670'
order by week desc



--**************** Checking if Driver has Statements
select week_date,drn,registration_no as contract_plate,*
--add loan repait (t-1) - loan repaid (t) = weekly repaid amount
from recon.recon_output__income_statement
where country = 'Ghana' and drn in ('MVG00212') -- and week_date = '2026-04-13'
order by week_date desc
limit 10



--*****************Investigating adjustments weekly recon vs weekly recon
with daily_recon as (
select drn, SUM(case when adjustment_type not ilike '%driver remit adjustment%' then coalesce(adjustments, 0) else 0 end ) as daily_adjustments
from core_dimensions.mart_driver_daily_recon
where country = 'Ghana' and recon_week  = '2026-04-13' and adjustments <>0
group by drn)
--union all-- full outer join 
,weekly_recon as(
select drn, SUM(case when adjustment_type not ilike '%driver remit adjustment%' then coalesce(adjustments, 0) else 0 end ) as weekly_adjustments
from core_dimensions.mart_driver_weekly_recon
where country = 'Ghana' and recon_week  = '2026-04-13' and adjustments <>0
group by drn)
select dr.*, wr.weekly_adjustments
from daily_recon dr full outer join weekly_recon wr on dr.drn = wr.drn



--**************** checking drns in recon vs in loans
-- DRNs in weekly_recon but NOT in paid_to_date
WITH recon_drns AS (
    SELECT DISTINCT driver_id, drn
    FROM core_dimensions.mart_driver_weekly_recon
    WHERE country = 'Ghana' AND recon_week = '2026-04-20'
),
paid_drns AS (
    SELECT DISTINCT driver_id, drn
    FROM core_dimensions.mart_driver_paid_to_date
    WHERE country = 'Ghana' AND week = '2026-04-20'
),
gaps AS (
    SELECT driver_id, drn, 'in_recon_not_in_paid' AS source
    FROM recon_drns
    WHERE drn NOT IN (SELECT drn FROM paid_drns)
    UNION ALL
    SELECT driver_id, drn, 'in_paid_not_in_recon' AS source
    FROM paid_drns
    WHERE drn NOT IN (SELECT drn FROM recon_drns)
)
SELECT
    g.drn AS unique_drn
    , g.source
    , ddc.contract_id AS driver_contract_id
    , ddc.contract_code --ddc.comment AS contract_file
    , ddc.status
FROM gaps                                       AS g
INNER JOIN core_dimensions.dim_driver           AS dd   ON g.driver_id  = dd.driver_id
INNER JOIN core_dimensions.dim_driver_contract  AS ddc  ON dd.driver_id = ddc.driver_id
QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1
ORDER BY g.source, g.drn;
