--**************** weekly total received -- calculate recon vs loans 
with raw_recon as (
    select
        recon_week, drn,
        sum(coalesce(uber_balance, 0)) as uber_balance,
        sum(coalesce(payins, 0)) as payins,
        sum(coalesce(extra_charges, 0)) as regular_extra_charges,
        sum(coalesce(repair_charges, 0)) as repair_fund_extra_charges,
        sum(coalesce(additional_charges, 0)) as addon_extra_charges,
        sum(coalesce(payouts, 0)) as payouts,
        sum(coalesce(passthrough_costs)) as passthrough_costs
    from core_dimensions.mart_driver_weekly_recon
    where country ilike 'south africa' and recon_week = '2026-08-31'
    --drn = 'MVS16348'
    group by recon_week, drn
)
,parsed_adjustments AS (
select frd.recon_week, frd.drn, JSON_PARSE(frd.adjustments_breakdown) AS breakdown_obj
from core_dimensions.fact_recon_daily frd
where frd.country in ('South Africa') and frd.recon_week = '2026-08-31'
and frd.adjustments_breakdown is not null 
and TRIM(frd.adjustments_breakdown) <> ''and IS_VALID_JSON(frd.adjustments_breakdown)
),individual_adjustments as (
SELECT DATE_TRUNC('week', recon_week) as week_start,
drn, key as category, value::float8 as amount
from parsed_adjustments t, unpivot t.breakdown_obj as value at key
where value::float8 <> 0
order by week_start, drn, category
),adjustments_data as(
select drn, sum(case when (lower(category) ilike '%days%' or lower(category) ilike '%remit%') then amount else 0 end) as  remit_adjustments
, sum(case when (lower(category) not ilike '%days%' and lower(category) not ilike '%remit%') then amount else 0 end) as  loan_adjustments
from individual_adjustments
group by drn 
), loandata as (
    select week, drn 
    ,uber_balance as ptd_uber_balance
    ,bank_statement as ptd_payins
    ,adjustment_amount_included as ptd_loan_adjustments
    ,adjustment_amount_excluded as ptd_remit_adjustments
    ,extra_charges as ptd_regular_extra_charges
    ,passthrough_costs as ptd_passthrough_extra_charges
    ,additional_charges as ptd_addon_extra_charges
    ,repair_charges as ptd_repair_fund_extra_charges
    ,coalesce(recon_total_received, 0) as week_total_received
    from core_dimensions.mart_driver_paid_to_date
    where country ilike 'south africa' and week = '2026-08-31')
, final as (select
    coalesce(rr.recon_week::date, ld.week::date) as week 
    ,coalesce(rr.drn, ld.drn) as drn
    ,rr.uber_balance, ld.ptd_uber_balance
    ,rr.payins, ld.ptd_payins
    ,ad.loan_adjustments, ld.ptd_loan_adjustments
    ,ad.remit_adjustments, ld.ptd_remit_adjustments--, abs(ld.ptd_remit_adjustments) as absptdadjustment
    ,rr.regular_extra_charges, ld.ptd_regular_extra_charges
    , rr.repair_fund_extra_charges , ld.ptd_repair_fund_extra_charges
    , rr.addon_extra_charges, rr.passthrough_costs, ld.ptd_passthrough_extra_charges, ld.ptd_addon_extra_charges
    ,coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0)+ coalesce(ad.loan_adjustments, 0) + coalesce(rr.regular_extra_charges, 0) 
    + coalesce(rr.repair_fund_extra_charges, 0) + coalesce(rr.addon_extra_charges, 0) + coalesce(rr.passthrough_costs, 0) + coalesce(rr.payouts, 0) as recon_weekly_received,
    ld.week_total_received,
    (coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0) + coalesce(ad.loan_adjustments, 0)
      + coalesce(rr.regular_extra_charges, 0) + coalesce(rr.repair_fund_extra_charges, 0) 
      + coalesce(rr.addon_extra_charges, 0)+ coalesce(rr.payouts, 0) + coalesce(rr.passthrough_costs, 0) -- coalesce(abs(ld.ptd_remit_adjustments), 0)
      - coalesce(ld.week_total_received, 0)) as diff
from raw_recon rr
full outer join loandata ld on rr.drn = ld.drn --full join to include any driver on loans & not on recon
and rr.recon_week = ld.week
left join adjustments_data ad on rr.drn = ad.drn
order by rr.drn,rr.recon_week desc
)
select *
from final 
where diff not between -1 and 1


    
--recon check
select recon_week,drn,effective_days,uber_balance,driver_remit_for_the_period,driver_balance_for_the_period,contract_status,registration_no,* 
from core_dimensions.mart_driver_weekly_recon
where country ilike 'south africa' and drn = 'MVS17503'
order by recon_week desc

--DRN specific loan check
select week, drn,week_total_received, driver_total_received, * --week, drn, coalesce(week_total_received, 0) as week_total_received
from core_dimensions.mart_driver_paid_to_date
where drn in ('MVS17503') --and week = '2026-04-06' --MVS24104','MVS10955','MVS12685','MVS14366','MVS16113''
order by week




-- Contract DRN <> plate mapping 
select b.drn, c.source_registration_no as plates
from core_dimensions.dim_driver_contract a 
join core_dimensions.dim_driver b on a.driver_id = b.driver_id 
join core_dimensions.dim_vehicle c on a.vehicle_id  = c.vehicle_id
where c.source_registration_no = 'GC2336-22' --a.status = 'ACTIVE' and b.country = 'Ghana' and 


--contract status
SELECT
    dd.drn
    , dd.country
    , ddc.vehicle_id
    , ddc.start_date AS last_contract_start_date
  FROM core_dimensions.dim_driver_contract AS ddc
  INNER JOIN core_dimensions.dim_driver AS dd
    ON ddc.driver_id = dd.driver_id
  WHERE dd.country = 'South Africa'
    AND ddc.status IN ('TERMINATED', 'ACTIVE', 'COMPLETED', 'TERMINATION_INITIATED')
    and dd.drn in ('MVS16187','MVS18483','MVS21019','MVS21107','MVS24104')
  QUALIFY ROW_NUMBER() OVER ( PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC )  = 1

-- ****************  Total loan amount
-- calculate recon remit * tenure vs paid_to_date loan amount
with raw_metrics as (
  select
    mdwr.drn, (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 as weekly_remit, ddc.tenure
  from core_dimensions.mart_driver_weekly_recon mdwr
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id -- core_dimensions.dim_driver_contract core_dimensions.dim_driver_contract_hist 
  where lower(mdwr.country) = 'south africa'
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-04-20' --between '2026-04-13' and '2026-04-20'
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, contract_required_remittance as loan_amount
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'south africa' and week = '2026-04-20')
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.loan_amount, round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount not between -10 and 10
order by diff desc, drn
  

  

--***************** Drivers by payment category 
-->> paid, nothing paid, -ve payment
select
    -- paid
    count(case when week_total_received > 0 then 1 end)                     as paid_count
    , sum(case when week_total_received > 0 then week_total_received end)   as paid_sum
    , avg(case when week_total_received > 0 then week_total_received end)   as paid_avg
    -- nothing paid
    , count(case when week_total_received = 0 then 1 end)                   as nothing_paid_count
    , sum(case when week_total_received = 0 then week_total_received end)   as nothing_paid_sum
    , avg(case when week_total_received = 0 then week_total_received end)   as nothing_paid_avg
    -- negative
    , count(case when week_total_received < 0 then 1 end)                   as negative_count
    , sum(case when week_total_received < 0 then week_total_received end)   as negative_sum
    , avg(case when week_total_received < 0 then week_total_received end)   as negative_avg
from (
    select mdptd.drn, coalesce(mdptd.week_total_received, 0) as week_total_received
    from core_dimensions.mart_driver_paid_to_date mdptd
    left join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
    where mdptd.country ilike 'south africa'
      and mdptd.week = date '2026-04-20'
      --and ddc.status = 'ACTIVE'
      QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 
) sub



--Extracting Active Drivers Only
select mdptd.drn, mdptd.week_total_received as week_total_received,ddc.status  -- count(mdptd.drn)
from core_dimensions.mart_driver_paid_to_date mdptd
inner join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
where mdptd.country ilike 'south africa' 
and mdptd.week = date '2026-04-20' 
and mdptd.week_total_received = 0 
and ddc.status = 'ACTIVE'
QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 

--Extracting Inactive Drivers Only
select 
mdptd.drn
, coalesce(mdptd.week_total_received, 0) as week_total_received
, ddc.end_date
, ddc.status
from core_dimensions.mart_driver_paid_to_date mdptd
left join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
where mdptd.country ilike 'south africa'
      and mdptd.week = date '2026-04-20'
      and ddc.end_date >= date '2026-04-20'
      and ddc.status <> 'ACTIVE'
      and mdptd.week_total_received = 0
      QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 
order by ddc.end_date desc


-- ****************  Total loan amount
with raw_metrics as (
  select
    mdwr.drn, base_remittance as weekly_remit, ddc.tenure
  from  dbt_emad.mart_driver_paid_to_date mdwr --core_dimensions.mart_driver_weekly_recon 
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id -- core_dimensions.dim_driver_contract core_dimensions.dim_driver_contract_hist 
  where lower(mdwr.country) = 'south africa'
    and mdwr.total_remittance <> 0
    and mdwr.week = '2026-04-20'--between '2026-03-23' and '2026-04-06' 
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, tenure AS ptd_tenure, TOTAL_REMITTANCE AS ptd_weely_remit, contract_required_remittance as loan_amount
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'south africa' and week = '2026-04-20'--between '2026-03-23' and '2026-04-06'
  )
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.ptd_weely_remit, la.ptd_tenure, la.loan_amount, round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount not between -500 and 500
order by diff desc, drn



--added loan 2.0 tenure and remit columns
with raw_metrics as (
  select
    mdwr.drn, (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 as weekly_remit, ddc.tenure
  from core_dimensions.mart_driver_weekly_recon mdwr
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id -- core_dimensions.dim_driver_contract core_dimensions.dim_driver_contract_hist 
  where lower(mdwr.country) = 'south africa'
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-04-20'
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, tenure AS ptd_tenure, TOTAL_REMITTANCE AS ptd_weely_remit, contract_required_remittance as loan_amount
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'south africa' and week = '2026-04-20')
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.ptd_weely_remit, la.ptd_tenure, la.loan_amount
  , round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as loan_amount_diff
  ,rm.weekly_remit - la.ptd_weely_remit as weekly_remit_diff
  , rm.tenure - la.ptd_tenure as tenure_diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount not between -10 and 10
order by loan_amount_diff desc


--added loan 2.0 tenure and remit columns
with raw_metrics as (
  select
    mdwr.drn, (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 as weekly_remit, ddc.tenure
  from core_dimensions.mart_driver_weekly_recon mdwr
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id -- core_dimensions.dim_driver_contract core_dimensions.dim_driver_contract_hist 
  where lower(mdwr.country) = 'south africa'
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-04-20'
    and ddc.status = 'ACTIVE' ),
loan_amounts as (
  select drn, tenure AS ptd_tenure, TOTAL_REMITTANCE AS ptd_weely_remit, contract_required_remittance as loan_amount
  from dbt_emad.mart_driver_paid_to_date -- core_dimensions.mart_driver_paid_to_date
  where lower(country) = 'south africa' and week = '2026-04-20')
select
  rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.ptd_weely_remit, la.ptd_tenure, la.loan_amount
  , round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as loan_amount_diff
  ,rm.weekly_remit - la.ptd_weely_remit as weekly_remit_diff
  , rm.tenure - la.ptd_tenure as tenure_diff
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount  not between -10 and 10
order by loan_amount_diff desc


-- **************** Paid to date comparison >> last week vs Previous week
-- t-1 published paid_to_date vs t draft paid_to_date
with weekly_comparison as (
  select drn, 
    max(case when week = '2026-04-13' then driver_total_received end) as prev_total_received,
    max(case when week = '2026-04-20' then driver_total_received end) as current_total_received,
    max(case when week = '2026-04-20' then week_total_received end) as week_total_received -- value responsible for change
  from core_dimensions.mart_driver_paid_to_date
  where week in ('2026-04-20', '2026-04-13') and lower(country) = 'south africa'
  group by drn)
select
  drn,  prev_total_received, current_total_received,
  current_total_received - prev_total_received as diff,
  week_total_received,
  current_total_received - prev_total_received - week_total_received as balancer
from weekly_comparison
where current_total_received - prev_total_received - week_total_received <> 0




--**************** Confirming Statements Exist
select *
from recon.recon_output__income_statement
where country = 'South Africa' and week_date = '2026-04-13'
limit 10
