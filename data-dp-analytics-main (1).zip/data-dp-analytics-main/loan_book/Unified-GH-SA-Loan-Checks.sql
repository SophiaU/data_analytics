--**************** weekly total received -- calculate recon vs loans 
with raw_recon as (
    select
        recon_week, drn,
        sum(coalesce(uber_balance, 0)) as uber_balance,
        sum(coalesce(payins, 0)) as payins,
        sum(coalesce(extra_charges, 0)) as regular_extra_charges,
        sum(coalesce(repair_charges, 0)) as repair_fund_extra_charges,
        sum(coalesce(additional_charges, 0)) as addon_extra_charges,
        sum(coalesce(payouts, 0)) as payouts,
        sum(coalesce(passthrough_costs)) as passthrough_costs,
        sum(amount_credit_from_recon_to_sd ) as credit_recon_to_sd,
        sum(amount_credit_from_sd_to_recon  ) as credit_sd_to_recon,
        sum(amount_debit_from_recon_to_sd ) as debit_recon_to_sd,
        sum(amount_debit_from_sd_to_recon ) as debit_sd_to_recon,
        sum(termination_fee ) as rtermination_fee
    from core_dimensions.mart_driver_weekly_recon
    where lower(country) in ('ghana','south africa') and recon_week = '2026-08-31'
    --drn = 'MVS16348'
    group by recon_week, drn
)
,parsed_adjustments AS (
select frd.recon_week, frd.drn, JSON_PARSE(frd.adjustments_breakdown) AS breakdown_obj
from core_dimensions.fact_recon_daily frd
where lower(frd.country) in ('ghana','south africa') and frd.recon_week = '2026-08-31'
and frd.adjustments_breakdown is not null 
and TRIM(frd.adjustments_breakdown) <> ''and IS_VALID_JSON(frd.adjustments_breakdown)
),individual_adjustments as (
SELECT DATE_TRUNC('week', recon_week) as week_start,
drn, key as category, value::float8 as amount
from parsed_adjustments t, unpivot t.breakdown_obj as value at key
where value::float8 <> 0
order by week_start, drn, category
),adjustments_data as(
select drn, sum(case when (lower(category) ilike '%days%' or lower(category) ilike '%remit%') then amount else 0 end) as  remit_adjustments
, sum(case when (lower(category) not ilike '%days%' and lower(category) not ilike '%remit%') then amount else 0 end) as  loan_adjustments
from individual_adjustments
group by drn 
), loandata as (
    select country,week, drn 
    ,uber_balance as ptd_uber_balance
    ,bank_statement as ptd_payins
    ,adjustment_amount_included as ptd_loan_adjustments
    ,adjustment_amount_excluded as ptd_remit_adjustments
    ,extra_charges as ptd_regular_extra_charges
    ,passthrough_costs as ptd_passthrough_extra_charges
    ,additional_charges as ptd_addon_extra_charges
    ,repair_charges as ptd_repair_fund_extra_charges
    ,amount_credit_from_sd_to_recon as sd_to_recon 
    ,amount_debit_from_recon_to_sd as recon_to_sd
    ,termination_fee as ltermination_fee
    ,coalesce(recon_total_received, 0) as week_total_received
    from core_dimensions.mart_driver_paid_to_date
    where lower(country) in ('ghana','south africa') and week = '2026-08-31')
    --drn = 'MVS16348')
, final as (select
    ld. country, coalesce(rr.recon_week::date, ld.week::date) as week 
    ,coalesce(rr.drn, ld.drn) as drn
    ,rr.uber_balance, ld.ptd_uber_balance
    ,rr.payins, ld.ptd_payins
    ,ad.loan_adjustments, ld.ptd_loan_adjustments
    ,ad.remit_adjustments, ld.ptd_remit_adjustments--, abs(ld.ptd_remit_adjustments) as absptdadjustment
    ,rr.regular_extra_charges, ld.ptd_regular_extra_charges
    , rr.repair_fund_extra_charges , ld.ptd_repair_fund_extra_charges
    , rr.addon_extra_charges, rr.passthrough_costs, ld.ptd_passthrough_extra_charges, ld.ptd_addon_extra_charges
    ,rr.debit_recon_to_sd, rr.debit_sd_to_recon, rr.credit_recon_to_sd , rr.credit_sd_to_recon 
    ,ld.sd_to_recon, ld.recon_to_sd 
    ,rr.rtermination_fee ,ld.ltermination_fee 
    ,coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0)+ coalesce(ad.loan_adjustments, 0) + coalesce(rr.regular_extra_charges, 0) 
    + coalesce(rr.repair_fund_extra_charges, 0) + coalesce(rr.addon_extra_charges, 0) + coalesce(rr.passthrough_costs, 0) + coalesce(rr.payouts, 0)
    + coalesce(rr.credit_sd_to_recon,0 ) + coalesce(rr.debit_recon_to_sd ,0 )
     + coalesce(rr.rtermination_fee  ,0 ) as recon_weekly_received,
    ld.week_total_received,
    (coalesce(rr.uber_balance, 0) + coalesce(rr.payins, 0) + coalesce(ad.loan_adjustments, 0)
      + coalesce(rr.regular_extra_charges, 0) + coalesce(rr.repair_fund_extra_charges, 0) 
      + coalesce(rr.addon_extra_charges, 0)+ coalesce(rr.payouts, 0) + coalesce(rr.passthrough_costs, 0) -- coalesce(abs(ld.ptd_remit_adjustments), 0)
      + coalesce(rr.credit_sd_to_recon,0 ) + coalesce(rr.debit_recon_to_sd ,0 ) + coalesce(rr.rtermination_fee  ,0 )
      - coalesce(ld.week_total_received, 0)) as diff
from raw_recon rr
full outer join loandata ld on rr.drn = ld.drn --full join to include any driver on loans & not on recon
and rr.recon_week = ld.week
left join adjustments_data ad on rr.drn = ad.drn
order by rr.drn,rr.recon_week desc
)
select *
from final 
where diff not between -1 and 1




--***************** Drivers by payment category 
-->> paid, nothing paid, -ve payment
select
    -- paid
country
    ,count(case when recon_total_received > 0 then 1 end)                     as paid_count
    , sum(case when recon_total_received > 0 then recon_total_received end)   as paid_sum
    , avg(case when recon_total_received > 0 then recon_total_received end)   as paid_avg
    -- nothing paid
    , count(case when recon_total_received = 0 then 1 end)                   as nothing_paid_count
    , sum(case when recon_total_received = 0 then recon_total_received end)   as nothing_paid_sum
    , avg(case when recon_total_received = 0 then recon_total_received end)   as nothing_paid_avg
    -- negative
    , count(case when recon_total_received < 0 then 1 end)                   as negative_count
    , sum(case when recon_total_received < 0 then recon_total_received end)   as negative_sum
    , avg(case when recon_total_received < 0 then recon_total_received end)   as negative_avg
from (
    select mdptd.country,  mdptd.drn, coalesce(mdptd.recon_total_received, 0) as recon_total_received
    from core_dimensions.mart_driver_paid_to_date mdptd
    left join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
    where lower(mdptd.country) in ('ghana','south africa')
      and mdptd.week = date '2026-08-31'
      --and ddc.status = 'ACTIVE'
      --QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 
) sub
group by country



-- counting drivers by amount paid category
select mdptd.country,mdptd.contract_status,
count(case when recon_total_received = 0 then 1 end) as nothing_paid_count
,count(case when recon_total_received < 0 then 1 end) as negative_paid_count
from core_dimensions.mart_driver_paid_to_date mdptd
--inner join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
where mdptd.week = '2026-08-24 00:00:00'::timestamp 
and mdptd.country in ('Ghana','South Africa')
and mdptd.contract_status = 'ACTIVE'
group by mdptd.country,mdptd.contract_status



--*************** Total loan amount
-- calculated recon remit * tenure vs paid_to_date loan amount
--added loan 2.0 tenure and remit columns
with raw_metrics as (
  select
    mdwr.country,mdwr.drn 
    --case when lower(mdwr.country) = 'ghana' then (abs(mdwr.driver_remit_for_the_period) / mdwr.effective_days) * 6 else abs(mdwr.driver_remit_for_the_period) end as weekly_remit
    ,case when lower(mdwr.country) = 'ghana' then (abs(dct.remittance + dct.additional_service_fee ) * 6)	else abs(dct.remittance) end as contract_temp_weekly_remit
    ,abs(driver_remit_for_the_period) * 6 as weekly_remit
    -- STILL NEEDS a true source of weekly remittance ;-not derived
    , ddc.tenure, ddc.start_date as contract_start_date
    ,ddc.last_modified_on 
  from core_dimensions.mart_driver_daily_recon mdwr
  --core_dimensions.mart_driver_weekly_recon mdwr
  left join core.driver_contracts ddc on mdwr.driver_id = ddc.driver_id 
  -- core_dimensions.dim_driver_contract 
  --core_dimensions.dim_driver_contract_hist 
  left join core_dimensions.dim_contract_template dct on ddc.template_id = dct.template_id 
  where lower(mdwr.country) in ('ghana','south africa')
    and mdwr.driver_remit_for_the_period <> 0
    and mdwr.recon_week = '2026-08-31'
    and ddc.status = 'ACTIVE' 
   --group by mdwr.country,mdwr.drn
    ),
loan_amounts as (
  select drn, tenure AS ptd_tenure,
  case when lower(country) = 'ghana' then 
  	TOTAL_REMITTANCE * 6 
  	else TOTAL_REMITTANCE end AS ptd_weely_remit
  , contract_required_remittance as loan_amount --, ghana_trial_threshold
  from core_dimensions.mart_driver_paid_to_date
  where lower(country) in ('ghana','south africa') and week = '2026-08-31'
  )
select
  rm.country,rm.drn, rm.weekly_remit, rm.tenure, rm.weekly_remit * rm.tenure as calculated_loan_amount,
  la.ptd_weely_remit, la.ptd_tenure, la.loan_amount, round(rm.weekly_remit * rm.tenure,0) - la.loan_amount as diff --, la.ghana_trial_threshold
  ,rm.contract_start_date , rm.last_modified_on
from raw_metrics rm
left join loan_amounts la on rm.drn = la.drn
where (rm.weekly_remit * rm.tenure) - la.loan_amount not between -10 and 10
order by country, diff desc 

select drn,abs(min(driver_remit_for_the_period)) * 6 as weekly_remit
from core_dimensions.mart_driver_daily_recon
where lower(country) in ('ghana','south africa') and recon_week = '2026-08-31'
group by drn


-- **************** Paid to date comparison
-- t-1 published paid_to_date vs t draft paid_to_date
with weekly_comparison as (
  select drn, 
    max(case when week = '2026-08-24' then driver_total_received end) as prev_total_received,
    max(case when week = '2026-08-31' then driver_total_received end) as current_total_received,
    max(case when week = '2026-08-31' then recon_total_received end) as week_total_received -- value responsible for change
    --max(case when week = '2026-08-10' then contract_start_date end) as week_total_received
  from core_dimensions.mart_driver_paid_to_date
  where week in ('2026-08-24', '2026-08-31') and lower(country) in ('south africa', 'ghana')
  group by drn
 ), contracts as (
select * from(
select b.country, b.drn, a.status, c.source_registration_no as plates,a.start_date, a.end_date
,a.last_modified_on 
,row_number() over(partition by a.driver_id order by a.end_date desc, a.start_date) as rn
from core_dimensions.dim_driver_contract a 
join core_dimensions.dim_driver b on a.driver_id = b.driver_id 
join core_dimensions.dim_vehicle c on a.vehicle_id  = c.vehicle_id
where  b.country  in ('Ghana', 'South Africa') and a.status not in ('CANCELLED','SIGNED','INVALID'))
where rn = 1
), gh_4wktrial_status as(
SELECT week, drn, ghana_trial_week, prev_week_ghana_trial_week
FROM (SELECT week, drn, ghana_trial_week
, LAG(ghana_trial_week) OVER (PARTITION BY drn ORDER BY week) AS prev_week_ghana_trial_week
    FROM core_dimensions.mart_driver_gh_trial_status) t
WHERE week = '2026-08-24' 
)
select
  c.country, wc.drn,  prev_total_received, current_total_received,
  current_total_received - prev_total_received as diff,
  week_total_received,
  current_total_received - prev_total_received - week_total_received as balancer
  ,c.start_date ,c.last_modified_on 
  ,g4ws.ghana_trial_week ,g4ws.prev_week_ghana_trial_week
from weekly_comparison wc
left join contracts c on wc.drn = c.drn
left join gh_4wktrial_status g4ws on wc.drn = g4ws.drn
where current_total_received - prev_total_received - week_total_received <> 0
order by c.country
  
 
--**************** Checking if Driver has Statements
select week_date,drn,registration_no as contract_plate,*
--add loan repait (t-1) - loan repaid (t) = weekly repaid amount
from recon.recon_output__income_statement
where country in ('Ghana', 'South Africa') 
and drn in ('MVG13761','MVG16377','MVG16369','MVG16375','MVG13132') 
and week_date = '2026-08-31'
order by week_date 
limit 20







--############## GHANA Specific Repair Charges--
-- ******** Repair Charge: Bynx vs Repair Fund Table (Weekly Check) ********
with ghana_plates as (
    select b.drn, c.source_registration_no as plates
    from core_dimensions.dim_driver_contract a
    join core_dimensions.dim_driver b on a.driver_id = b.driver_id
    join core_dimensions.dim_vehicle c on a.vehicle_id = c.vehicle_id
    where a.status = 'ACTIVE' and b.country = 'Ghana'
), ghana_bynx_repairs as (
    select reg_no, sum(total_job_cost) as total_job_cost
    from core_dimensions.dim_bynx_vehicle_maintenance_hist bynxhist
    inner join ghana_plates gp on bynxhist.reg_no = gp.plates
    where bynxhist.status = 'CLOSED'
      and DATE_TRUNC('week', bynxhist.end_date)::date = '2026-08-31'
      and bynxhist.type_of_maintenance IN ('WEAR & TEAR', 'Major Repairs')
      and bynxhist.is_latest_version is true
    group by reg_no
), recon_repair_costs as (
    select registration_no, sum(repair_fund_spent_via_maintenance) as repair_fund_spent_via_maintenance
    from core_dimensions.fact_repair_fund_weekly_costs
    where country ilike 'ghana'
      and recon_week = '2026-08-31'
      and repair_fund_spent_via_maintenance <> 0
    group by registration_no
)
select
    COALESCE(gbr.reg_no, rrc.registration_no) as reg_no,
    gbr.total_job_cost,
    rrc.repair_fund_spent_via_maintenance,
    COALESCE(gbr.total_job_cost, 0) + COALESCE(rrc.repair_fund_spent_via_maintenance, 0) as diff
from ghana_bynx_repairs gbr
full outer join recon_repair_costs rrc on gbr.reg_no = rrc.registration_no
where COALESCE(gbr.total_job_cost, 0) + COALESCE(rrc.repair_fund_spent_via_maintenance, 0) <> 0



--******************** Highlighting Repair charges double charges
-->1 driver charged repair charge due to mid-week assignment
with flagged as (
    select recon_week,drn,registration_no,repair_fund_spent_via_maintenance,bynx_maintenance_references,
        case
            when min(drn) over (partition by recon_week, registration_no) <> max(drn) over (partition by recon_week, registration_no)
            then 1 else 0 end as has_multiple_drns
    from core_dimensions.fact_repair_fund_weekly_costs
    where repair_fund_spent_via_maintenance <> 0 and recon_week > '2026-03-23' --remove week filter to see historical occurrences
)
select recon_week, drn, registration_no, repair_fund_spent_via_maintenance,bynx_maintenance_references
--,dbvmh.maintenance_reference
from flagged f
left join core_dimensions.dim_bynx_vehicle_maintenance_hist dbvmh 
on f.registration_no = dbvmh.reg_no and round(f.repair_fund_spent_via_maintenance,0) = round(dbvmh.total_job_cost,0)
where has_multiple_drns = 1 and recon_week = '2026-08-31'
and dbvmh.is_latest_version is true
order by recon_week, registration_no, drn;




---##########SA Specific Extracting ACTIVE drivers with 0 weekly paid amounts
-- Active Drivers Only with vehicle custody status
-- Extract periodically requested by SA Ops

with ranked_vehicle_custody as (
    select *,row_number() over (partition by vehicle_id order by end_date desc) as rn
    from core_dimensions.dim_vehicle_operational_status_history --custody
), vehicle_custody_status as (
select * from ranked_vehicle_custody
where rn = 1
),ranked_vehicle_lifecycle as (
select *,row_number() over (partition by vehicle_id order by end_date desc) as rn
from core_dimensions.dim_vehicle_lifecycle_status_history_hist
), vehicle_lifecycle_status as (
select * from ranked_vehicle_lifecycle
where rn = 1
)
select mdptd.drn, mdptd.recon_total_received as week_total_received,ddc.status, -- count(mdptd.drn)
vcs.operational_status as vehicle_custody_status,
vls.lifecycle_status as vehicle_lifecycle_status
--, vcs.start_date as status_start_date, vcs.end_date  as status_end_date
from core_dimensions.mart_driver_paid_to_date mdptd
inner join core_dimensions.dim_driver_contract ddc on mdptd.driver_id = ddc.driver_id 
left join vehicle_custody_status vcs on ddc.vehicle_id = vcs.vehicle_id  
left join ranked_vehicle_lifecycle vls on ddc.vehicle_id = vls.vehicle_id 
where mdptd.country ilike 'south africa' 
and mdptd.week = date '2026-08-31' 
and mdptd.recon_total_received = 0 
and ddc.status = 'ACTIVE'
QUALIFY ROW_NUMBER() OVER (PARTITION BY ddc.driver_id ORDER BY ddc.start_date DESC) = 1 



--Count of Active drivers >> recon vs uber
with pre_uber AS (
SELECT country, COUNT(DISTINCT u.duuid) AS pre_drivers_uber
FROM recon.recon_input__uber_payments_data u
where date_trunc('week', u."date") = '2026-08-31'
group by country
), post_recon as (
select country,  COUNT(DISTINCT m.drn) AS post_total_drivers
FROM   core_dimensions.mart_driver_weekly_recon m
where m.recon_week = '2026-08-31'
and m.contract_status = 'ACTIVE'
group by country)
select  pu.country,pre_drivers_uber,post_total_drivers
from pre_uber pu
left join post_recon pr on lower(left(pu.country,5)) = lower(left(pr.country,5))



--******** GH Driver Graduation Check *************
--Driver graduation readyness verification/confirmation check
with latest_ptd as (
    select *
    from core_dimensions.mart_driver_paid_to_date
    where drn = 'MVG10324'
    qualify row_number() over (partition by drn order by week desc) = 1
), latest_rfb as (
    select *
    from core_dimensions.mart_driver_weekly_repair_fund_balances
    where drn = 'MVG10324'
    qualify row_number() over (partition by drn order by recon_week desc) = 1
),latest_dwr as (
    select *
    from core_dimensions.mart_driver_weekly_recon
    where drn = 'MVG10324'
    --order by recon_week
    qualify row_number() over (partition by drn order by recon_week desc) = 1
), all_drns AS (
    SELECT drn FROM latest_ptd ptd
    UNION
    SELECT drn FROM latest_rfb rfb
    UNION
    SELECT drn FROM latest_dwr dwr
)
select
    ad.drn
    ,min(ddr.day) as loan_start_date
    ,max(ddr.recon_week) as as_of_EOW
    , ptd.contract_required_remittance as loan_amount
    , ptd.driver_total_received as loan_repaid
    , ptd.contract_required_remittance - ptd.driver_total_received as base_loan_balance
    , rfb.outstanding_repair_fund_balance *-1 as repair_fund_balance --
    , ptd.contract_required_remittance - ptd.driver_total_received - rfb.outstanding_repair_fund_balance as closing_out_final_bal
    , dwr.driver_closing_balance as recon_driver_closing_balance
    ,dwr.driver_closing_balance < 0 AS collect_outstanding
from all_drns ad join 
core_dimensions.mart_driver_daily_recon ddr on ad.drn = ddr.drn
join latest_ptd ptd on ddr.drn = ptd.drn
join latest_rfb rfb on ddr.drn = rfb.drn
join latest_dwr dwr on ddr.drn = dwr.drn
where ddr.drn = 'MVG10324'
group by  ad.drn, ptd.contract_required_remittance, ptd.driver_total_received, rfb.outstanding_repair_fund_balance,dwr.driver_closing_balance 
