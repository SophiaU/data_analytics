# Introduction

This is a common repository used by Data Performance team.
Here we store various sql scripts for data analysis.

I want to push this update to GitHub.
