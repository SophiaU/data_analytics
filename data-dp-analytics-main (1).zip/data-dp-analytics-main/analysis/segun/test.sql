Test query.
