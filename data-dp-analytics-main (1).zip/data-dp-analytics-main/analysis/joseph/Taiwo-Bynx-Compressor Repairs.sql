select bvm.maintenance_reference,bvm.start_date, bvm.reg_no,bvm.model,bvm.type_of_maintenance,bvm.downtime_days,bvm.status,bvm.work_done,bvm.total_job_cost, cvd.carco_name
from dbt.bynx_vehicle_maintenance bvm-- bynx.vehicle_maintenance_history
left join dbt.core__vehicle_domain cvd on bvm.reg_no = cvd.registration_no_cleaned
where work_done like '%compressor%' and cvd.country = 'Nigeria' and bvm.start_date >= '2024-01-01' --and '2024-12-31'
order by bvm.start_date
