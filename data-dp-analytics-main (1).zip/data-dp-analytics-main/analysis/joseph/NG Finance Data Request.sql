

---NG Finance Data Request----
-----Daily All Drivers Data for Nigeria for one Calendar Month---
--Updated on Dec 19 2022-----

select source_file_date as day_date, driveruuid,driverfirstname,driverlastname, 
SUM(payouts)payouts,SUM(payouts__transferredtobankaccount)payouts__transferredtobankaccount,
SUM(payouts__cashcollected)payouts__cashcollected,SUM(paidtothirdparties)paidtothirdparties,
SUM(refunds_expenses)refunds_expenses, SUM(refunds_expenses__refunds__nontripbalance_misc)refunds_expenses__refunds__nontripbalance_misc,
SUM(refunds_expenses__refunds__airportfee)refunds_expenses__refunds__airportfee,
SUM(refunds_expenses__refunds__toll)refunds_expenses__refunds__toll,
SUM(totalearnings__tip)totalearnings__tip,
SUM(totalearnings__yousaved__quest)totalearnings__yousaved__quest,
SUM(totalearnings__netfare)totalearnings__netfare,
SUM(totalearnings)totalearnings,
SUM(payouts__servicefeecollectionreturn)payouts__servicefeecollectionreturn,
SUM(totalearnings__promotions)totalearnings__promotions,
SUM(payouts__arrearscollection)payouts__arrearscollection,
SUM(refunds_expenses__refunds__cleaningandrepairs)refunds_expenses__refunds__cleaningandrepairs,
SUM(totalearnings__taxes)totalearnings__taxes,
SUM(totalearnings__cartopdisplay)totalearnings__cartopdisplay,
SUM(refunds_expenses__refunds__scheduledpayreturn)refunds_expenses__refunds__scheduledpayreturn,
SUM(paidtouber)paidtouber, SUM(paidtouber__bookingfee)paidtouber__bookingfee,
SUM(totalearnings__otherearnings__adjustment)totalearnings__otherearnings__adjustment,
SUM(paidtouber__faresplitfee)paidtouber__faresplitfee,
SUM(totalearnings__otherfees__adjustment)totalearnings__otherfees__adjustment,
SUM(payouts__cashcollection)payouts__cashcollection,
SUM(refunds_expenses__expenses__toll)refunds_expenses__expenses__toll,
Product,Carco,
'Demarcator' as demarcator,
SUM(refunds_expenses__expenses__devicesubscriptionfee)refunds_expenses__expenses__devicesubscriptionfee,
SUM(refunds_expenses__expenses__nontripbalance_misc)refunds_expenses__expenses__nontripbalance_misc,
SUM(refunds_expenses__expenses__nontripbalancemisc)refunds_expenses__expenses__nontripbalancemisc,
SUM(refunds_expenses__expenses__tickets_fines_andtows)refunds_expenses__expenses__tickets_fines_andtows,
SUM(refunds_expenses__expenses__vehiclerelatedfee)refunds_expenses__expenses__vehiclerelatedfee,
SUM(refunds_expenses__refunds__accraairportsurcharge)refunds_expenses__refunds__accraairportsurcharge,
SUM(refunds_expenses__refunds__cleaning_repairs)refunds_expenses__refunds__cleaning_repairs,
SUM(refunds_expenses__refunds__nontripbalancemisc)refunds_expenses__refunds__nontripbalancemisc,
SUM(refunds_expenses__refunds__tickets_fines_andtows)refunds_expenses__refunds__tickets_fines_andtows,
SUM(refunds_expenses__refunds__ticketsfinesandtows)refunds_expenses__refunds__ticketsfinesandtows,
SUM(totalearnings__otherearnings__deliveryadjustment)totalearnings__otherearnings__deliveryadjustment,
SUM(totalearnings__otherearnings__minimumearningspromotionpayout)totalearnings__otherearnings__minimumearningspromotionpayout,
SUM(totalearnings__otherearnings__nighttimecharges)totalearnings__otherearnings__nighttimecharges,
SUM(payouts__uberfeecollectionreturn)payouts__uberfeecollectionreturn,
SUM(paidtorestaurant__restaurantordererrordispute)paidtorestaurant__restaurantordererrordispute,SUM(paidtorestaurant)paidtorestaurant
from (select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
   	         when account in ('6','9','71','72','73','74','75','76') then 'UberX'
             when account in ('7','10','30','31','32','33','34','35','36','37','38','39') then 'UberGo'
             when account in ('20','21','22','23','24','25','26','27','28','29') then 'UberGo'
             when account in ('50','51','52','53','54','55','56','57','58','59') then 'UberHailables'
             when account in ('BOM_1','BOM_2','HYD_1','HYD_2') then 'UberGo'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5') then 'CCO1'
             when account in ('8','11') then 'CCO1'
   	         when account in ('12','14') then 'BIKECO'
   	         when account in ('13','15','16','17') then 'CCO1'
   	         when account in ('18','60','61','62','63','64','65') then 'CCO2'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'CCO3'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'BIKECO'
   	         when account in ('6','9','71','72','73','74','75','76') then 'AccraCCO1'
             when account in ('7','10','30','31','32','33','34','35','36','37','38','39') then 'JBurgCCO1'
             when account in ('20','21','22','23','24','25','26','27','28','29') then 'CPTCCO1'
             when account in ('50','51','52','53','54','55','56','57','58','59') then 'KENCCO1'
             when account in ('BOM_1','BOM_2','HYD_1','HYD_2') then 'INDCCO1'
               else 'Unkown' 
       end as  Carco       
from persistence_uber_daily.all_driver
  )
where country = 'nigeria' and source_file_date between '2023-01-01' and '2023-01-31'
group by source_file_date,driveruuid,driverfirstname,driverlastname,Product,Carco
order by source_file_date,driveruuid,Product,Carco;



--------------------------------------
----Feb 13 2023----
--Checking with Atta to see if the data on the new Supplier account sums to what we currently have---



select * from persistence_uber_weekly.payment where country = 'nigeria' 
and source_file_date = '2023-02-06' and 

select distinct orgalias from persistence_uber_weekly.payment where country quality_reporting_feature= 'nigeria' 
and source_file_date = '2023-02-06';

---Payments File---
select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.payment where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City


---Payments File---
(select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.payment where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City)


---Driver Quality File---
select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.driver_quality where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City


---Driver Performance File---
select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.driver_performance where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City



---Trip Activity File---
select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.trip_activity where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City



---All Drivers File---
select *, 
case when account in ('1','2','3','4','5') then 'UberX'
             when account in ('8','11') then 'UberGoDTE'
   	         when account in ('12','14') then 'UberConnect'
   	         when account in ('13','15','16','17') then 'UberGoDTO18'
   	         when account in ('18','60','61','62','63','64','65') then 'UberGoDTO48_SuzukiAlto'
   	         when account in ('66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'UberGoDTO48_SuzukiSPresso'
   	         when account in ('40','41','42','43','44','45','46','47','48','49') then 'UberMoto'
               else 'Unkown' 
       end as  Product,
case when account in ('1','2','3','4','5','8','11','12','14','13','15','16','17','18','60','61','62','63','64','65',
'66','67','68','69','70','80','81','82','83','84','85','86','87','88','89','90','91','92','93','94') then 'Lagos'
               else 'Unkown' 
       end as  City       
from (select * from persistence_uber_weekly.all_driver where country = 'nigeria' and source_file_date = '2023-02-06' and account not in ('40','41','42','43','44','45','46','47','48','49') )
order by account,Product, City


