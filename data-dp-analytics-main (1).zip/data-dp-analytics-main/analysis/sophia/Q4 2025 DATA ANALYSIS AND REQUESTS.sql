

--------------------------------------
---October 14, 2025----
---South Africa Missing Inputs (Extra Charges, Days Off & Adjustments ) Analysis--
select * from recon_south_africa.reconciliation where week >= '2025-09-22'
and drn in ('MVS10010','MVS10329','MVS15379','MVS12084','MVS22699','MVS16984','MVS19792')
order by drn, week;


select week, drn, days_off, uber_balance, moove_balance, remittance, extra_charges,adjustment_amount,	amount_due,	outstanding, prev_outstanding, cum_outstanding, payables
from recon_south_africa.reconciliation where week = '2025-09-22'
and drn in ('MVS10111',
'MVS10145',
'MVS10147',
'MVS10236',
'MVS10299',
'MVS10314',
'MVS10318',
'MVS10349',
'MVS10355',
'MVS10426',
'MVS10491',
'MVS10521',
'MVS10574',
'MVS10618',
'MVS10771',
'MVS10782',
'MVS10786',
'MVS10912',
'MVS10970',
'MVS11042',
'MVS11055',
'MVS11093',
'MVS11123',
'MVS11374',
'MVS11696',
'MVS11782',
'MVS12028',
'MVS12080',
'MVS12084',
'MVS12130',
'MVS12194',
'MVS12522',
'MVS12568',
'MVS12603',
'MVS12634',
'MVS12641',
'MVS12717',
'MVS12727',
'MVS12753',
'MVS12776',
'MVS12778',
'MVS12781',
'MVS12801',
'MVS12828',
'MVS12886',
'MVS12899',
'MVS12909',
'MVS12910',
'MVS13032',
'MVS13069',
'MVS13088',
'MVS13094',
'MVS13099',
'MVS13108',
'MVS13110',
'MVS13132',
'MVS13168',
'MVS13177',
'MVS13200',
'MVS13220',
'MVS13285',
'MVS13312',
'MVS13322',
'MVS13344',
'MVS13423',
'MVS13620',
'MVS13822',
'MVS13860',
'MVS14101',
'MVS14113',
'MVS14290',
'MVS14365',
'MVS14378',
'MVS14383',
'MVS14406',
'MVS14500',
'MVS14528',
'MVS14542',
'MVS14552',
'MVS14596',
'MVS14633',
'MVS14704',
'MVS14737',
'MVS14865',
'MVS14872',
'MVS14956',
'MVS14994',
'MVS15051',
'MVS15083',
'MVS15299',
'MVS15315',
'MVS15333',
'MVS15342',
'MVS15379',
'MVS15418',
'MVS15486',
'MVS15489',
'MVS15576',
'MVS15604',
'MVS15625',
'MVS15647',
'MVS15671',
'MVS15821',
'MVS15842',
'MVS15893',
'MVS15900',
'MVS15910',
'MVS15971',
'MVS15976',
'MVS15977',
'MVS16033',
'MVS16040',
'MVS16118',
'MVS16126',
'MVS16138',
'MVS16147',
'MVS16162',
'MVS16185',
'MVS16189',
'MVS16194',
'MVS16235',
'MVS16250',
'MVS16378',
'MVS16468',
'MVS16538',
'MVS16642',
'MVS16655',
'MVS16665',
'MVS16669',
'MVS16670',
'MVS16681',
'MVS16686',
'MVS16744',
'MVS16826',
'MVS16952',
'MVS16984',
'MVS16990',
'MVS17016',
'MVS17019',
'MVS17123',
'MVS17157',
'MVS17180',
'MVS17202',
'MVS17297',
'MVS17311',
'MVS17312',
'MVS17368',
'MVS17373',
'MVS17451',
'MVS17452',
'MVS17454',
'MVS17480',
'MVS17502',
'MVS17508',
'MVS17534',
'MVS17564',
'MVS17573',
'MVS17648',
'MVS17678',
'MVS17709',
'MVS17710',
'MVS17769',
'MVS17772',
'MVS17778',
'MVS17810',
'MVS17813',
'MVS17868',
'MVS17878',
'MVS17911',
'MVS17919',
'MVS17936',
'MVS17942',
'MVS17946',
'MVS17947',
'MVS17963',
'MVS17990',
'MVS18001',
'MVS18005',
'MVS18024',
'MVS18031',
'MVS18051',
'MVS18076',
'MVS18087',
'MVS18104',
'MVS18114',
'MVS18148',
'MVS18152',
'MVS18189',
'MVS18190',
'MVS18255',
'MVS18268',
'MVS18276',
'MVS18312',
'MVS18314',
'MVS18346',
'MVS18405',
'MVS18463',
'MVS18483',
'MVS18496',
'MVS18557',
'MVS18583',
'MVS18596',
'MVS18627',
'MVS18629',
'MVS18637',
'MVS18638',
'MVS18640',
'MVS18650',
'MVS18675',
'MVS18683',
'MVS18704',
'MVS18721',
'MVS18731',
'MVS18752',
'MVS18779',
'MVS18852',
'MVS18872',
'MVS18921',
'MVS18944',
'MVS18980',
'MVS19034',
'MVS19054',
'MVS19055',
'MVS19123',
'MVS19158',
'MVS19165',
'MVS19177',
'MVS19195',
'MVS19221',
'MVS19224',
'MVS19263',
'MVS19285',
'MVS19354',
'MVS19363',
'MVS19366',
'MVS19368',
'MVS19385',
'MVS19452',
'MVS19474',
'MVS19492',
'MVS19503',
'MVS19527',
'MVS19536',
'MVS19565',
'MVS19576',
'MVS19592',
'MVS19598',
'MVS19601',
'MVS19630',
'MVS19652',
'MVS19673',
'MVS19677',
'MVS19680',
'MVS19688',
'MVS19715',
'MVS19749',
'MVS19755',
'MVS19767',
'MVS19769',
'MVS19775',
'MVS19777',
'MVS19792',
'MVS19808',
'MVS19812',
'MVS19816',
'MVS19852',
'MVS19859',
'MVS19899',
'MVS19927',
'MVS19937',
'MVS19958',
'MVS20032',
'MVS20063',
'MVS20088',
'MVS20114',
'MVS20120',
'MVS20143',
'MVS20176',
'MVS20212',
'MVS20242',
'MVS20284',
'MVS20286',
'MVS20317',
'MVS20356',
'MVS20358',
'MVS20367',
'MVS20403',
'MVS20410',
'MVS20417',
'MVS20435',
'MVS20436',
'MVS20446',
'MVS20450',
'MVS20454',
'MVS20467',
'MVS20477',
'MVS20483',
'MVS20500',
'MVS20518',
'MVS20529',
'MVS20550',
'MVS20565',
'MVS20579',
'MVS20580',
'MVS20596',
'MVS20603',
'MVS20604',
'MVS20633',
'MVS20645',
'MVS20674',
'MVS20675',
'MVS20686',
'MVS20687',
'MVS20694',
'MVS20697',
'MVS20707',
'MVS20710',
'MVS20723',
'MVS20726',
'MVS20730',
'MVS20751',
'MVS20753',
'MVS20754',
'MVS20761',
'MVS20809',
'MVS20815',
'MVS20818',
'MVS20822',
'MVS20852',
'MVS20883',
'MVS20902',
'MVS20911',
'MVS20932',
'MVS20939',
'MVS20943',
'MVS20959',
'MVS20967',
'MVS20997',
'MVS21003',
'MVS21016',
'MVS21017',
'MVS21022',
'MVS21056',
'MVS21067',
'MVS21070',
'MVS21110',
'MVS21111',
'MVS21120',
'MVS21125',
'MVS21136',
'MVS21137',
'MVS21197',
'MVS21204',
'MVS21236',
'MVS21239',
'MVS21258',
'MVS21261',
'MVS21272',
'MVS21275',
'MVS21294',
'MVS21320',
'MVS21330',
'MVS21347',
'MVS21357',
'MVS21362',
'MVS21363',
'MVS21431',
'MVS21468',
'MVS21472',
'MVS21483',
'MVS21485',
'MVS21509',
'MVS21510',
'MVS21527',
'MVS21548',
'MVS21555',
'MVS21592',
'MVS21617',
'MVS21628',
'MVS21632',
'MVS21635',
'MVS21636',
'MVS21658',
'MVS21673',
'MVS21680',
'MVS21684',
'MVS21712',
'MVS21717',
'MVS21725',
'MVS21727',
'MVS21729',
'MVS21731',
'MVS21746',
'MVS21757',
'MVS21776',
'MVS21780',
'MVS21788',
'MVS21819',
'MVS21820',
'MVS21824',
'MVS21854',
'MVS21873',
'MVS21875',
'MVS21896',
'MVS21904',
'MVS21909',
'MVS21913',
'MVS21917',
'MVS21967',
'MVS21968',
'MVS22043',
'MVS22045',
'MVS22052',
'MVS22081',
'MVS22089',
'MVS22169',
'MVS22308',
'MVS22338',
'MVS22423',
'MVS22425',
'MVS22512',
'MVS17867',
'MVS18502',
'MVS18794',
'MVS18836',
'MVS19282',
'MVS21216',
'MVS21883',
'MVS20744',
'MVS21467',
'MVS19219',
'MVS21597',
'MVS21887',
'MVS21541',
'MVS21677',
'MVS18649',
'MVS20794',
'MVS17240',
'MVS21276',
'MVS19572',
'MVS17922',
'MVS20217',
'MVS19249',
'MVS20762',
'MVS17316',
'MVS17840',
'MVS21534',
'MVS18533',
'MVS20898',
'MVS21743',
'MVS20328',
'MVS17864',
'MVS20473',
'MVS17607',
'MVS22012',
'MVS20024',
'MVS18311',
'MVS17865',
'MVS19973',
'MVS20905',
'MVS17406',
'MVS20327',
'MVS21018',
'MVS13944',
'MVS11842',
'MVS21230',
'MVS21010',
'MVS18441',
'MVS18373',
'MVS21869',
'MVS21556',
'MVS21919',
'MVS17323',
'MVS21081',
'MVS21698',
'MVS21584',
'MVS18644',
'MVS20420',
'MVS15147',
'MVS20566',
'MVS11957',
'MVS20896',
'MVS19365',
'MVS17809',
'MVS18217',
'MVS12883',
'MVS21767',
'MVS19247',
'MVS21670',
'MVS21907',
'MVS21557',
'MVS20975',
'MVS12768',
'MVS21566',
'MVS18564',
'MVS17895',
'MVS19969',
'MVS18359',
'MVS15318',
'MVS19178',
'MVS19095',
'MVS19560',
'MVS21764',
'MVS17636',
'MVS20035',
'MVS21408',
'MVS16232',
'MVS22038',
'MVS20543',
'MVS18238',
'MVS19904',
'MVS21935',
'MVS20252',
'MVS21481',
'MVS21172',
'MVS19129',
'MVS17148',
'MVS20214',
'MVS20758',
'MVS15056',
'MVS21602',
'MVS21447',
'MVS21830',
'MVS17896',
'MVS20484',
'MVS14237',
'MVS16954',
'MVS21814',
'MVS21937',
'MVS16885',
'MVS20763',
'MVS16476',
'MVS20505',
'MVS18085',
'MVS17578',
'MVS21214',
'MVS21145',
'MVS20514',
'MVS18507',
'MVS20588',
'MVS18515',
'MVS20042',
'MVS20594',
'MVS19933',
'MVS21702',
'MVS18569',
'MVS16915',
'MVS20293',
'MVS15940',
'MVS14556',
'MVS17047',
'MVS21605',
'MVS21699',
'MVS21505',
'MVS18600',
'MVS20204',
'MVS16961',
'MVS20321',
'MVS22006',
'MVS16793',
'MVS20290',
'MVS20956',
'MVS20951',
'MVS18396',
'MVS16959',
'MVS17900',
'MVS16778',
'MVS20739',
'MVS18384',
'MVS21277',
'MVS19699',
'MVS19716',
'MVS20200',
'MVS18386',
'MVS21286',
'MVS17984',
'MVS19361',
'MVS19747',
'MVS18756',
'MVS20703',
'MVS16621',
'MVS19000',
'MVS21290',
'MVS20577',
'MVS20618',
'MVS17815',
'MVS20274',
'MVS20458',
'MVS18127',
'MVS19815',
'MVS18159',
'MVS11584',
'MVS21250',
'MVS14173',
'MVS16730');




select * from recon_nigeria.incentive_programs;


---Tolls---
select * from recon_south_africa.reconciliation where week = '2025-09-29'
and toll <>0
order by drn;


---Market Recon Checks----
--SA-
--Validate the toll fix 
select * from recon_south_africa.reconciliation where week = '2025-10-06'
order by drn;

--NG-
--Validate incentives were extended and applied correctly
select * from recon_nigeria.reconciliation_spresso where week = '2025-10-13' and incentives <> 0
order by drn;

---Validate no incentives are applied on SUndays--
select distinct day from recon_nigeria.reconciliation_spresso where week >= '2025-09-22' 
and incentives <> 0;


recon_nigeria.reconciliation_spresso





-----------------------------------------
---October 15, 2025---
--- v2 group of models test the change in source for drn/uber_id mapping
select * from recon.recon_input__driver_profile_v2 limit 100;
select * from recon.recon_input__core_assignments_w_dates_v2;
select * from recon.recon_input__uber_assignment_based_on_trips_v2
select * from recon.recon_input__uber_rental_payments_data_v2;
select * from recon.recon_input__uber_trips_data_v2;

-- v3 model tests the change of the driver superset to use dim_driver 
select * from recon.recon_input__driver_profile_v3;



---Driver Profile COmparison---
select * from recon.recon_input__driver_profile_v2 limit 100;

select * from recon.recon_input__driver_profile limit 100;

with driver_profile_original as (
select * from recon.recon_input__driver_profile
),
driver_profile_v2 as (
select * from recon.recon_input__driver_profile_v2
),
comparison_driver_profile as (

)

-----------------------------------------------------
---First Query Trial---Didn't work, as I'm using Dbeaver----
DO $$
DECLARE
    cols TEXT;
    where_conditions TEXT;
    sql TEXT;
BEGIN
    -- ✅ 1. Build dynamic CASE columns for mismatch details
    SELECT string_agg(
        format(
            $f$
            CASE 
                WHEN (a.%1$I IS DISTINCT FROM b.%1$I) 
                THEN CONCAT('%1$I mismatch: Original=', COALESCE(a.%1$I::TEXT, 'NULL'), ', V2=', COALESCE(b.%1$I::TEXT, 'NULL'))
                ELSE NULL
            END AS %1$I_diff
            $f$,
            column_name
        ),
        ', ' || E'\n'
    )
    INTO cols
    FROM information_schema.columns
    WHERE table_schema = 'recon'       -- 👈 your schema name here
      AND table_name = 'recon_input__driver_profile'
      AND column_name NOT IN ('drn', 'date');
    -- ✅ 2. Build dynamic WHERE clause to detect differences
    SELECT string_agg(
        format('(a.%1$I IS DISTINCT FROM b.%1$I)', column_name),
        ' OR '
    )
    INTO where_conditions
    FROM information_schema.columns
    WHERE table_schema = 'recon'       -- 👈 same schema here
      AND table_name = 'recon_input__driver_profile'
      AND column_name NOT IN ('drn', 'date');
    -- ✅ 3. Combine into main comparison query
    sql := format(
        $q$
        SELECT 
            COALESCE(a.drn, b.drn) AS drn,
            COALESCE(a.date, b.date) AS date,
            CASE 
                WHEN a.drn IS NULL THEN 'Missing in Original'
                WHEN b.drn IS NULL THEN 'Missing in Version 2'
                ELSE 'Present in both'
            END AS record_status,
            %1$s
        FROM recon.recon_input__driver_profile a
        FULL OUTER JOIN recon.recon_input__driver_profile_v2 b
            ON a.drn = b.drn AND a.date = b.date
        WHERE 
            a.drn IS NULL OR 
            b.drn IS NULL OR 
            %2$s
        ORDER BY drn, date;
        $q$,
        cols,
        where_conditions
    );
    -- ✅ 4. Execute and show results
    RAISE NOTICE 'Running query:%', sql;
    EXECUTE sql;
END $$;





--#############################----
----SECOND---
-- Step 1: Generate dynamic SQL
WITH cols AS (
  SELECT string_agg(
      'CASE WHEN (a.' || column_name || ' IS DISTINCT FROM b.' || column_name || ') ' ||
      'THEN CONCAT(''' || column_name || ' mismatch: Original='', COALESCE(a.' || column_name || '::TEXT, ''NULL''), '', V2='', COALESCE(b.' || column_name || '::TEXT, ''NULL'')) ' ||
      'ELSE NULL END AS ' || column_name || '_diff',
      ', ' || E'\n'
    ) AS col_diff,
    string_agg(
      '(a.' || column_name || ' IS DISTINCT FROM b.' || column_name || ')',
      ' OR '
    ) AS where_clause
  FROM information_schema.columns
  WHERE table_schema = 'recon'     -- 👈 your schema
    AND table_name = 'recon_input__driver_profile'
    AND column_name NOT IN ('drn', 'date')
)
SELECT 
'SELECT 
    COALESCE(a.drn, b.drn) AS drn,
    COALESCE(a.date, b.date) AS date,
    CASE 
        WHEN a.drn IS NULL THEN ''Missing in Original''
        WHEN b.drn IS NULL THEN ''Missing in Version 2''
        ELSE ''Present in both''
    END AS record_status,
    ' || col_diff || '
FROM recon.recon_input__driver_profile a
FULL OUTER JOIN recon.recon_input__driver_profile_v2 b
    ON a.drn = b.drn AND a.date = b.date
WHERE a.drn IS NULL OR b.drn IS NULL OR ' || where_clause || '
ORDER BY drn, date;' AS generated_query
FROM cols;




-----FINAL ONE---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn) AS drn,
        COALESCE(a.date, b.date) AS date,
        a.country AS country_original,
        b.country AS country_v2,
        a.city AS city_original,
        b.city AS city_v2,
        a.final_license_plate AS final_license_plate_original,
        b.final_license_plate AS final_license_plate_v2,
        a.uber_id AS uber_id_original,
        b.uber_id AS uber_id_v2,
        a.plan_code AS plan_code_original,
        b.plan_code AS plan_code_v2,
        a.remit_days AS remit_days_original,
        b.remit_days AS remit_days_v2,
        a.original_remit AS original_remit_original,
        b.original_remit AS original_remit_v2,
        a.vehicle_assignment_start_date AS vehicle_assignment_start_date_original,
        b.vehicle_assignment_start_date AS vehicle_assignment_start_date_v2,
        a.vehicle_assignment_end_date AS vehicle_assignment_end_date_original,
        b.vehicle_assignment_end_date AS vehicle_assignment_end_date_v2,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original'
            WHEN b.drn IS NULL THEN 'DRN Missing in Version 2'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Version 2'
            ELSE 'DRN or UberID Present in both'
        END AS record_status
    FROM (select * from recon.recon_input__driver_profile where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06') a
    FULL OUTER JOIN (select * from recon.recon_input__driver_profile_v2 where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06') b
        ON a.drn = b.drn AND a.date = b.date
)
SELECT *
FROM combined
WHERE 
    record_status != 'Present in both'
    OR country_original IS DISTINCT FROM country_v2
    OR city_original IS DISTINCT FROM city_v2
    OR final_license_plate_original IS DISTINCT FROM final_license_plate_v2
    OR uber_id_original IS DISTINCT FROM uber_id_v2
    OR plan_code_original IS DISTINCT FROM plan_code_v2
    OR remit_days_original IS DISTINCT FROM remit_days_v2
    OR original_remit_original IS DISTINCT FROM original_remit_v2
    OR vehicle_assignment_start_date_original IS DISTINCT FROM vehicle_assignment_start_date_v2
    OR vehicle_assignment_end_date_original IS DISTINCT FROM vehicle_assignment_end_date_v2
ORDER BY drn, date;


select * from recon.recon_input__driver_profile where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06';

select * from recon.recon_input__driver_profile_v2 where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06';




-----FINAL TWO - UberID on Driver Profile Validation---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn) AS drn,
        COALESCE(a.date, b.date) AS date,
        a.country AS country_original,
        b.country AS country_v2,
        a.city AS city_original,
        b.city AS city_v2,
        a.final_license_plate AS final_license_plate_original,
        b.final_license_plate AS final_license_plate_v2,
        a.uber_id AS uber_id_original,
        b.uber_id AS uber_id_v2,
        a.plan_code AS plan_code_original,
        b.plan_code AS plan_code_v2,
        a.remit_days AS remit_days_original,
        b.remit_days AS remit_days_v2,
        a.original_remit AS original_remit_original,
        b.original_remit AS original_remit_v2,
        a.vehicle_assignment_start_date AS vehicle_assignment_start_date_original,
        b.vehicle_assignment_start_date AS vehicle_assignment_start_date_v2,
        a.vehicle_assignment_end_date AS vehicle_assignment_end_date_original,
        b.vehicle_assignment_end_date AS vehicle_assignment_end_date_v2,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original'
            WHEN b.drn IS NULL THEN 'DRN Missing in Version 2'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Version 2'
            ELSE 'DRN and UberID Present in both'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id
            THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have *any* column difference
        CASE 
            WHEN a.country IS DISTINCT FROM b.country
              OR a.city IS DISTINCT FROM b.city
              OR a.final_license_plate IS DISTINCT FROM b.final_license_plate
              OR a.plan_code IS DISTINCT FROM b.plan_code
              OR a.remit_days IS DISTINCT FROM b.remit_days
              OR a.original_remit IS DISTINCT FROM b.original_remit
              OR a.vehicle_assignment_start_date IS DISTINCT FROM b.vehicle_assignment_start_date
              OR a.vehicle_assignment_end_date IS DISTINCT FROM b.vehicle_assignment_end_date
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon.recon_input__driver_profile where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06') a
    FULL OUTER JOIN (select * from recon.recon_input__driver_profile_v2 where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06') b
        ON a.drn = b.drn AND a.date = b.date
)
SELECT *
FROM combined
WHERE 
    record_status != 'DRN and UberID Present in both'
    OR has_uberid_difference = 'Yes'
    OR has_difference_other_columns = 'Yes'
ORDER BY drn, date;



---Random Checks
select * from recon.recon_input__driver_profile_v2 
where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06'
and drn = 'MVMX00003';






---Colombia Payouts Investigation---
select * from dbt_recon.recon_output__colombia_payouts;

select * from recon.recon_output__colombia_payouts;

select * from recon.recon_output__weekly_summary 
where lower(country_code) = 'colombia' and week_date = '2025-10-06';  
---where lower(city) in ('bogota','medellin') and week_date = '2025-10-06';  



---------------------------------------------------
---October 16 2025---
select * from dbt.core__vehicle_domain limit 5; 

select * from dbt.core__int_vehicle_status_assignment limit 5;

select * from dbt.core__int_vehicle_status_assignment
where registration_no = 'LV03TTGP'; ---drn = 'MVS18074';

select * from dbt.core__driver_domain limit 5;


select * from core.vehicle_status_history limit 10;

where li reg_no = 'LV03TTGP'
order by last_modified_on desc;

vehicle_status_last_modified




--Vehicle Assignment & Status From CORE 
WITH assignments AS (
  select drn, registration_no, 
  	vehicle_assignment_start_date as effective_start_date, 
  	vehicle_assignment_end_date as effective_end_date, 
  	vehicle_updated_by
  		from dbt.core__vehicle_driver_assignment
  		where drn = 'MVS18074'
) ,
vehicleAssign as (
    select row_number() over (partition by drn order by effective_start_date desc),* 
    from assignments)
SELECT
--  v.country,
  v.city,
  v.carco_name AS car_co,
  vp.partner_product_name AS vehicle_plan,
  va.registration_no AS "Plate Number",
--  v.vin AS vin_no,
  va.drn,
  dd.first_name AS "Driver Name",
  v.vehicle_status,
  effective_start_date,
  effective_end_date,
  vehicle_updated_by AS "Who Assigned the vehicle"
FROM
  vehicleAssign va
LEFT JOIN dbt.core__driver_domain dd ON dd.drn = va.drn
LEFT JOIN dbt.core__vehicle_domain v ON va.registration_no = v.registration_no
LEFT JOIN dbt.core__vehicle_product_plan_assignment vp ON va.registration_no = vp.registration_no
where lower(v.country) in ('ghana', 'nigeria', 'south africa')
order by effective_start_date desc, effective_end_date desc;




SELECT *
FROM recon_south_africa.reconciliation
where week >= '2025-09-29' and drn = 'MVS18074';


---Oct 17, 2025---
select * from recon_ghana.products;



--------------------------------------------------
----Oct 17, 2025---
---Ahmed's Loan book analysis

--Recon Table
SELECT *
    FROM tmp_loan_book.stg_fct_raw_recon
    WHERE country='South Africa';
    
    
----Contract Table--
SELECT *
    FROM tmp_loan_book.stg_fct_contract
    WHERE country='South Africa'
        AND status='Active';

---Vehicle Loan Book--
SELECT *
    FROM tmp_loan_book.fct_vehicle_loan_book_v1
    WHERE country='Nigeria';


---Driver Payment---
SELECT *
    FROM tmp_loan_book.stg_fct_driver_payment
    WHERE country='Nigeria';




----------------------------------------------
---Contracts Table Study---

select * from core.driver_contracts limit 100;

select * from "dev"."dbt_vitalii".dim_contract_template
select * from "dev"."dbt_vitalii".dim_contract_template_hist
select * from "dev"."dbt_vitalii".dim_template_addon_type
select * from "dev"."dbt_vitalii".dim_driver_contract
select * from "dev"."dbt_vitalii".dim_driver_contract_hist
select * from "dev"."dbt_vitalii".fact_contract_addons
select * from "dev"."dbt_vitalii".fact_template_addons



select * from recon.recon_input__driver_profile_v2 where lower(country) = 'mexico' and week between '2025-09-29' and '2025-10-06';


select distinct uber_id from recon.recon_input__driver_profile_v2 where lower(country) = 'mexico'; --and week between '2025-09-29' and '2025-10-06';


select * from recon.recon_input__core_assignments_w_dates_v2 limit 10;

select distinct uber_driver_id from recon.recon_input__core_assignments_w_dates_v2 
where country = 'Mexico';




--------------------------------
---October 20, 2025---


---South Africa Asigned Drivers with Missed & Wrong Charges Analysis----
with sa_Recon as (
select * from recon_south_africa.reconciliation where week = '2025-10-06'
),
assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS assignment_rank,
    case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
	end as assignment_status
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
, week_assignments AS (
  SELECT 
    sr.city,
    sr.drn, sr.week,
    a.vehicle_assignment_start_date,
    a.vehicle_assignment_end_date,
    a.assignment_status,
  a.assignment_rank,
  sr.uber_id,
  sr.is_assigned, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance, toll, 
  sr.remittance, extra_charges, adjustment_amount, adjustment_type, adjustment_description, bank_statement, payouts, moove_balance, 
  sr.outstanding, prev_outstanding, cum_outstanding,
    --a.vehicle_plate,
    -- Rank assignments so the most recent before the week is chosen if none overlap
    ROW_NUMBER() OVER (
      PARTITION BY sr.drn, sr.week
      ORDER BY
        CASE 
          WHEN a.vehicle_assignment_start_date <= (sr.week + INTERVAL '6 day')
           AND (a.vehicle_assignment_end_date IS NULL OR a.vehicle_assignment_end_date >= sr.week)
          THEN 0 ELSE 1 END,  -- 0 means it overlaps the week
        a.vehicle_assignment_end_date DESC NULLS LAST
--      ORDER BY 
--        CASE 
--          WHEN sr.week BETWEEN a.vehicle_assignment_start_date AND COALESCE(a.vehicle_assignment_end_date, sr.week)
--          THEN 0 ELSE 1 END,
--        ABS(EXTRACT(EPOCH FROM (sr.week - a.vehicle_assignment_end_date))) NULLS LAST
    ) AS rk
  FROM sa_recon sr
  LEFT JOIN assignments a
    ON sr.drn = a.drn
),
week_bounds AS (
  SELECT
    drn,
    week as recon_week,
    vehicle_assignment_start_date,
    vehicle_assignment_end_date, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance,
    assignment_status,
    week AS week_start,
    week + INTERVAL '6 days' AS week_end
  FROM week_assignments where rk = 1
),
effective_period AS (
  SELECT
    drn,
    recon_week,
    vehicle_assignment_start_date,
    vehicle_assignment_end_date, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance,
    assignment_status,
    GREATEST(vehicle_assignment_start_date, week_start) AS start_date,
    LEAST(COALESCE(vehicle_assignment_end_date, week_end), week_end) AS end_date
  FROM week_bounds
)
SELECT
  drn,
  recon_week,
  vehicle_assignment_start_date,
  vehicle_assignment_end_date,
  assignment_status,
  start_date,
  end_date,
  CASE
    WHEN end_date <= start_date THEN 0
    ELSE
      (
        -- count days between start_date and end_date (exclusive of both ends)
        ROUND((EXTRACT(EPOCH FROM (end_date::timestamp - start_date::timestamp)) / 86400) --- - 1
        -
        -- subtract Sundays within the range
        FLOOR( ((EXTRACT(EPOCH FROM (end_date::timestamp - start_date::timestamp)) / 86400)
               + EXTRACT(DOW FROM start_date::timestamp)) / 7 ))
      )
  END AS effective_charge_no_of_days,
  days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance
FROM effective_period;
--SELECT 
--  *
--FROM week_assignments
--WHERE rk = 1 ---and drn = 'MVS10010'
--ORDER BY drn, week;




-----FINAL TWO---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn) AS drn,
        COALESCE(a.date, b.date) AS date,
        a.country AS country_original,
        b.country AS country_v2,
        a.city AS city_original,
        b.city AS city_v2,
        a.final_license_plate AS final_license_plate_original,
        b.final_license_plate AS final_license_plate_v2,
        a.uber_id AS uber_id_original,
        b.uber_id AS uber_id_v2,
        a.plan_code AS plan_code_original,
        b.plan_code AS plan_code_v2,
        a.remit_days AS remit_days_original,
        b.remit_days AS remit_days_v2,
        a.original_remit AS original_remit_original,
        b.original_remit AS original_remit_v2,
        a.vehicle_assignment_start_date AS vehicle_assignment_start_date_original,
        b.vehicle_assignment_start_date AS vehicle_assignment_start_date_v2,
        a.vehicle_assignment_end_date AS vehicle_assignment_end_date_original,
        b.vehicle_assignment_end_date AS vehicle_assignment_end_date_v2,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original'
            WHEN b.drn IS NULL THEN 'DRN Missing in Version 2'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Version 2'
            ELSE 'DRN and UberID Present in both'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id
            THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have *any* column difference
        CASE 
            WHEN a.country IS DISTINCT FROM b.country
              OR a.city IS DISTINCT FROM b.city
              OR a.final_license_plate IS DISTINCT FROM b.final_license_plate
              OR a.plan_code IS DISTINCT FROM b.plan_code
              OR a.remit_days IS DISTINCT FROM b.remit_days
              OR a.original_remit IS DISTINCT FROM b.original_remit
              OR a.vehicle_assignment_start_date IS DISTINCT FROM b.vehicle_assignment_start_date
              OR a.vehicle_assignment_end_date IS DISTINCT FROM b.vehicle_assignment_end_date
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon.recon_input__driver_profile where lower(country) = 'south africa' and week between '2025-09-29' and '2025-10-06') a
    FULL OUTER JOIN (select * from recon.recon_input__driver_profile_v2 where lower(country) = 'south africa' and week between '2025-09-29' and '2025-10-06') b
        ON a.drn = b.drn AND a.date = b.date
)
SELECT *
FROM combined
WHERE 
    record_status != 'DRN and UberID Present in both'
    OR has_uberid_difference = 'Yes'
    OR has_difference_other_columns = 'Yes'
ORDER BY drn, date;




--Query to get remit from Contracts---
WITH active_addons AS (
    SELECT
        fta.contract_template_id,
        SUM(fta.addon_charge) AS total_addon_charge
    FROM core_dimensions.fact_template_addons fta
    WHERE fta.soft_deleted = FALSE
    GROUP BY fta.contract_template_id
)
SELECT
    d.drn,
    dc.contract_code,
    ct.template_code,
    ct.remittance AS base_remittance,
    COALESCE(aa.total_addon_charge, 0) AS addon_adjustment,
    ct.remittance + COALESCE(aa.total_addon_charge, 0) AS net_remittance,
    ct.remittance_frequency
FROM core_dimensions.dim_driver_contract dc
JOIN core_dimensions.dim_driver d
ON dc.driver_id = d.driver_id
    JOIN core_dimensions.dim_contract_template ct
    ON dc.template_id = ct.template_id
    LEFT JOIN active_addons aa
    ON ct.template_id = aa.contract_template_id
WHERE dc.status = 'ACTIVE'
  AND d.soft_deleted = FALSE
ORDER BY d.drn, dc.contract_code;




select * from recon_south_africa.reconciliation where week >= '2025-10-06' 
and drn = 'MVS22770';





------------------------------------------
---Validating SA New Loan Book.

WITH historical_paid_to_date AS(
   SELECT 
      UPPER(drn)::VARCHAR AS drn, 
      week_start::DATE AS week, 
      total_received::FLOAT AS total_received
   FROM "default".sa_prev_total_received_sophia
)
, payment_tbl AS(
   SELECT *
   FROM dbt_ahmed.stg_fct_driver_payment
)
, driver_contracts_tbl AS(
   SELECT *
   FROM dbt_vitalii.fact_driver_contracts
)
, dim_driver_tbl AS(
   SELECT *
   FROM core_dimensions.dim_driver
)
, driver_contracts AS(
   WITH last_contract AS(
      SELECT 
         dc.driver_sk,
         dc.start_date AS contract_start_date,
         dc.status AS contract_status,
      ROW_NUMBER() OVER (
         PARTITION BY dc.driver_sk
         ORDER BY dc.start_date ASC
      ) as rn
      FROM driver_contracts_tbl dc 
   )
   SELECT 
     lc.driver_sk,
     dd.drn,
     dd.country,
     lc.contract_start_date,
     lc.contract_status
   FROM last_contract lc
   INNER JOIN dim_driver_tbl dd
      ON lc.driver_sk = dd.driver_sk
)
, paid_to_date_calculation AS(
   WITH driver_week_payments_data AS(
     SELECT 
        country,
        city,
        drn,
        week,
        SUM(uber_balance) AS uber_balance,
        SUM(bank_statement) AS bank_statement,
        SUM(incentives) AS incentives,
        SUM(payouts) AS payouts,
        SUM(extra_charges) AS extra_charges,
        SUM(toll) AS toll,
        SUM(adjustment_amount) AS adjustment_amount,
        MAX(adjustment_type) AS adjustment_type
     FROM payment_tbl
     WHERE 
        entity = 'Moove'
        AND country = 'South Africa'
     GROUP BY ALL
   )
   , selected_payments AS(
      SELECT 
         dc.driver_sk,
         dc.contract_status,
         dp.*
      FROM driver_week_payments_data dp
      INNER JOIN driver_contracts dc
         ON dp.drn = dc.drn
         AND dp.country = dc.country
         AND dp.week >= dc.contract_start_date
   )
   SELECT 
      sp.driver_sk,
      sp.country,
      sp.city,
      sp.drn,
      sp.week,
      SUM(
        sp.uber_balance 
        - sp.toll 
        + sp.bank_statement 
        + sp.incentives  
        - sp.payouts 
        - sp.extra_charges 
        - (
            CASE 
               WHEN sp.adjustment_type ilike '%Agreement of Debt%' 
                   OR sp.adjustment_type ilike '%Driver remit adjustment%' 
                   THEN 0
               ELSE sp.adjustment_amount
            END
        )
      ) AS total_received
   FROM selected_payments sp
   GROUP BY ALL
)
, paid_to_date_adjustment AS(
   WITH comparison_paid_to_date AS(
      SELECT *
      FROM paid_to_date_calculation ptd
      WHERE ptd.week <= (
         SELECT MAX(week)::DATE 
         FROM historical_paid_to_date
      )
   )
   SELECT
      cptd.driver_sk,
      cptd.total_received AS current_total_received,
      hptd.total_received AS historical_total_received,
      historical_total_received - current_total_received AS total_received_adjustment
   FROM comparison_paid_to_date cptd
   FULL OUTER JOIN historical_paid_to_date hptd
      ON cptd.week = hptd.week
      AND cptd.drn = hptd.drn
   GROUP BY ALL
)
SELECT 
   cptd.*,
   pta.total_received_adjustment,
   cptd.total_received + COALESCE(pta.total_received_adjustment, 0) AS driver_total_received
FROM paid_to_date_calculation cptd
LEFT JOIN paid_to_date_adjustment pta
   ON cptd.driver_sk = pta.driver_sk
LIMIT 100;





-----------------------------------
---Oct 21 2025---
select * FROM dbt.core__vehicle_driver_assignment where drn = 'MVS20906';


-------------------------------------------------------
-----Updated New Loan Book Query----
WITH historical_paid_to_date AS(
   SELECT 
      UPPER(drn)::VARCHAR AS drn, 
      DATE_TRUNC('WEEK', week_start::DATE) AS week, 
      total_received::FLOAT AS total_received
   FROM "default".sa_prev_total_received_sophia
)
, payment_tbl AS(
   SELECT *
   FROM tmp_loan_book.stg_fct_driver_payment
)
, driver_contracts_tbl AS(
   SELECT *
   FROM core_dimensions.dim_driver_contract
)
, dim_driver_tbl AS(
   SELECT *
   FROM core_dimensions.dim_driver
)
, driver_contracts AS(
   WITH last_contract AS(
      SELECT 
         dc.driver_id,
         dc.start_date AS contract_start_date,
         dc.status AS contract_status
      FROM driver_contracts_tbl dc
      QUALIFY ROW_NUMBER() OVER (
         PARTITION BY dc.driver_id
         ORDER BY dc.start_date ASC
      ) = 1
   )
   SELECT 
     dd.driver_sk,
     dd.drn,
     dd.country,
     lc.contract_start_date,
     lc.contract_status
   FROM last_contract lc
   INNER JOIN dim_driver_tbl dd
      ON lc.driver_id = dd.driver_id
)
, paid_to_date_calculation AS(
   WITH driver_week_payments_data AS(
     SELECT 
        country,
        city,
        drn,
        week,
        SUM(uber_balance) AS uber_balance,
        SUM(bank_statement) AS bank_statement,
        SUM(incentives) AS incentives,
        SUM(payouts) AS payouts,
        SUM(extra_charges) AS extra_charges,
        SUM(toll) AS toll,
        SUM(adjustment_amount) AS adjustment_amount,
        MAX(adjustment_type) AS adjustment_type
     FROM payment_tbl
     WHERE 
        entity = 'Moove'
        AND country = 'South Africa'
     GROUP BY ALL
   )
   , selected_payments AS(
      SELECT 
         dc.driver_sk,
         dc.contract_status,
         dp.*
      FROM driver_week_payments_data dp
      INNER JOIN driver_contracts dc
         ON dp.drn = dc.drn
         AND dp.country = dc.country
         AND dp.week >= dc.contract_start_date
   )
   , week_paid_to_date AS(
      SELECT 
         sp.driver_sk,
         sp.country,
         sp.city,
         sp.drn,
         sp.week,
         SUM(
         sp.uber_balance 
         - sp.toll 
         + sp.bank_statement 
         + sp.incentives  
         - sp.payouts 
         - sp.extra_charges 
         - (
               CASE 
                  WHEN sp.adjustment_type ilike '%Agreement of Debt%' 
                     OR sp.adjustment_type ilike '%Driver remit adjustment%' 
                     THEN 0
                  ELSE sp.adjustment_amount
               END
         )
         ) AS total_received
      FROM selected_payments sp
      GROUP BY ALL
   )
   SELECT *, 
      SUM(total_received) OVER (
         PARTITION BY drn, country 
         ORDER BY week
         ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      ) AS cumulative_total_received
   FROM week_paid_to_date
)
, paid_to_date_adjustment AS(
   SELECT 
      ptd.driver_sk,
      ptd.country,
      ptd.city,
      ptd.drn,
      ptd.week,
      ptd.total_received AS week_total_received,
      hptd.total_received AS historical_total_received,
      ptd.cumulative_total_received AS current_total_received,
      hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
   FROM paid_to_date_calculation ptd
   INNER JOIN historical_paid_to_date hptd
      ON ptd.drn = hptd.drn
      AND ptd.week = hptd.week
)
SELECT 
   cptd.*,
   pta.historical_total_received,
   pta.total_received_adjustment,
   cptd.cumulative_total_received + COALESCE(pta.total_received_adjustment, 0) AS driver_total_received,
   dc.contract_start_date AS last_contract_start_date,
   dc.contract_status AS last_contract_status
FROM paid_to_date_calculation cptd 
INNER JOIN paid_to_date_adjustment pta
   ON cptd.driver_sk = pta.driver_sk
   AND cptd.week >= pta.week
INNER JOIN driver_contracts dc
   ON cptd.drn = dc.drn
   AND cptd.country = dc.country
   AND cptd.week >= dc.contract_start_date
ORDER BY drn, week;
-- SELECT *
-- FROM tmp_loan_book.stg_fct_driver_payment
-- WHERE drn = 'MVS21403'

-- SELECT COUNT(DISTINCT drn), 
-- FROM paid_to_date_calculation

-- SELECT *
-- FROM  driver_contracts
-- -- LIMIT 100;



select
	drn,
	"day",
	day_in_the_lease_lifecycle,
	driver_closing_balance,
	deposit_closing_balance,
	country
from
	(
	select
		drn,
		"day",
		cumulative_effective_days as day_in_the_lease_lifecycle,
		driver_closing_balance,
		deposit_closing_balance,
		country_code as country,
		country,
		row_number() over(partition by drn
	order by
		"day" desc )as rn
	from
		recon.daily_recon_output
		where "day" < 'recon_start_date' )
where
	rn = 1 );









-----------------------------

---Mexico---
select * from recon.raw_daily_recon_output
where drn = 'MVMX00640';



--------------------------------------
---Missing Payment on Payment Aggregator

select transaction_date, country_code, count(*)
from (SELECT s.payment_unique_reference,
             s.driver_number,
             s.amount,
             s.currency,
             s.transaction_date,
             s.created           as source_created,
             s.payment_gateway,
             s.status,
             s.country_code
      FROM "default".aggregated_tx_source_backup s
               LEFT JOIN payments_aggregator.aggregated_transactions t
                         ON s.payment_unique_reference = t.payment_unique_reference
      WHERE t.payment_unique_reference IS NULL
      ORDER BY s.transaction_date DESC, s.created DESC)
group by transaction_date, country_code;



select count(*), min(transaction_date)as d, payment_unique_reference, created
from payments_aggregator.aggregated_transactions
group by payment_unique_reference, created
having count(*) > 1;


select * from payments_aggregator.aggregated_transactions_backup_2025_10_21 limit 10;

payments_aggregator




select * from tmp_loan_book.stg_fct_recon limit 10;



----------------------------------------------------------
---Oct 21, 2025---
---Stage Fact Table Validation----

with sa_recon as (
select * from recon_south_africa.reconciliation where week = '2025-10-06' 
),
loan_recon_table as (
select * from tmp_loan_book.stg_fct_recon where lower(country) = 'south africa' and week = '2025-10-06'
)


-----RECON COMPARISON: ORIGINAL AND NEW LOANBOOK SOURCE---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn) AS drn,
        COALESCE(a.week, b.week) AS week,
        a.country AS country_originalrecon,
        b.country AS country_fctrecon,
        a.uber_id AS uber_id_originalrecon,
        b.uber_id AS uber_id_fctrecon,
        a.effective_days AS effective_days_recon,
        b.effective_days AS effective_days_fct,
        a.refund_and_expenses AS refund_and_expenses_originalrecon,
        b.refund_and_expenses AS refund_and_expenses_fctrecon,
        a.uber_balance AS uber_balance_originalrecon,
        b.uber_balance AS uber_balance_fctrecon,
        a.remittance AS remittance_originalrecon,
        b.remittance AS remittance_fctrecon,
        a.prev_outstanding AS prev_outstanding_originalrecon,
        b.prev_outstanding AS prev_outstanding_fctrecon,
        a.cum_outstanding AS cum_outstanding_originalrecon,
        b.cumm_outstanding AS cum_outstanding_fctrecon,
        a.bank_statement AS bank_statement_originalrecon,
        b.bank_statement AS bank_statement_fctrecon,
        a.adjustment_amount AS adjustment_amount_originalrecon,
        b.adjustment_amount AS adjustment_amount_fctrecon,
        a.cum_outstanding - a.prev_outstanding as week_outstanding_originalrecon,
        b.cumm_outstanding - b.prev_outstanding as week_outstanding_fctrecon,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
            WHEN b.drn IS NULL THEN 'DRN Missing in FCT Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in FCT Recon'
            ELSE 'DRN and UberID Present in both'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id
            THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have Cumulative Outstanding difference
        CASE 
            WHEN a.cum_outstanding IS DISTINCT FROM b.cumm_outstanding
            THEN 'Yes'
            ELSE 'No'
        END AS has_cum_outstanding_difference,
        ----Flag rows that have *any* column difference
        CASE 
            WHEN a.country IS DISTINCT FROM b.country
              OR a.effective_days IS DISTINCT FROM b.effective_days
              OR a.uber_balance IS DISTINCT FROM b.uber_balance
              OR a.refund_and_expenses IS DISTINCT FROM b.refund_and_expenses
              OR a.remittance IS DISTINCT FROM b.remittance
              OR a.prev_outstanding IS DISTINCT FROM b.prev_outstanding
              OR a.bank_statement IS DISTINCT FROM b.bank_statement
              OR a.adjustment_amount IS DISTINCT FROM b.adjustment_amount
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon_south_africa.reconciliation where week = '2025-08-01' ) a
    FULL OUTER JOIN (select * from tmp_loan_book.stg_fct_recon where lower(country) = 'south africa' and week = '2025-08-01') b
        ON a.drn = b.drn AND a.week = b.week
)
SELECT *
FROM combined
WHERE 
    record_status != 'DRN and UberID Present in both'
    OR has_uberid_difference = 'Yes'
    OR has_cum_outstanding_difference = 'Yes'
    OR has_difference_other_columns = 'Yes'
ORDER BY drn, week;





select country, drn, uber_id, week, 
sum(effective_days)effective_days, sum(uber_balance)uber_balance, sum(refund_and_expenses)refund_and_expenses, 
sum(remittance)remittance, sum(prev_outstanding)prev_outstanding, sum(bank_statement)bank_statement, sum(adjustment_amount)adjustment_amount, 
sum(cumm_outstanding)cumm_outstanding, sum(), sum(), sum(), 
from tmp_loan_book.stg_fct_recon



WITH ranked_recon AS (
  SELECT
    driver_id,
    week_start_date,              -- assuming this column identifies the week
    cumm_outstanding,
    ROW_NUMBER() OVER (
      PARTITION BY driver_id, week_start_date
      ORDER BY updated_at DESC
    ) AS rn
  FROM recon
)
SELECT
  driver_id,
  week_start_date,
  cumm_outstanding
FROM ranked_recon
WHERE rn = 1;





--------------------------------------------------
---Oct 23 2025---

--Duplicate transactions - payments_aggregator.aggregated_transactions_backup_2025_10_21
--Missing transaction resides in "default".aggregated_tx_source_backup
--Current de-duplicated data flowing into recon: payments_aggregator.aggregated_transactions

select * from payments_aggregator.aggregated_transactions_backup_2025_10_21 ---limit 10;
where driver_number = 'DRN016767'
order by transaction_date;


--------------------
----New Recon Validation---
select * from
tmp_loan_book.stg_fct_recon limit 10; 

---Ahmed's Loan Book source
select * from
tmp_loan_book.stg_fct_recon
where week = '2025-10-06' and drn = 'MVS19447';


-----Vitali Legacy---
select * from
dbt_vitalii.int_recon_daily__legacy
where recon_week = '2025-10-06' and drn = 'MVS19447';


----Fact Recon Model---
select * from
dbt.fact_recon_daily ---limit 10;
where recon_week = '2025-10-06' and drn = 'MVS19447';






-----RECON COMPARISON: ORIGINAL, LEGACY & FACT RECON---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn, c.drn, d.drn) AS drn,
        COALESCE(a.week, b.week, c.recon_week, d.recon_week) AS week,
        a.country AS country_originalrecon,
        b.country AS country_loanfctrecon,
        c.country AS country_vitalilegacy,
        d.country AS country_factmodel,
        a.uber_id AS uber_id_originalrecon,
        b.uber_id AS uber_id_loanfctrecon,
        c.uber_id AS uber_id_vitalilegacy,
        d.uber_id AS uber_id_factmodel,
        a.effective_days AS effective_days_originalrecon,
        b.effective_days AS effective_days_loanfctrecon,
        c.effective_days AS effective_days_vitalilegacy,
        d.effective_days AS effective_days_factmodel,
        a.trips AS trips_originalrecon,
        null AS trips_loanfctrecon,
        c.trips AS trips_vitalilegacy,
        d.trips AS trips_factmodel,
        a.supply_hours AS supply_hours_originalrecon,
        null AS supply_hours_loanfctrecon,
        c.supply_hours AS supply_hours_vitalilegacy,
        d.supply_hours AS supply_hours_factmodel,
        a.uber_balance AS uber_balance_originalrecon,
        b.uber_balance AS uber_balance_loanfctrecon,
        c.uber_payments_partner_balance AS uber_balance_vitalilegacy,
        d.uber_payments_partner_balance AS uber_balance_factmodel,
        a.bank_statement AS bank_statement_originalrecon,
        b.bank_statement AS bank_statement_loanfctrecon,
        c.payments_payins AS bank_statement_vitalilegacy,
        d.payments_payins AS bank_statement_factmodel,
        a.adjustment_amount AS adjustment_amount_originalrecon,
        b.adjustment_amount AS adjustment_amount_loanfctrecon,
        c.adjustments AS adjustments_vitalilegacy,
        d.adjustments AS adjustments_factmodel,
        a.outstanding AS week_outstanding_originalrecon,
        b.cumm_outstanding - b.prev_outstanding AS week_outstanding_loanfctrecon,
        c.driver_balance_for_the_period AS week_outstanding_vitalilegacy,
        d.driver_balance_for_the_period AS week_outstanding_factmodel,
        a.remittance AS remittance_originalrecon,
        b.remittance AS remittance_loanfctrecon,
        c.driver_remit_for_the_period AS remittance_vitalilegacy,
        d.driver_remit_for_the_period AS remittance_factmodel,
        a.prev_outstanding AS prev_outstanding_originalrecon,
        b.prev_outstanding AS prev_outstanding_loanfctrecon,
        c.driver_opening_balance AS prev_outstanding_vitalilegacy,
        d.driver_opening_balance AS prev_outstanding_factmodel,
        a.cum_outstanding AS cum_outstanding_originalrecon,
        b.cumm_outstanding AS cum_outstanding_loanfctrecon,
        c.driver_closing_balance AS cum_outstanding_vitalilegacy,
        d.driver_closing_balance AS cum_outstanding_factmodel,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
            WHEN b.drn IS NULL THEN 'DRN Missing in Loan FCT Recon'
            WHEN c.drn IS NULL THEN 'DRN Missing in Vitali Legacy Recon'
            WHEN d.drn IS NULL THEN 'DRN Missing in Fact Model Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Loan FCT Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Vitali Legacy Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Fact Model Recon'
            ELSE 'DRN and UberID Present in all'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
            WHEN a.uber_id IS DISTINCT FROM c.uber_id THEN 'Yes'
            WHEN a.uber_id IS DISTINCT FROM d.uber_id THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have Cumulative Outstanding difference
        CASE 
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.cumm_outstanding) THEN 'Yes'
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(c.driver_closing_balance) THEN 'Yes'
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(d.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_cum_outstanding_difference,
        ----Flag rows that have any column difference
        CASE 
            WHEN a.country IS DISTINCT FROM d.country
              OR a.effective_days IS DISTINCT FROM d.effective_days
              OR a.uber_balance IS DISTINCT FROM d.uber_payments_partner_balance
              OR a.bank_statement IS DISTINCT FROM d.payments_payins
              OR a.remittance IS DISTINCT FROM d.driver_remit_for_the_period
              OR a.prev_outstanding IS DISTINCT FROM d.driver_opening_balance
              OR a.trips IS DISTINCT FROM d.trips
              OR a.adjustment_amount IS DISTINCT FROM d.adjustments
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon_south_africa.reconciliation where week >= '2025-08-04' ) a
    FULL OUTER JOIN (select * from tmp_loan_book.stg_fct_recon where lower(country) = 'south africa' and week >= '2025-08-04') b
        ON a.drn = b.drn AND a.week = b.week
    FULL OUTER JOIN (select * from dbt_vitalii.int_recon_daily__legacy where lower(country) = 'south africa' and recon_week >= '2025-08-04') c
        ON a.drn = c.drn AND a.week = c.recon_week
    FULL OUTER JOIN (select * from dbt.fact_recon_daily where lower(country) = 'south africa' and recon_week >= '2025-08-04') d
        ON a.drn = d.drn AND a.week = d.recon_week
)
SELECT *
FROM combined
WHERE has_difference_other_columns = 'Yes';


    (record_status != 'DRN and UberID Present in all'
    OR has_uberid_difference = 'Yes'
    OR has_cum_outstanding_difference = 'Yes'
    OR has_difference_other_columns = 'Yes');



    and drn in (
    'MVS19388',
'MVS21403',
'MVS14157',
'MVS22276',
'MVS20675',
'MVS20662',
'MVS17486',
'MVS22342',
'MVS22319',
'MVS21361',
'MVS19346',
'MVS21420',
'MVS22324',
'MVS20218',
'MVS19923',
'MVS11503',
'MVS22306',
'MVS21280',
'MVS19447',
'MVS21072',
'MVS21888',
'MVS22378',
'MVS19483',
'MVS22389',
'MVS20300',
'MVS22359',
'MVS19323',
'MVS21367'
    )
ORDER BY drn, week;





{
    "drn": "MVS10507",
    "day": "2023-09-04",
    "count": 2
  },
  {
    "drn": "MVS13227",
    "day": "2023-09-18",
    "count": 2
  },
  {
    "drn": "MVS13227",
    "day": "2023-09-11",
    "count": 2
  },
  {
    "drn": "MVS14209",
    "day": "2023-05-01",
    "count": 2
  },
  {
    "drn": "MVS15955",
    "day": "2023-07-10",
    "count": 2
  }
  
  'MVS10507', 'MVS13227', 'MVS14209', 'MVS15955'
select * from recon_south_africa.reconciliation where week = '2023-07-10'
  and drn = 'MVS15955';

select * from (
SELECT * FROM reconciliation_history.drivers_data_reconciliation_cape_town
			union all
			SELECT * FROM reconciliation_history.drivers_data_reconciliation_johannesburg)
where week  = '2023-07-10' and drn = 'MVS15955';


------------------------------------------
-----October 24, 2025----

select * from tmp_loan_book.stg_fct_recon
where week = '2025-09-15' and drn = 'MVS11503';



----Checks for drns appearing twice for one date.
select * from partners_data_weekly.mv_uber_harmonized_payments_order
where source_file_date = '2023-05-01' and driveruberid = '3af5f368-647a-4a39-9ec0-a26462fdf23b';


select * from partners_data_weekly.vw_uber_driver_aggr
where week_no = '2023-05-01' and driveruuid = '3af5f368-647a-4a39-9ec0-a26462fdf23b';

  'MVS10507', 'MVS13227', 'MVS14209', 'MVS15955'

select * from partners_data_weekly.vw_uber_driver_aggr
where week_no in ('2023-07-10') and drn = 'MVS15955';


{
    "drn": "MVS10507",
    "day": "2023-09-04",
    "count": 2
  },
  {
    "drn": "MVS13227",
    "day": "2023-09-18",
    "count": 2
  },
  {
    "drn": "MVS13227",
    "day": "2023-09-11",
    "count": 2
  },
  {
    "drn": "MVS14209",
    "day": "2023-05-01",
    "count": 2
  },
  {
    "drn": "MVS15955",
    "day": "2023-07-10",
    "count": 2
  }

  
  
  select * from recon_south_africa.reconciliation where week = '2023-07-10'
  and drn = 'MVS15955';
  
  
  
  
  
  ------------------------------------------
-----October 27, 2025----
  
---NG Drivers Missing in Audit--
  
  select * from reconciliation_history.drivers_outstanding_report_uberx_lagos
  where drns in (
  'DRN001758',
'DRN001938',
'DRN002529',
'DRN002664',
'DRN002612',
'DRN018027',
'DRN005445',
'DRN011862',
'DRN005753',
'DRN002331',
'DRN008243',
'DRN002016',
'DRN002530',
'DRN002598',
'DRN005714',
'DRN004788',
'DRN002659',
'DRN003914',
'DRN002694',
'DRN001212',
'DRN013182',
'DRN000515',
'DRN001302',
'DRN002247',
'DRN001312',
'DRN001006',
'DRN000951',
'DRN000583',
'DRN005359',
'DRN001357',
'DRN005426',
'DRN002094',
'DRN007808',
'DRN013180',
'DRN002096',
'DRN002713',
'DRN003688',
'DRN004752',
'DRN002596',
'DRN002464',
'DRN003511',
'DRN001608',
'DRN004959',
'DRN002576',
'DRN001186',
'DRN004478',
'DRN006684',
'DRN005062',
'DRN002103',
'DRN004376'
  );
  
  
  
------------------------------------------
----October 28 2025---
  ---New SA Auto-Recon Checks--

select * from recon.raw_daily_recon_output rdro
where lower(rdro.country) = 'south africa';

select * from recon.daily_recon_output
where lower(country) = 'south africa';


select * from dbt.fact_recon_daily where lower(country) = 'south africa' and recon_week = '2025-10-13';


select max(recon_week) as max_week from dbt.fact_recon_daily where lower(country) = 'south africa';





select * from recon.daily_recon_output
where drn = '' and week = '2025-10-20';




--------------------------------------------------
----October 29 2025----

select * from reconciliation_history.drivers_data_reconciliation_cape_town
where drn = 'MVS15955' and week ='2023-07-10';

select * from reconciliation_history.drivers_data_reconciliation_johannesburg
where drn = 'MVS15955' and week ='2023-07-10';

select * from recon_south_africa.reconciliation
where drn = 'MVS15955' and week ='2023-07-10';

select * from tmp_loan_book.stg_fct_recon
where drn = 'MVS15955' and week ='2023-07-10';




----India Incentive Investigation---
select * from partners_data_weekly.mv_uber_harmonized_driver_quality

select * from 
where 'MVIN18965';






----------------------------------
---October 30 2025---

select min(payouts) as payouts from recon_south_africa.reconciliation
where week >= '2025-07-01';

select distinct payouts from recon_south_africa.reconciliation
where week >= '2025-10-06';



----------------------------------
---October 31 2025---

select * from recon_nigeria.incentive_programs



select * from partners_data_weekly.mv_uber_harmonized_payments_order ---limit 5;
where org_id like "%ZAF%" and source_file_date = '2025-10-20' limit 100;


partners_data_weekly.mv_uber_harmonized_driver_activity

select * from persistence_uber_api_reports_weekly.payments_order_report limit 10;

select distinct created_date from persistence_uber_api_reports_weekly.payments_order_report
where source_file_date >= '2025-08-15' and country ilike '%south%'
order by created_date;

select distinct updated_date from persistence_uber_api_reports_weekly.payments_order_report
where source_file_date >= '2025-08-15' and country ilike '%south%'
order by updated_date;

select distinct updated_date from persistence_uber_api_reports_weekly.uber_driver_aggr
where country = 'South Africa' and event_date >= '2025-08-15'
order by updated_date desc;


select distinct updated_date from partners_data_weekly.vw_uber_driver_aggr
where event_date >= '2025-08-15' and country ilike '%south%'
order by updated_date;





------------------------------------
------Nov 3 2025----

WITH historical_paid_to_date AS (
  SELECT
    UPPER(drn)::VARCHAR AS drn
    , DATE_TRUNC('WEEK', week_start::DATE) AS week
    , total_received::FLOAT AS total_received
  FROM "default".sa_prev_total_received_sophia
)
, payment_tbl AS (
  SELECT
    country
    , city
    , drn
    , week
    , day
    , uber_balance
    , bank_statement
    , incentives
    , payouts
    , extra_charges
    , toll
    , adjustment_amount
    , adjustment_type AS adjustment_type
  FROM tmp_loan_book.stg_fct_driver_payment
  WHERE country = 'South Africa'
)
, driver_contracts_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver_contract
)
, dim_driver_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver
)
, calendar AS (
  SELECT DISTINCT DATE_TRUNC('WEEK', date) AS week
  FROM tmp_loan_book.stg_dim_daily_calendar
  WHERE date <= CURRENT_DATE
)
, driver_contracts AS (
  WITH last_contract AS (
    SELECT
      dc.driver_id
      , dc.start_date AS contract_start_date
      , dc.status AS contract_status
    FROM driver_contracts_tbl dc
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY dc.driver_id
      ORDER BY dc.start_date ASC
    ) = 1
  )
  SELECT
    dd.driver_sk
    , dd.drn
    , dd.driver_id
    , dd.country
    , lc.contract_start_date
    , lc.contract_status
  FROM last_contract lc
  INNER JOIN dim_driver_tbl dd
    ON lc.driver_id = dd.driver_id
)
, paid_to_date_calculation AS (
  WITH driver_week_payments_data AS (
    SELECT
      country
      , city
      , drn
      , week
      , SUM(uber_balance) AS uber_balance
      , SUM(bank_statement) AS bank_statement
      , SUM(incentives) AS incentives
      , SUM(payouts) AS payouts
      , SUM(extra_charges) AS extra_charges
      , SUM(toll) AS toll
      , SUM(adjustment_amount) AS adjustment_amount
      , MAX(adjustment_type) AS adjustment_type
    FROM payment_tbl
    GROUP BY country, city, drn, week
  )
  , selected_payments AS (
    SELECT
      dc.driver_sk
      , dc.contract_status
      , dp.*
    FROM driver_week_payments_data dp
    INNER JOIN driver_contracts dc
      ON dp.drn = dc.drn
        AND dp.country = dc.country
        AND dp.week >= dc.contract_start_date
  )
  , week_paid_to_date AS (
    SELECT
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
      , SUM(
        sp.uber_balance
        - sp.toll
        + sp.bank_statement
        + sp.incentives
        - sp.payouts
        - sp.extra_charges
        - (
          CASE
            WHEN sp.adjustment_type ILIKE '%Agreement of Debt%'
              OR sp.adjustment_type ILIKE '%Driver remit adjustment%'
              THEN 0
            ELSE sp.adjustment_amount
          END
        )
      ) AS total_received
    FROM selected_payments sp
    GROUP BY
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
  )
  SELECT
    *
    , SUM(total_received) OVER (
      PARTITION BY drn, country
      ORDER BY week
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_total_received
  FROM week_paid_to_date
)
, paid_to_date_calendar AS (
  WITH paid_to_date_all_weeks AS (
    SELECT
      c.week
      , dc.country
      , dc.driver_sk
      , dc.driver_id
      , dc.drn
      , COALESCE(ptd.total_received, 0) AS week_total_received
      , ptd.cumulative_total_received
    FROM calendar c
    INNER JOIN driver_contracts dc
      ON TRUE
    INNER JOIN (
      SELECT
        driver_sk
        , MIN(week) AS min_week
      FROM paid_to_date_calculation
      GROUP BY driver_sk
    ) mw
      ON dc.driver_sk = mw.driver_sk
        AND c.week >= mw.min_week
    LEFT JOIN paid_to_date_calculation ptd
      ON c.week = ptd.week
        AND dc.driver_sk = ptd.driver_sk
  )
  SELECT
    week
    , country
    , driver_sk
    , driver_id
    , drn
    , week_total_received
    , LAST_VALUE(cumulative_total_received IGNORE NULLS)
      OVER (
        PARTITION BY driver_sk
        ORDER BY week
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
    AS cumulative_total_received
  FROM paid_to_date_all_weeks
)
, paid_to_date_adjustment AS (
  SELECT
    ptd.driver_sk
    , ptd.country
    -- ptd.city,
    , ptd.drn
    , ptd.week
    , ptd.week_total_received
    , hptd.total_received AS historical_total_received
    , ptd.cumulative_total_received AS current_total_received
    , hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
  FROM paid_to_date_calendar ptd
  INNER JOIN historical_paid_to_date hptd
    ON ptd.drn = hptd.drn
      AND ptd.week = hptd.week
)
SELECT
  cptd.*
  , pta.historical_total_received
  , pta.total_received_adjustment
  , cptd.cumulative_total_received + COALESCE(pta.total_received_adjustment, 0) AS driver_total_received
  , dc.contract_start_date AS last_contract_start_date
  , dc.contract_status AS last_contract_status
FROM paid_to_date_calendar cptd
INNER JOIN paid_to_date_adjustment pta
  ON cptd.driver_sk = pta.driver_sk
    AND cptd.week >= pta.week
INNER JOIN driver_contracts dc
  ON cptd.drn = dc.drn
    AND cptd.country = dc.country
    AND cptd.week >= dc.contract_start_date
WHERE cptd.week <= '2025-10-20'
ORDER BY cptd.driver_sk, cptd.week;




recon.recon_output__weekly_summary
-------------------------------------------------
----Nov 04 2025----
select * from recon.recon_output__weekly_summary
where week_date = '2025-10-27' and country = 'Colombia';

select * from recon.daily_recon_output
where recon_week = '2025-10-27' and country = 'Colombia';


select * from recon.daily_recon_output
where recon_week >= '2025-10-06' and country = 'Colombia'
and drn = 'MVCO00349';

select distinct previous_day_drn_was_on_recon, count(distinct drn)drn from recon.daily_recon_output
where day = '2025-10-27' and country = 'Colombia'
group by previous_day_drn_was_on_recon;

select distinct previous_day_drn_was_on_recon, count(drn)drn from recon.daily_recon_output
where recon_week = '2025-10-27' and country in ('Colombia', 'Mexico')
group by previous_day_drn_was_on_recon;


select distinct previous_day_drn_was_on_recon, country, count(distinct drn)drn from recon.daily_recon_output
where day = '2025-10-27' and country in ('Colombia', 'Mexico')
group by previous_day_drn_was_on_recon, country;

cumulative_effective_days








--------------------------------------------
---Check India Incentive Issue---

select * from partners_data_daily.mv_uber_harmonized_driver_quality
where driveruuid = 'd69b637b-43b1-4a54-b348-ac3722b4446b' and source_file_date >= '2025-10-06';


------------------------------------
------November 5 2025----
---Validating the Closing Balance Records For LatAm After SA auto-recon Update----

---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon.daily_recon_output
    WHERE week < '2025-10-27' ---get the Monday date of last week.
    and status = 'PUBLISHED'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < '2025-10-27' ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, min(day) as min_day
    FROM recon.daily_recon_output
    WHERE week = '2025-10-27' ---get the Monday date of last week.
    and status = 'DRAFT'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-10-27' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.driver_closing_balance as previous_last_driver_closing_balance, a.driver_opening_balance as this_week_driver_opening_balance,
    case 
        when ABS(ROUND(b.driver_closing_balance,0) - ROUND(a.driver_opening_balance,0)) <= 1 then 'ok'
        else 'fail'
    end as  balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;









---UPDATED DRIVER BALANCE CHECK SCRIPT -SOUTH AFRICA
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon_south_africa.reconciliation
    WHERE week < '2025-10-27' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < '2025-10-27' ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, min(day) as min_day
    FROM recon_south_africa.reconciliation
    WHERE week = '2025-10-27' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-10-27' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.cum_outstanding as previous_last_driver_closing_balance, a.prev_outstanding as this_week_driver_opening_balance,
    case 
        when ABS(ROUND(b.cum_outstanding,0) - ROUND(a.prev_outstanding,0)) <= 1 then 'ok'
        else 'fail'
    end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;



---UPDATED DRIVER BALANCE CHECK SCRIPT -SOUTH AFRICA
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon_south_africa.reconciliation
    WHERE week < '2025-10-27' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < '2025-10-27' ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, min(day) as min_day
    FROM recon_south_africa.reconciliation
    WHERE week = '2025-10-27' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-10-27' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.cum_outstanding as previous_last_driver_closing_balance, a.prev_outstanding as this_week_driver_opening_balance,
    case 
        when ABS(ROUND(b.cum_outstanding,0) - ROUND(a.prev_outstanding,0)) <= 1 then 'ok'
        else 'fail'
    end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;




----------------------------------------------
----Nov 5, 2025---
----Auto Recon 2.0 is live for South Africa. Comparing its output with Legacy Recon---

select * from core_dimensions.mart_driver_weekly_recon limit 10;


-----RECON COMPARISON: ORIGINAL, LEGACY & FACT RECON---
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn, c.drn, d.drn) AS drn,
        COALESCE(a.week, b.week, c.recon_week, d.recon_week) AS week,
        a.country AS country_originalrecon,
        b.country AS country_loanfctrecon,
        c.country AS country_vitalilegacy,
        d.country AS country_factmodel,
        a.uber_id AS uber_id_originalrecon,
        b.uber_id AS uber_id_loanfctrecon,
        c.uber_id AS uber_id_vitalilegacy,
        d.uber_id AS uber_id_factmodel,
        a.effective_days AS effective_days_originalrecon,
        b.effective_days AS effective_days_loanfctrecon,
        c.effective_days AS effective_days_vitalilegacy,
        d.effective_days AS effective_days_factmodel,
        a.trips AS trips_originalrecon,
        null AS trips_loanfctrecon,
        c.trips AS trips_vitalilegacy,
        d.trips AS trips_factmodel,
        a.supply_hours AS supply_hours_originalrecon,
        null AS supply_hours_loanfctrecon,
        c.supply_hours AS supply_hours_vitalilegacy,
        d.supply_hours AS supply_hours_factmodel,
        a.uber_balance AS uber_balance_originalrecon,
        b.uber_balance AS uber_balance_loanfctrecon,
        c.uber_payments_partner_balance AS uber_balance_vitalilegacy,
        d.uber_payments_partner_balance AS uber_balance_factmodel,
        a.bank_statement AS bank_statement_originalrecon,
        b.bank_statement AS bank_statement_loanfctrecon,
        c.payments_payins AS bank_statement_vitalilegacy,
        d.payments_payins AS bank_statement_factmodel,
        a.adjustment_amount AS adjustment_amount_originalrecon,
        b.adjustment_amount AS adjustment_amount_loanfctrecon,
        c.adjustments AS adjustments_vitalilegacy,
        d.adjustments AS adjustments_factmodel,
        a.outstanding AS week_outstanding_originalrecon,
        b.cumm_outstanding - b.prev_outstanding AS week_outstanding_loanfctrecon,
        c.driver_balance_for_the_period AS week_outstanding_vitalilegacy,
        d.driver_balance_for_the_period AS week_outstanding_factmodel,
        a.remittance AS remittance_originalrecon,
        b.remittance AS remittance_loanfctrecon,
        c.driver_remit_for_the_period AS remittance_vitalilegacy,
        d.driver_remit_for_the_period AS remittance_factmodel,
        a.prev_outstanding AS prev_outstanding_originalrecon,
        b.prev_outstanding AS prev_outstanding_loanfctrecon,
        c.driver_opening_balance AS prev_outstanding_vitalilegacy,
        d.driver_opening_balance AS prev_outstanding_factmodel,
        a.cum_outstanding AS cum_outstanding_originalrecon,
        b.cumm_outstanding AS cum_outstanding_loanfctrecon,
        c.driver_closing_balance AS cum_outstanding_vitalilegacy,
        d.driver_closing_balance AS cum_outstanding_factmodel,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
            WHEN b.drn IS NULL THEN 'DRN Missing in Loan FCT Recon'
            WHEN c.drn IS NULL THEN 'DRN Missing in Vitali Legacy Recon'
            WHEN d.drn IS NULL THEN 'DRN Missing in Fact Model Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Loan FCT Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Vitali Legacy Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Fact Model Recon'
            ELSE 'DRN and UberID Present in all'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
            WHEN a.uber_id IS DISTINCT FROM c.uber_id THEN 'Yes'
            WHEN a.uber_id IS DISTINCT FROM d.uber_id THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have Cumulative Outstanding difference
        CASE 
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.cumm_outstanding) THEN 'Yes'
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(c.driver_closing_balance) THEN 'Yes'
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(d.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_cum_outstanding_difference,
        ----Flag rows that have any column difference
        CASE 
            WHEN a.country IS DISTINCT FROM d.country
              OR a.effective_days IS DISTINCT FROM d.effective_days
              OR a.uber_balance IS DISTINCT FROM d.uber_payments_partner_balance
              OR a.bank_statement IS DISTINCT FROM d.payments_payins
              OR a.remittance IS DISTINCT FROM d.driver_remit_for_the_period
              OR a.prev_outstanding IS DISTINCT FROM d.driver_opening_balance
              OR a.trips IS DISTINCT FROM d.trips
              OR a.adjustment_amount IS DISTINCT FROM d.adjustments
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon_south_africa.reconciliation where week >= '2025-08-04' ) a
    FULL OUTER JOIN (select * from tmp_loan_book.stg_fct_recon where lower(country) = 'south africa' and week >= '2025-08-04') b
        ON a.drn = b.drn AND a.week = b.week
    FULL OUTER JOIN (select * from dbt_vitalii.int_recon_daily__legacy where lower(country) = 'south africa' and recon_week >= '2025-08-04') c
        ON a.drn = c.drn AND a.week = c.recon_week
    FULL OUTER JOIN (select * from dbt.fact_recon_daily where lower(country) = 'south africa' and recon_week >= '2025-08-04') d
        ON a.drn = d.drn AND a.week = d.recon_week
)
SELECT *
FROM combined
WHERE has_difference_other_columns = 'Yes';


    (record_status != 'DRN and UberID Present in all'
    OR has_uberid_difference = 'Yes'
    OR has_cum_outstanding_difference = 'Yes'
    OR has_difference_other_columns = 'Yes');


select * from recon_south_africa.reconciliation where week >= '2025-08-04' limit 10;

-----RECON COMPARISON: LEGACY, MART & FACT RECON---Updated Nov 10, 2025
WITH combined AS (
    SELECT 
        COALESCE(a.drn, b.drn, d.drn) AS drn,
        COALESCE(a.week, b.recon_week, d.recon_week) AS week,
        a.country AS country_originalrecon,
        b.country AS country_martweeklyrecon,
        d.country AS country_factmodel,
        a.uber_id AS uber_id_originalrecon,
        b.uber_id AS uber_id_martweeklyrecon,
        d.uber_id AS uber_id_factmodel,
        a.effective_days AS effective_days_originalrecon,
        b.effective_days AS effective_days_martweeklyrecon,
        d.effective_days AS effective_days_factmodel,
        a.trips AS trips_originalrecon,
        b.trips AS trips_martweeklyrecon,
        d.trips AS trips_factmodel,
        a.supply_hours AS supply_hours_originalrecon,
        b.supply_hours AS supply_hours_martweeklyrecon,
        d.supply_hours AS supply_hours_factmodel,
        a.uber_balance AS uber_balance_originalrecon,
        b.uber_balance AS uber_balance_martweeklyrecon,
        d.uber_payments_partner_balance AS uber_balance_factmodel,
        a.bank_statement AS payins_originalrecon,
        b.payins AS payins_martweeklyrecon,
        d.payments_payins AS payins_factmodel,
        a.adjustment_amount AS adjustment_amount_originalrecon,
        b.adjustments AS adjustment_amount_martweeklyrecon,
        d.adjustments AS adjustments_factmodel,
        a.outstanding AS week_outstanding_originalrecon,
        b.driver_balance_for_the_period AS week_outstanding_martweeklyrecon,
        d.driver_balance_for_the_period AS week_outstanding_factmodel,
        a.remittance AS remittance_originalrecon,
        b.driver_remit_for_the_period AS remittance_martweeklyrecon,
        d.driver_remit_for_the_period AS remittance_factmodel,
        a.prev_outstanding AS prev_outstanding_originalrecon,
        b.driver_opening_balance AS prev_outstanding_martweeklyrecon,
        d.driver_opening_balance AS prev_outstanding_factmodel,
        a.cum_outstanding AS cum_outstanding_originalrecon,
        b.driver_closing_balance AS cum_outstanding_martweeklyrecon,
        d.driver_closing_balance AS cum_outstanding_factmodel,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
            WHEN b.drn IS NULL THEN 'DRN Missing in Mart Weekly Recon'
            WHEN d.drn IS NULL THEN 'DRN Missing in Fact Model Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Mart Weekly Recon'
            WHEN d.uber_id IS NULL THEN 'UberID Missing in Fact Model Recon'
            ELSE 'DRN and UberID Present in all'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
            WHEN a.uber_id IS DISTINCT FROM d.uber_id THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have Opening Balance difference
        CASE 
            WHEN ROUND(a.prev_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
            WHEN ROUND(a.prev_outstanding) IS DISTINCT FROM ROUND(d.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_driver_opening_balance_difference,
        ----Flag rows that have Closing Balance difference
        CASE 
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(d.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_driver_closing_balance_difference,
        ----Flag rows that have any column difference
        CASE 
            WHEN a.country IS DISTINCT FROM b.country
              OR a.effective_days IS DISTINCT FROM b.effective_days
              OR a.uber_balance IS DISTINCT FROM b.uber_balance
              OR a.bank_statement IS DISTINCT FROM b.payins
              OR a.remittance IS DISTINCT FROM b.driver_remit_for_the_period
              OR a.prev_outstanding IS DISTINCT FROM b.driver_opening_balance
              OR a.trips IS DISTINCT FROM b.trips
              OR a.adjustment_amount IS DISTINCT FROM b.adjustments
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon_south_africa.reconciliation where week = '2025-10-27' ) a
    FULL OUTER JOIN (select country, city, recon_week, uber_id, drn, contract_type, vehicle_make, vehicle_model, sum(effective_days)effective_days, sum(effective_days_ineffective_days)effective_days_ineffective_days,
sum(cumulative_effective_days)cumulative_effective_days, sum(trips)trips, sum(supply_hours)supply_hours, sum(net_earnings)net_earnings, 
sum(uber_payments_cash_collected_by_driver)uber_payments_cash_collected_by_driver, sum(uber_balance)uber_balance, 
sum(uber_payments_surge_and_promotion)uber_payments_surge_and_promotion, sum(taxes)taxes, sum(driver_remit_for_the_period)driver_remit_for_the_period, 
sum(additional_charges_additional_charges)additional_charges_additional_charges, sum(additional_charges_extra_charges)additional_charges_extra_charges,
sum(additional_charges_passthrough_costs)additional_charges_passthrough_costs, sum(incentives)incentives, sum(adjustments)adjustments, sum(adjustment_type)adjustment_type, 
sum(payins)payins, sum(payouts)payouts, sum(driver_opening_balance)driver_opening_balance, sum(driver_balance_for_the_period)driver_balance_for_the_period, 
sum(driver_closing_balance)driver_closing_balance, sum(deposit_opening_balance)deposit_opening_balance, sum(deposits_inflow)deposits_inflow, 
sum(deposits_refunds)deposits_refunds, sum(deposit_closing_balance)deposit_closing_balance, sum(default_times)default_times
from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-10-27'
group by country, city, recon_week, uber_id, drn, contract_type, vehicle_make, vehicle_model
    ) b
        ON a.drn = b.drn AND a.week = b.recon_week
--    FULL OUTER JOIN (select * from dbt_vitalii.int_recon_daily__legacy where lower(country) = 'south africa' and recon_week >= '2025-08-04') c
--        ON a.drn = c.drn AND a.week = c.recon_week
    FULL OUTER JOIN (select * from dbt.fact_recon_daily where lower(country) = 'south africa' and recon_week = '2025-10-27') d
        ON a.drn = d.drn AND a.week = d.recon_week
)
SELECT *
FROM combined
WHERE 
    (record_status != 'DRN and UberID Present in all'
    OR has_uberid_difference = 'Yes'
    OR has_driver_opening_balance_difference = 'Yes'
    OR has_driver_closing_balance_difference = 'Yes'
    OR has_difference_other_columns = 'Yes');


select * from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-10-27' 
and drn = 'MVS20731';


select * from recon_south_africa.reconciliation where week = '2025-10-27' 
and drn = 'MVS12174';

select * from recon.raw_daily_recon_output where recon_week = '2025-10-27'
and drn = 'MVS21420';

select * from dbt.fact_recon_daily where lower(country) = 'south africa' and recon_week = '2025-10-27' limit 10;


select country, city, recon_week, uber_id, drn, contract_type, vehicle_make, vehicle_model, sum(effective_days)effective_days, sum(effective_days_ineffective_days)effective_days_ineffective_days,
sum(cumulative_effective_days)cumulative_effective_days, sum(trips)trips, sum(supply_hours)supply_hours, sum(net_earnings)net_earnings, 
sum(uber_payments_cash_collected_by_driver)uber_payments_cash_collected_by_driver, sum(uber_balance)uber_balance, 
sum(uber_payments_surge_and_promotion)uber_payments_surge_and_promotion, sum(taxes)taxes, sum(driver_remit_for_the_period)driver_remit_for_the_period, 
sum(additional_charges_additional_charges)additional_charges_additional_charges, sum(additional_charges_extra_charges)additional_charges_extra_charges,
sum(additional_charges_passthrough_costs)additional_charges_passthrough_costs, sum(incentives)incentives, sum(adjustments)adjustments, sum(adjustment_type)adjustment_type, 
sum(payins)payins, sum(payouts)payouts, sum(driver_opening_balance)driver_opening_balance, sum(driver_balance_for_the_period)driver_balance_for_the_period, 
sum(driver_closing_balance)driver_closing_balance, sum(deposit_opening_balance)deposit_opening_balance, sum(deposits_inflow)deposits_inflow, 
sum(deposits_refunds)deposits_refunds, sum(deposit_closing_balance)deposit_closing_balance, sum(default_times)default_times
from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-10-27'


   
---Corrected & Updated Code - Table 2
SELECT 
    t.drn,
    t.recon_week,
    ROUND(t.driver_opening_balance, 0) AS driver_opening_balance,
    ROUND(t.previous_closing_balance, 0) AS previous_closing_balance,
    ROUND(t.driver_opening_balance, 0) - ROUND(t.previous_closing_balance, 0) AS gap
FROM (
    SELECT 
        drn,
        recon_week, 
        driver_opening_balance,
        LAG(driver_closing_balance) OVER (PARTITION BY drn ORDER BY recon_week ASC) AS previous_closing_balance
    FROM recon.raw_daily_recon_output where recon_week = '2025-10-27' and drn = 'MVS21476'  and ingestion_date = '2025-11-06 10:51:06.000'
) t
--WHERE ---ABS(ROUND(t.driver_opening_balance, 0) - ROUND(t.previous_closing_balance, 0)) >1
-- drn = 'MVS21476'
ORDER BY t.drn ASC, t.recon_week ASC;

select * from recon.raw_daily_recon_output rdro where 
recon_week = '2025-10-27' and drn = 'MVS21476' and ingestion_date = '2025-11-06 10:51:06.000';






















--Vehicle Assignment & Status From CORE 
WITH assignments_total AS (
  select drn, registration_no, 
  	vehicle_assignment_start_date as effective_start_date, 
  	vehicle_assignment_end_date as effective_end_date, 
  	row_number() over (partition by drn order by effective_start_date desc) as rn
  from dbt.core__vehicle_driver_assignment
  ) ,
  assignments as (
  	select *
  	from assignments_total 
  	where rn = 1
  ),
  carco as (
  	select carco_name, registration_no_cleaned, country 
	from dbt.core__vehicle_domain
	where country = 'South Africa'
  ),
  recon as (
select week, drn, payouts
from recon_south_africa.reconciliation
)
select date_trunc('week', week) week, 
		c.carco_name,
		--r.drn,
		round(sum(payouts), 2) total_payouts          
from recon r
left join assignments a on a.drn = r.drn
left join carco c on c.registration_no_cleaned = a.registration_no
where week between '2024-01-01' and '2024-12-31'
group by 1, 2--, 3
order by 1, 2;--, 3


-------------------------------------------------------------------------
---====================================



-----------------------------------------------------------------
--November 6 2025----
--Annne's code---
WITH first_day_week_drn AS (
  SELECT
    drn
    , cast(recon_week AS date) AS week_date
    , min(cast(day AS date)) AS first_day
  FROM recon.raw_daily_recon_output GROUP BY drn, week_date
)
, driver_opening_balances AS (
  SELECT
    cast(recon_week AS date) AS week_date
    , recon.raw_daily_recon_output.drn
    , driver_opening_balance
    , deposit_opening_balance 
  FROM recon.raw_daily_recon_output JOIN first_day_week_drn
    ON first_day_week_drn.first_day = cast(recon.raw_daily_recon_output.day AS date)
      AND first_day_week_drn.drn = recon.raw_daily_recon_output.drn
)
, last_day_week_drn AS (
  SELECT
    drn
    , cast(recon_week AS date) AS week_date
    , max(cast(day AS date)) AS last_day
  FROM recon.raw_daily_recon_output GROUP BY drn, week_date
)
, driver_closing_balances AS (
  SELECT
    cast(recon_week AS date) AS week_date
    , recon.raw_daily_recon_output.drn
    , driver_closing_balance
    , cumulative_effective_days
    , deposit_closing_balance 
  FROM recon.raw_daily_recon_output JOIN last_day_week_drn
    ON last_day_week_drn.last_day = cast(recon.raw_daily_recon_output.day AS date)
      AND last_day_week_drn.drn = recon.raw_daily_recon_output.drn
)
, weekly_aggregated_data AS (
  select
    first_name AS driver_name 
    , max(city) AS city
    , country_code
    , cast(recon_week AS date) AS week_date
    , drn
    , carco_name
    , max(registration_no) AS registration_no
    , listagg(DISTINCT uber_id, ', ') WITHIN GROUP (ORDER BY uber_id) AS uber_id
    , sum(effective_days) AS effective_days
    , sum(CASE
      WHEN
        json_extract_path_text(effective_days_breakdown, 'vehicle_days_off')::float = 1.0
        OR json_extract_path_text(effective_days_breakdown, 'driver_days_off')::float = 1.0
        OR json_extract_path_text(effective_days_breakdown, 'ineffective_days')::float = 1.0
        OR json_extract_path_text(effective_days_breakdown, 'date_equal_to_pickup_date')::float = 1.0
        OR json_extract_path_text(effective_days_breakdown, 'date_greater_than_equal_to_drop_off_date')::float = 1.0
        OR json_extract_path_text(effective_days_breakdown, 'assignment_start_date_is_null')::float = 1.0
        THEN 1
      ELSE 0
    END) AS ineffective_days
    , sum(trips) AS trips
    , sum(supply_hours) AS supply_hours
    , sum(net_earnings_post_partner_adjustments) - (sum(json_extract_path_text(uber_payments_breakdown, 'partner_fees')::float) + sum(json_extract_path_text(uber_payments_breakdown, 'tax_partner_sales_tax')::float) + sum(json_extract_path_text(uber_payments_breakdown, 'tax_moove_output_vat')::float)) AS gross_bookings
    , sum(json_extract_path_text(uber_payments_breakdown, 'partner_fees')::float) AS uber_fees
    , sum(json_extract_path_text(uber_payments_breakdown, 'partner_adjustments')::float) AS uber_adjustments
    , sum(json_extract_path_text(uber_payments_breakdown, 'partner_balance')::float) AS partner_balance
    , sum(net_earnings_post_partner_adjustments) AS uber_net_of_fees
    , (
      nvl(sum(json_extract_path_text(uber_payments_breakdown, 'gross_fare')::float), 0.0) +
      nvl(sum(json_extract_path_text(uber_payments_breakdown, 'partner_fees')::float), 0.0)
    ) AS net_fare
    , nvl(sum(taxes::float), 0) AS witholding_tax
    , round(sum(driver_remit_for_the_period)) AS weekly_remit
    , nvl(sum(json_extract_path_text(driver_discounts_breakdown, 'dynamic_pricing_discount')::float), 0.0) + nvl(sum(json_extract_path_text(driver_discounts_breakdown, 'uber_dynamic_pricing_program_discount')::float), 0) AS total_dynamic_pricing
    , nvl(sum(json_extract_path_text(driver_discounts_breakdown, 'dynamic_pricing_discount')::float), 0.0) AS dynamic_pricing_discount
    , nvl(sum(json_extract_path_text(driver_discounts_breakdown, 'uber_dynamic_pricing_program_discount')::float), 0.0) AS uber_dynamic_pricing_program_discount
    , sum(net_earnings_post_partner_adjustments + driver_remit_for_the_period + driver_discounts) + witholding_tax AS driver_payable_before_additional_fees
    , sum(json_extract_path_text(additional_charges_breakdown, 'extra_charges')::float) AS extra_charges
    , sum(json_extract_path_text(additional_charges_breakdown, 'passthrough_costs')::float) AS passthrough_costs
    , sum(adjustments) AS adjustments
    , sum(additional_charges + adjustments) + driver_payable_before_additional_fees AS adjusted_driver_payable
    , sum(json_extract_path_text(payments_breakdown, 'partner_cash_collected_by_driver')::float) AS cash_collected_in_the_week
    , sum(json_extract_path_text(payments_breakdown, 'payouts')::float) AS payouts
    , sum(json_extract_path_text(payments_breakdown, 'payins')::float) AS payins
    , sum(json_extract_path_text(payments_breakdown, 'sheet_payins')::float) as sheet_payins
    , nvl(sum(json_extract_path_text(payments_breakdown, 'rental_payments')::float), 0.0) AS rental_payins
    , sum(driver_balance_for_the_period) as driver_balance_for_the_period
    , sum(json_extract_path_text(deposit_payments_breakdown, 'deposits')::float) as deposit_payments
    , sum(json_extract_path_text(deposit_payments_breakdown, 'deposit_refunds')::float) as deposit_refunds
    , sum(json_extract_path_text(deposit_closing_balance_breakdown, 'amount_credit_from_recon')::float) as deposit_amount_credited_from_recon
    , max(status) AS status
  FROM recon.raw_daily_recon_output
  WHERE frequency = 'weekly' and country = 'South Africa' and recon_week = '2025-10-27'
  GROUP BY country_code, drn, recon_week, first_name, carco_name
)
select
  status
  , country_code as country
  , city
  , weekly_aggregated_data.week_date as week
  , weekly_aggregated_data.drn
  , uber_id
  , driver_name
  , registration_no
  , carco_name as carco
  , effective_days
  , ineffective_days
  ,cumulative_effective_days
  , trips
  , supply_hours
  , cash_collected_in_the_week
  , (uber_net_of_fees + cash_collected_in_the_week) as uber_balance
  , weekly_remit as remit
  , total_dynamic_pricing as incentives
  , extra_charges
  , passthrough_costs
  , adjustments
  , payouts
  , payins + sheet_payins as payins
  , cast(driver_opening_balance AS integer)
  , driver_balance_for_the_period
  , cast(driver_closing_balance AS integer)
  , deposit_opening_balance
  , deposit_amount_credited_from_recon + deposit_payments as deposit_in_flows
  , deposit_refunds
  , deposit_closing_balance
FROM weekly_aggregated_data
JOIN driver_opening_balances ON weekly_aggregated_data.week_date = driver_opening_balances.week_date AND weekly_aggregated_data.drn = driver_opening_balances.drn
JOIN driver_closing_balances ON weekly_aggregated_data.week_date = driver_closing_balances.week_date AND weekly_aggregated_data.drn = driver_closing_balances.drn




------------------------------------------
---November 10, 2025---

select * from payments_aggregator.aggregated_transactions
where payment_unique_reference in (
'100004251105082938144612269813',
'100004251105093210144618155728',
'100004251105085444144614336709',
'100004251105092806144616519145',
'100033251105090013141270943831',
'100004251105091527144614874795',
'100004251105083726144613527772',
'100004251105090023144615452299',
'100004251105093042144617532127',
'100004251105085252144613979975',
'100004251105092300144615964775',
'090405251105095146143420967217',
'100004251105084502144613425249',
'000017251105102848746511742003',
'100004251105085709144614972288',
'100004251105083458144612508848',
'100004251105092544144615987980',
'000004251105101912492041195568',
'000013251105103432000526651573',
'100004251105084436144613842603',
'000017251105093116579941709138',
'100004251105083128144612479719',
'100004251105092612144616502918',
'100004251105083906144612648072'
);

--Checking if they reflected on Recon.
select * from (
select drn, bank_statement from recon_nigeria.reconciliation_spresso
where day = '2025-11-04'
union all
select drn, bank_statement from recon_nigeria.reconciliation_alto
where day = '2025-11-04')
where drn in (
'DRN004469',
'DRN015305',
'DRN012621',
'DRN018718',
'DRN016123',
'DRN017799',
'DRN013818',
'DRN017700',
'DRN016781',
'DRN017426',
'DRN009604',
'DRN017320',
'DRN017350',
'DRN017616',
'DRN018225',
'DRN018203',
'DRN014772',
'DRN015974',
'DRN017914',
'DRN017248',
'DRN018386'
);




-------------------------------------------------------
----Nov 11 2025----

select * from core_dimensions.mart_driver_weekly_recon
where recon_week = '2025-10-27'
and drn = 'MVS21420';


select * from dbt_vitalii.tr_fact_recon_daily__driver_balance_math;


---Missing Nigeria payments re-instated at a later date. Use the created column, that's what Recon references.
select * from payments_aggregator.aggregated_transactions
where payment_unique_reference in (
'100004251105082938144612269813',
'100004251105085444144614336709',
'100004251105093042144617532127');



--------------------------------------------------
------Nov 12, 2025------

-----RECON COMPARISON: LEGACY & MART WEEKLY RECON---
WITH 
combined AS (
    SELECT 
        COALESCE(a.drn, b.drn) AS drn,
        COALESCE(a.week, b.recon_week) AS week,
        a.country AS country_originalrecon,
        b.country AS country_martweeklyrecon,
        a.uber_id AS uber_id_originalrecon,
        b.uber_id AS uber_id_martweeklyrecon,
        NVL(a.effective_days,0.0) AS effective_days_originalrecon,
        b.effective_days AS effective_days_martweeklyrecon,
        null as effective_days_gap,
        a.days_off AS ineffective_days_originalrecon,
        b.ineffective_days AS ineffective_days_martweeklyrecon,
        null as ineffective_days_gap,
        a.trips AS trips_originalrecon,
        b.trips AS trips_martweeklyrecon,
        null as trips_gap,
        a.supply_hours AS supply_hours_originalrecon,
        b.supply_hours AS supply_hours_martweeklyrecon,
        null as supply_hours_gap,
        a.uber_balance AS uber_balance_originalrecon,
        b.uber_balance AS uber_balance_martweeklyrecon,
        null as uber_balance_gap,
        a.bank_statement AS payins_originalrecon,
        b.payins AS payins_martweeklyrecon,
        null as payins_gap,
        a.adjustment_amount AS adjustment_amount_originalrecon,
        b.adjustments AS adjustment_amount_martweeklyrecon,
        null as adjustment_gap,
        a.extra_charges AS extracharges_originalrecon,
        b.extra_charges + b.passthrough_costs AS extracharges_martweeklyrecon,    
        null as extracharges_gap,
        a.remittance AS remittance_originalrecon,
        b.driver_remit_for_the_period AS remittance_martweeklyrecon,
        null as remittance_gap,
        a.outstanding AS balance_forthe_period_originalrecon,
        b.driver_balance_for_the_period AS balance_forthe_period_martweeklyrecon,
        null as balance_forthe_period_gap,
        null AS security_deposit_credited_from_recon_originalrecon,
        b.security_deposit_contribution AS security_deposit_credited_from_recon_martweeklyrecon,
        null as security_deposit_credited_from_recon_gap,
        a.payouts AS payouts_originalrecon,
        b.payouts AS payouts_martweeklyrecon,
        null as payouts_gap,
        a.prev_outstanding AS opening_balance_originalrecon,
        b.driver_opening_balance AS opening_balance_martweeklyrecon,
        null as opening_balance_gap,
        a.cum_outstanding as closing_balance_originalrecon,
        b.driver_closing_balance AS closing_balance_martweeklyrecon,
        null as closing_balance_gap,
        CASE 
            WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
            WHEN b.drn IS NULL THEN 'DRN Missing in Mart Weekly Recon'
            WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
            WHEN b.uber_id IS NULL THEN 'UberID Missing in Mart Weekly Recon'
            ELSE 'DRN and UberID Present in all'
        END AS record_status,
        ----Flag rows that have UberID difference
        CASE 
            WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
            ELSE 'No'
        END AS has_uberid_difference,
        ----Flag rows that have Opening Balance difference
        CASE 
            WHEN ROUND(a.prev_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_driver_opening_balance_difference,
        ----Flag rows that have Closing Balance difference
        CASE 
            WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
            ELSE 'No'
        END AS has_driver_closing_balance_difference,
        ----Flag rows that have any column difference
        CASE 
            WHEN a.country IS DISTINCT FROM b.country
              OR a.effective_days IS DISTINCT FROM b.effective_days
              OR a.uber_balance IS DISTINCT FROM b.uber_balance
              OR a.bank_statement IS DISTINCT FROM b.payins
              or a.days_off is distinct from b.ineffective_days
              or a.extra_charges is distinct from (b.extra_charges + b.passthrough_costs)
              OR a.remittance IS DISTINCT FROM b.driver_remit_for_the_period
              OR a.prev_outstanding IS DISTINCT FROM b.driver_opening_balance
              OR a.trips IS DISTINCT FROM b.trips
              OR a.adjustment_amount IS DISTINCT FROM b.adjustments
            THEN 'Yes'
            ELSE 'No'
        END AS has_difference_other_columns
    FROM (select * from recon_south_africa.reconciliation where week = '2025-11-03' ) a
    FULL OUTER JOIN (select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-11-03'
    ) b
        ON a.drn = b.drn AND a.week = b.recon_week
)
SELECT *
FROM combined
WHERE 
    (record_status != 'DRN and UberID Present in all'
    OR has_uberid_difference = 'Yes'
    OR has_driver_opening_balance_difference = 'Yes'
    OR has_driver_closing_balance_difference = 'Yes'
    OR has_difference_other_columns = 'Yes')
    and country_martweeklyrecon is not null
order by drn;




select * from core_dimensions.mart_driver_weekly_recon
where recon_week = '2025-10-27';

select * from core_dimensions.mart_driver_weekly_recon
where recon_week = '2025-11-03';


select distinct recon_week from core_dimensions.mart_driver_weekly_recon;


select * from core_dimensions.mart_driver_weekly_recon_draft
where recon_week = '2025-11-03';





--------------------------------------------------------
---Nov 13, 2025--
--=====UPDATED QUERY======---

-----RECON COMPARISON: LEGACY & MART WEEKLY RECON---
WITH
combined AS (
   SELECT
       COALESCE(a.drn, b.drn) AS drn,
       COALESCE(a.week, b.recon_week) AS week,
       a.country AS country_originalrecon,
       b.country AS country_martweeklyrecon,
       a.uber_id AS uber_id_originalrecon,
       b.uber_id AS uber_id_martweeklyrecon,
       NVL(a.effective_days,0.0) AS effective_days_originalrecon,
       NVL(b.effective_days ,0.0)AS effective_days_martweeklyrecon,
       NVL(a.effective_days,0.0)  -  NVL(b.effective_days,0.0) as effective_days_gap,
       NVL(a.days_off,0.0) AS ineffective_days_originalrecon,
       NVL(b.ineffective_days, 0.0) AS ineffective_days_martweeklyrecon,
       NVL(a.days_off,0.0) - NVL(b.ineffective_days, 0.0) as ineffective_days_gap,
       NVL(a.trips, 0.0) AS trips_originalrecon,
       NVL(b.trips, 0.0) AS trips_martweeklyrecon,
       NVL(a.trips, 0.0) - NVL(b.trips, 0.0) as trips_gap,
       NVL(a.supply_hours, 0.0) AS supply_hours_originalrecon,
       NVL(b.supply_hours, 0.0) AS supply_hours_martweeklyrecon,
       NVL(a.supply_hours, 0.0) - NVL(b.supply_hours, 0.0) as supply_hours_gap,
       NVL(a.uber_balance, 0.0) AS uber_balance_originalrecon,
       NVL(b.uber_balance, 0.0) AS uber_balance_martweeklyrecon,
       NVL(a.uber_balance, 0.0) - NVL(b.uber_balance, 0.0) as uber_balance_gap,
       NVL(a.bank_statement, 0.0) AS payins_originalrecon,
       NVL(b.payins, 0.0) AS payins_martweeklyrecon,
       NVL(a.bank_statement, 0.0) - NVL(b.payins, 0.0) as payins_gap,
       NVL(a.adjustment_amount, 0.0) AS adjustment_amount_originalrecon,
       NVL(b.adjustments, 0.0) AS adjustment_amount_martweeklyrecon,
       NVL(a.adjustment_amount, 0.0) + NVL(b.adjustments, 0.0) as adjustment_gap,
       NVL(a.extra_charges, 0.0) AS extracharges_originalrecon,
       (NVL(b.extra_charges,0.0) + NVL(b.passthrough_costs, 0.0)) AS extracharges_martweeklyrecon,   
       NVL(a.extra_charges, 0.0) + (NVL(b.extra_charges,0.0) + NVL(b.passthrough_costs, 0.0)) as extracharges_gap,
      NVL(a.remittance, 0.0) AS remittance_originalrecon,
      NVL( b.driver_remit_for_the_period, 0.0) AS remittance_martweeklyrecon,
       NVL(a.remittance, 0.0) + NVL( b.driver_remit_for_the_period, 0.0) as remittance_gap,
       NVL(a.outstanding, 0.0) AS balance_forthe_period_originalrecon,
       NVL(b.driver_balance_for_the_period, 0.0) AS balance_forthe_period_martweeklyrecon,
       NVL(a.outstanding, 0.0) + NVL(b.driver_balance_for_the_period, 0.0) as balance_forthe_period_gap,
       0 AS security_deposit_credited_from_recon_originalrecon,
       NVL(b.security_deposit_contribution, 0.0) AS security_deposit_credited_from_recon_martweeklyrecon,
       0 - NVL(b.security_deposit_contribution, 0.0) as security_deposit_credited_from_recon_gap,
       NVL(a.payouts, 0.0) AS payouts_originalrecon,
       NVL(b.payouts, 0.0) AS payouts_martweeklyrecon,
       NVL(a.payouts, 0.0) + NVL(b.payouts, 0.0) as payouts_gap,
       NVL(a.prev_outstanding, 0.0) AS opening_balance_originalrecon,
       NVL(b.driver_opening_balance, 0.0) AS opening_balance_martweeklyrecon,
       NVL(a.prev_outstanding, 0.0)  + NVL(b.driver_opening_balance, 0.0) as opening_balance_gap,
       NVL(a.cum_outstanding, 0.0) as closing_balance_originalrecon,
       NVL(b.driver_closing_balance, 0.0) AS closing_balance_martweeklyrecon,
       NVL(a.cum_outstanding, 0.0) + NVL(b.driver_closing_balance, 0.0)  as closing_balance_gap,
       CASE
           WHEN a.drn IS NULL THEN 'DRN Missing in Original Recon'
           WHEN b.drn IS NULL THEN 'DRN Missing in Mart Weekly Recon'
           WHEN a.uber_id IS NULL THEN 'UberID Missing in Original Recon'
           WHEN b.uber_id IS NULL THEN 'UberID Missing in Mart Weekly Recon'
           ELSE 'DRN and UberID Present in all'
       END AS record_status,
       ----Flag rows that have UberID difference
       CASE
           WHEN a.uber_id IS DISTINCT FROM b.uber_id THEN 'Yes'
           ELSE 'No'
       END AS has_uberid_difference,
       ----Flag rows that have Opening Balance difference
       CASE
           WHEN ROUND(a.prev_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
           ELSE 'No'
       END AS has_driver_opening_balance_difference,
       ----Flag rows that have Closing Balance difference
       CASE
           WHEN ROUND(a.cum_outstanding) IS DISTINCT FROM ROUND(b.driver_closing_balance) THEN 'Yes'
           ELSE 'No'
       END AS has_driver_closing_balance_difference,
       ----Flag rows that have any column difference
       CASE
           WHEN a.country IS DISTINCT FROM b.country
             OR a.effective_days IS DISTINCT FROM b.effective_days
             OR a.uber_balance IS DISTINCT FROM b.uber_balance
             OR a.bank_statement IS DISTINCT FROM b.payins
             or a.days_off is distinct from b.ineffective_days
             or a.extra_charges is distinct from (b.extra_charges + b.passthrough_costs)
             OR a.remittance IS DISTINCT FROM b.driver_remit_for_the_period
             OR a.prev_outstanding IS DISTINCT FROM b.driver_opening_balance
             OR a.trips IS DISTINCT FROM b.trips
             OR a.adjustment_amount IS DISTINCT FROM b.adjustments
           THEN 'Yes'
           ELSE 'No'
       END AS has_difference_other_columns
   FROM (select * from recon_south_africa.reconciliation where week = '2025-11-03' ) a
   FULL OUTER JOIN (select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-11-03'
   ) b
       ON a.drn = b.drn AND a.week = b.recon_week
)
SELECT *
FROM combined
WHERE
   (record_status != 'DRN and UberID Present in all'
   OR has_uberid_difference = 'Yes'
   OR has_driver_opening_balance_difference = 'Yes'
   OR has_driver_closing_balance_difference = 'Yes'
   OR has_difference_other_columns = 'Yes')
   and country_martweeklyrecon is not null
order by drn;





select * from recon.raw_daily_recon_output 
where recon_week = '2025-11-03' and drn = 'MVS20675';

select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' --and recon_week = '2025-11-03'
and drn = 'MVS10433'
order by recon_week;

total_security_deposit_amount

select * from recon_south_africa.reconciliation where week >= '2025-10-27' and drn = 'MVS20675';

select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' --and recon_week = '2025-11-03'
and drn = 'MVS14733'
order by recon_week;






-------------------
---Nov 14, 2025----
---Tolls Investigation---

with with_tolls as (select drn, week from recon_south_africa.reconciliation where week >= '2025-10-06' and toll <>0)
select a.drn, a.week, toll, uber_balance, amount_due as remit, extra_charges, adjustment_amount, a.adjustment_description, a.bank_statement, moove_balance, outstanding, prev_outstanding, cum_outstanding, payouts
from recon_south_africa.reconciliation a  
left join with_tolls b
on a.drn = b.drn and a.week = b.week
where a.week >= '2025-10-06' order by drn, week;  ---and a.drn = 'MVS15025';


where week >= '2025-10-06' order by drn, week;


select drn, week, toll, uber_balance, amount_due as remit, extra_charges, adjustment_amount, moove_balance, outstanding, prev_outstanding, cum_outstanding, payouts
from recon_south_africa.reconciliation where week >= '2025-10-06'
and drn= 'MVS15025' order by drn, week;





-------------------
---Dec 08, 2025----
---SA Recon run---


select * from driver_w_contracts_data limit 10;


with dim_driver_w_dates as 
(
select 
a.drn, 
a.city,
a.country,
b.date 
from 
core_dimensions.dim_driver a 
join public.dim_calendar b 
on a.created_ts::date <= b.date
where a.created_ts  is not null 
and b.date >= '2025-12-01' and b.date<= '2025-12-07' )
, driver_w_assignments_data as 
(
select 
drn
,city
,country
,"date"
,registration_no
,start_datetime
,end_datetime
from 
(
select 
a.drn
,a.city
,a.country
,a."date"
,b.registration_no
,b.start_datetime
,b.end_datetime
,rank()over(partition by a.drn, a.date order by b.start_datetime desc ) as rnk 
from dim_driver_w_dates a
  LEFT JOIN core_dimensions.dim_vehicle_driver_assignment b
    ON a.drn = b.drn and 
    a.date BETWEEN b.start_datetime ::date
      AND COALESCE(b.end_datetime ::date, CURRENT_DATE)) 
      where rnk = 1
)
, selected_addons_per_contract as 
(
select
driver_contract_id
,sum(fta.addon_charge) AS total_addon
from core_dimensions.fact_contract_addons dcta
join core_dimensions.fact_template_addons fta on dcta.contract_template_addon_id = fta.template_addon_id
where fta.soft_deleted = FALSE
group by driver_contract_id
)
, contract_remit as 
(
select
d.drn
, ct.remittance AS base_remittance
, COALESCE(sapc.total_addon, 0) as selected_addon
, ct.remittance + selected_addon as net_remittance
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
join core_dimensions.dim_contract_template ct ON dc.template_id = ct.template_id
left join selected_addons_per_contract sapc on dc.contract_id = sapc.driver_contract_id
--where dc.status = 'ACTIVE'
--and d.soft_deleted = false
)
, driver_w_contracts_data as 
(
select 
a.*, 
b.net_remittance 
from 
driver_w_assignments_data a 
join 
contract_remit b ON a.drn = b.drn
)
--select * from driver_w_contracts_data where drn in ('MVS21637', 'MVS21792', 'MVS21517', 'MVS22295');
select distinct drn, net_remittance AS original_remit, DATE_TRUNC('week', "date") as week, city 
from driver_w_contracts_data;
--select distinct drn, registration_no AS license_plate_moove, start_datetime AS vehicle_assignment_start_date, end_datetime AS vehicle_assignment_end_date
---from driver_w_contracts_data where DATE_TRUNC('week', "date") = '2025-12-01';



select * from core_dimensions.dim_driver where drn = 'MVS15351';

select * from core_dimensions.dim_vehicle_driver_assignment where drn = 'MVS21637';

select * from core_dimensions.dim_contract_template limit 10;

select 
 country
, city
, DATE_TRUNC('week', "date") as week
, date
, registration_no AS license_plate_moove
, NULL AS core_vehicle_id
, NULL AS license_plate_uber
, NULL AS uber_vehicle_id_from_core
, NULL AS final_license_plate
, NULL AS uber_id
, NULL AS core_driver_id 
, drn
, NULL AS first_name
, NULL AS last_name
, NULL AS carco_name
, NULL AS contract_type
, NULL AS moove_product_code
, NULL AS plan_code
, start_datetime AS vehicle_assignment_start_date
, end_datetime AS vehicle_assignment_end_date
, NULL AS first_assignment_date
, NULL AS churn_date
, net_remittance AS original_remit
, 6 AS remit_days
from driver_w_contracts_data;





select * from recon_south_africa.reconciliation where week >= '2025-09-22'
and drn in 

select distinct week from recon_south_africa.reconciliation where drn = 'MVS21792' order by week desc;


select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-11-03'

core_dimensions.fact_ineffective_days_request

core_dimensions.fact_driver_extra_charges
core_dimensions.fact_extra_charge_details

select * from core_dimensions.fact_ineffective_days_request limit 10;

select * from core_dimensions.fact_extra_charge_details limit 10;

select * from 
recon.recon_input__driver_ineffective_days
recon.recon_input__driver_extra_charges
recon.recon_input__driver_profile


select * from recon.recon_input__driver_ineffective_days limit 10;

select * from recon.recon_input__driver_extra_charges limit 10;

select * from recon.recon_input__driver_profile limit 10;

recon.recon_input__uber_payments_data
recon.recon_input__uber_trips_data
recon.recon_input__driver_profile_sa

select * from recon.recon_input__driver_profile_sa limit 10;
select * from recon.recon_input__driver_profile limit 10;



select * from recon.recon_input__driver_extra_charges 
where country = 'South Africa' and status = 'APPROVED' and charge_date between '2025-12-01' and '2025-12-07'
order by ;


select * from recon.recon_input__driver_ineffective_days 
where country = 'South Africa' and request_status = 'APPROVED' and start_date >= '2025-12-01' and end_date <= '2025-12-07'
order by drn;


select * from core_dimensions.dim_uber_core_mapping limit 10;


select * from recon.recon_input__uber_trips_data limit 10;




------------------------------------------------
----SA RECON 2.0 CHECKS
------------------------------------------------
-----Ineffective Days---
select * from recon.recon_input__driver_ineffective_days 
where country = 'South Africa' and request_status = 'APPROVED' and start_date <= '2025-12-07' and end_date >= '2025-12-01'
order by drn;


-----Uber Earnings---
select * from recon.recon_input__uber_payments_data limit 10;

select count(distinct drn)drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data 
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2025-12-01';

select distinct duuid,drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data 
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2025-12-01'
group by duuid,drn  order by drn;

select * from recon.recon_input__uber_payments_data 
where duuid = 'f0c945c2-1ded-446d-8276-4e98cdc7296e';


---Extra Charges + Passthrough Cost
select distinct drn, sum(amount) as extra_charges_pc from recon.recon_input__driver_extra_charges ---limit 10;
where country = 'South Africa' and status = 'APPROVED' and charge_date between '2025-12-01' and '2025-12-07'
group by drn order by drn;


---Last Recon from Legacy Recon
select * from recon_south_africa.reconciliation where week = '2025-11-24'
order by drn;


-----Payins
select distinct driver_number, sum(amount) as payins from payments_aggregator.aggregated_transactions --limit 10;
where created between '2025-12-01' and '2025-12-07' and country_code = 'ZA'
group by driver_number order by driver_number;

select distinct country_code from payments_aggregator.aggregated_transactions;

----Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
----LEGACY RECON---
select r.drn, r.week, r.day, r.prev_outstanding as driver_opening_balance , r.cum_outstanding as driver_closing_balance
FROM recon_south_africa.reconciliation r
WHERE r.week = '2025-11-24' ---get the Monday date of upper week.
order by drn
),
output_this_week as (
---RECON 2.0----
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, min(day) as min_day
    FROM recon.daily_recon_output
    WHERE week = '2025-12-01' ---get the Monday date of last week.
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-12-01' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, ROUND(b.driver_closing_balance,2) as previous_last_driver_closing_balance, ROUND(a.driver_opening_balance,2) as this_week_driver_opening_balance,
(ROUND(b.driver_closing_balance,2) - ROUND(a.driver_opening_balance,2)) as gap,
    case 
        when ABS(ABS(ROUND(b.driver_closing_balance,2)) - ABS(ROUND(a.driver_opening_balance,2))) <= 1 then 'ok'
        else 'fail'
    end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check ---where drn = 'MVS20604';
where balance_equality_check = 'fail'
order by drn;



---Recon 2.0 Extract For The Week---
select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-12-01'
order by drn;

recon.recon_input__uber_payments_data
recon.recon_input__uber_trips_data
recon.daily_recon_output


------------------------------------
---Dec 9 2025---
---Continuing SA new Recon checks
--------------------------------

select * from partners_data_weekly.mv_uber_harmonized_payments_order
where source_file_date = '2025-12-01' and country ilike '%south%'

select * from partners_data_weekly.vw_uber_driver_aggr limit 10;

select count(driveruuid)driveruuid, sum(net_earning)net_earnings from partners_data_weekly.vw_uber_driver_aggr
where country = 'South Africa' and  event_date = '2025-12-01';




------------------------------------
---Dec 10 2025---
---SA Loan Book Paid To Date Checks
------------------------------------

select * from core_dimensions.mart_driver_paid_to_date limit 10;

select * from "default".sa_prev_total_received_sophia --limit 10;
where drn = 'MVS22607';


----Ahmed's Paid To Date Records----
WITH historical_paid_to_date AS (
  SELECT
    UPPER(drn)::VARCHAR AS drn
    , DATE_TRUNC('WEEK', week_start::DATE) AS week
    , total_received_contract::FLOAT AS total_received
  FROM "default".sa_prev_total_received_sophia
  WHERE total_received_contract IS NOT NULL
)
, payment_tbl AS (
  SELECT
    country
    , city
    , drn
    , recon_week AS week
    , day
    , uber_payments_partner_balance AS uber_balance
    , payments_payins AS bank_statement
    , incentives AS incentives
    , payments_payouts AS payouts
    , additional_charges_extra_charges AS extra_charges
    , additional_charges_passthrough_costs AS toll
    , adjustments AS adjustment_amount
    , adjustment_type AS adjustment_type

  FROM core_dimensions.fact_recon_daily
  WHERE country = 'South Africa'
)
, driver_contracts_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver_contract
)
, dim_driver_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver
)
, calendar AS (
  SELECT DISTINCT DATE_TRUNC('WEEK', date) AS week
  FROM tmp_loan_book.stg_dim_daily_calendar
  WHERE date <= CURRENT_DATE
)
, driver_contracts AS (
  WITH last_contract AS (
    SELECT
      dc.driver_id
      , dc.start_date AS contract_start_date
      , dc.status AS contract_status
    FROM driver_contracts_tbl dc
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY dc.driver_id
      ORDER BY dc.start_date ASC
    ) = 1
  )
  SELECT
    dd.driver_sk
    , dd.drn
    , dd.driver_id
    , dd.country
    , lc.contract_start_date
    , lc.contract_status
  FROM last_contract lc
  INNER JOIN dim_driver_tbl dd
    ON lc.driver_id = dd.driver_id
)
, paid_to_date_calculation AS (
  WITH driver_week_payments_data AS (
    SELECT
      country
      , city
      , drn
      , week
      , SUM(uber_balance) AS uber_balance
      , SUM(bank_statement) AS bank_statement
      , SUM(incentives) AS incentives
      , SUM(payouts) AS payouts
      , SUM(extra_charges) AS extra_charges
      , SUM(toll) AS toll
      , SUM(adjustment_amount) AS adjustment_amount
      , MAX(adjustment_type) AS adjustment_type
    FROM payment_tbl
    GROUP BY country, city, drn, week
  )
  , selected_payments AS (
    SELECT
      dc.driver_sk
      , dc.contract_status
      , dp.*
    FROM driver_week_payments_data dp
    INNER JOIN driver_contracts dc
      ON dp.drn = dc.drn
        AND dp.country = dc.country
        AND dp.week >= dc.contract_start_date
  )
  , week_paid_to_date AS (
    SELECT
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
      , SUM(
        sp.uber_balance
        + (
          CASE
            WHEN sp.country = 'South Africa' AND sp.week <= '2025-09-29' THEN sp.toll
            ELSE 0
          END
        )
        + sp.bank_statement
        + sp.incentives
        + sp.payouts
        + sp.extra_charges
        + (
          CASE
            WHEN sp.adjustment_type ILIKE '%Agreement of Debt%'
              OR sp.adjustment_type ILIKE '%Driver remit adjustment%'
              THEN 0
            ELSE sp.adjustment_amount
          END
        )
      ) AS total_received
    FROM selected_payments sp
    GROUP BY
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
  )
  SELECT
    *
    , SUM(total_received) OVER (
      PARTITION BY drn, country
      ORDER BY week
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_total_received
  FROM week_paid_to_date
)
, paid_to_date_calendar AS (
  WITH paid_to_date_all_weeks AS (
    SELECT
      c.week
      , dc.country
      , dc.driver_sk
      , dc.driver_id
      , dc.drn
      , COALESCE(ptd.total_received, 0) AS week_total_received
      , ptd.cumulative_total_received
    FROM calendar c
    INNER JOIN driver_contracts dc
      ON TRUE
    INNER JOIN (
      SELECT
        driver_sk
        , MIN(week) AS min_week
      FROM paid_to_date_calculation
      GROUP BY driver_sk
    ) mw
      ON dc.driver_sk = mw.driver_sk
        AND c.week >= mw.min_week
    LEFT JOIN paid_to_date_calculation ptd
      ON c.week = ptd.week
        AND dc.driver_sk = ptd.driver_sk
  )
  SELECT
    week
    , country
    , driver_sk
    , driver_id
    , drn
    , week_total_received
    , LAST_VALUE(cumulative_total_received IGNORE NULLS)
      OVER (
        PARTITION BY driver_sk
        ORDER BY week
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
    AS cumulative_total_received
  FROM paid_to_date_all_weeks
)
, paid_to_date_adjustment AS (
  SELECT
    ptd.driver_sk
    , ptd.country
    -- ptd.city,
    , ptd.drn
    , ptd.week
    , ptd.week_total_received
    , hptd.total_received AS historical_total_received
    , ptd.cumulative_total_received AS current_total_received
    , hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
  FROM paid_to_date_calendar ptd
  INNER JOIN historical_paid_to_date hptd
    ON ptd.drn = hptd.drn
      AND ptd.week = hptd.week
)
SELECT *
FROM paid_to_date_calendar ptdc
WHERE ptdc.country = 'South Africa'
  AND ptdc.week >= '2025-10-20'
--QUALIFY ROW_NUMBER() OVER (
--  PARTITION BY ptdc.driver_sk
--  ORDER BY ptdc.week
--) = 1
ORDER BY ptdc.driver_sk, ptdc.week;



--If you need it for all weeks starting 2025-10-20, you can remove this
QUALIFY ROW_NUMBER() OVER (
  PARTITION BY ptdc.driver_sk
  ORDER BY ptdc.week
) = 1



---Dec 01, 2025----
select * from recon_nigeria.reconciliation_spresso where day = '2025-12-01' and drn = 'DRN017671';

select * from reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
where day = '2025-12-01' and drn = 'DRN017671';


---Segun re-ran Recon for Dec 1st and Now there are gaps---

---UPDATED DRIVER BALANCE CHECK SCRIPT - NIGERIA
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_nigeria.reconciliation_spresso r
WHERE day = '2025-12-01'  --- yesterday
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_nigeria.reconciliation_spresso r
WHERE r.day = '2025-12-02' ---today.
order by drn
),
balance_equality_check as (select a.drn, b.cum_outstanding as previous_last_driver_closing_balance, a.prev_outstanding as this_week_driver_opening_balance,
    case 
        when ABS(ROUND(b.cum_outstanding,0) - ROUND(a.prev_outstanding,0)) <= 1 then 'ok'
        else 'fail'
    end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;






-------------------------------------------------------
select * from core_dimensions.mart_driver_paid_to_date where 
drn = 'MVS20385' and week >= '2025-10-20';



select count(distinct drn)drn from recon_south_africa.reconciliation --limit .
where product ilike '%flexi%';


select * from recon_south_africa.reconciliation --limit .
where product ilike '%flexi%' limit 10;

select distinct drn, product from recon_south_africa.reconciliation --limit .
where product ilike '%flexi%';

select count(distinct drn)drn, product from recon_south_africa.reconciliation
group by product;

contract_sk 

select * from fact_recon_daily limit 10;

select * FROM core_dimensions.fact_recon_daily
WHERE country = 'South Africa' limit 10;

---Check for new plans

recon_india.products


select * from core_dimensions.dim_driver_contract limit 10;


select * from core_dimensions.mart_driver_paid_to_date limit 10;


----Dec 12 2025----
select * from core_dimensions.contract_templates ct
inner join core_dimensions.driver_contracts dc ON ct.id = dc.template_id
inner join core_dimensions.drivers d on d.driver_id = dc.driver_id
where ct.contract_type ='FLR';


select * from core_dimensions.dim_contract_template limit 10;

select
d.drn
, ct.remittance AS base_remittance
, COALESCE(sapc.total_addon, 0) as selected_addon
, ct.remittance + selected_addon as net_remittance
, ct.contract_type
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
join core_dimensions.dim_contract_template ct ON dc.template_id = ct.template_id
left join selected_addons_per_contract sapc on dc.contract_id = sapc.driver_contract_id
where dc.status = 'ACTIVE'
and d.soft_deleted = false;


---Query to Get Drivers on Flexi Rental
select distinct drn from(
select recon.*, ct.contract_type from core_dimensions.fact_recon_daily recon
join core_dimensions.dim_driver d ON recon.driver_sk = d.driver_sk
join core_dimensions.dim_driver_contract dc on dc.driver_id = d.driver_id
join core_dimensions.dim_contract_template ct ON dc.template_id = ct.template_id 
--where d.drn in ('MVS10159', 'MVS10188') ; 
where ct.contract_type ='FLR');



-----------------------------
---Dec 12, 2025------
-----------------------------

---Quick Nigeria UberX Checks---
select count(driveruuid)driveruuid, sum(net_earning)net_earnings from partners_data_daily.vw_uber_driver_aggr
where country = 'Nigeria' and event_date >= '2025-12-08' and account = '5';

select * from partners_data_daily.vw_uber_driver_aggr
where country = 'Nigeria' and event_date >= '2025-12-08' and account = '5';

select * from partners_data_daily.vw_uber_driver_aggr where country = 'Nigeria' limit 10;

select distinct account from partners_data_daily.vw_uber_driver_aggr
where country = 'Nigeria' and event_date >= '2025-12-08';

-----Deep Dive on Contract Loan Paid To Date---

select count(distinct drn)drn_count from core_dimensions.mart_driver_paid_to_date;

select * from core_dimensions.mart_driver_paid_to_date;


---AHMED: Updated Weekly Contract Loan Book Query
WITH historical_paid_to_date AS (
  SELECT
    UPPER(drn)::VARCHAR AS drn
    , DATE_TRUNC('WEEK', week_start::DATE) AS week
    , total_received_contract::FLOAT AS total_received
  FROM "default".sa_prev_total_received_sophia
  WHERE total_received_contract IS NOT NULL
)
, payment_tbl AS (
  SELECT
    country
    , city
    , drn
    , recon_week AS week
    , day
    , uber_payments_partner_balance AS uber_balance
    , payments_payins AS bank_statement
    , incentives AS incentives
    , payments_payouts AS payouts
    , additional_charges_extra_charges AS extra_charges
    , additional_charges_passthrough_costs AS toll
    , adjustments AS adjustment_amount
    , adjustment_type AS adjustment_type
  FROM core_dimensions.fact_recon_daily
  WHERE country = 'South Africa'
)
, driver_contracts_tbl AS (
  SELECT
    dc.*
    , ct.contract_type
  FROM core_dimensions.dim_driver_contract dc
  INNER JOIN core_dimensions.dim_contract_template ct
    ON dc.template_id = ct.template_id
)
, dim_driver_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver
)
, calendar AS (
  SELECT DISTINCT DATE_TRUNC('WEEK', date) AS week
  FROM public.dim_calendar
  WHERE date <= CURRENT_DATE
)
, driver_contracts AS (
  WITH last_contract AS (
    SELECT
      dc.driver_id
      , dd.country
      , dc.start_date AS contract_start_date
      , DATE_TRUNC('WEEK', dc.start_date::DATE) AS contract_start_week
      , dc.status AS contract_status
      , dc.contract_type
    FROM driver_contracts_tbl dc
    INNER JOIN dim_driver_tbl dd
      ON dc.driver_id = dd.driver_id
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY dc.driver_id
      ORDER BY dc.start_date DESC, COALESCE(dc.end_date, CURRENT_DATE) DESC, dc.created_on DESC
    ) = 1
  )
  SELECT
    dd.driver_sk
    , dd.drn
    , dd.driver_id
    , dd.country
    , lc.contract_start_date
    , lc.contract_start_week
    , lc.contract_status
  FROM last_contract lc
  INNER JOIN dim_driver_tbl dd
    ON lc.driver_id = dd.driver_id
  WHERE lc.contract_type != 'FLR'
)
, paid_to_date_calculation AS (
  WITH driver_week_payments_data AS (
    SELECT
      country
      , city
      , drn
      , week
      , SUM(uber_balance) AS uber_balance
      , SUM(bank_statement) AS bank_statement
      , SUM(incentives) AS incentives
      , SUM(payouts) AS payouts
      , SUM(extra_charges) AS extra_charges
      , SUM(toll) AS toll
      , SUM(adjustment_amount) AS adjustment_amount
      , MAX(adjustment_type) AS adjustment_type
    FROM payment_tbl
    GROUP BY country, city, drn, week
  )
  , selected_payments AS (
    SELECT
      dc.driver_sk
      , dc.contract_status
      , dp.*
    FROM driver_week_payments_data dp
    INNER JOIN driver_contracts dc
      ON dp.drn = dc.drn
        AND dp.country = dc.country
        AND dp.week >= dc.contract_start_week
  )
  , week_paid_to_date AS (
    SELECT
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
      , sp.uber_balance
      , sp.bank_statement
      , sp.incentives
      , sp.payouts
      , sp.extra_charges
      , sp.adjustment_amount
      , sp.adjustment_type
      , sp.toll
      , SUM(
        sp.uber_balance
        + (
          CASE
            WHEN sp.country = 'South Africa' AND sp.week <= '2025-09-29' THEN sp.toll
            ELSE 0
          END
        )
        + sp.bank_statement
        + sp.incentives
        + sp.payouts
        + sp.extra_charges
        + (
          CASE
            WHEN sp.adjustment_type ILIKE '%Agreement of Debt%'
              OR sp.adjustment_type ILIKE '%Driver remit adjustment%'
              THEN 0
            ELSE sp.adjustment_amount
          END
        )
      ) AS total_received
    FROM selected_payments sp
    GROUP BY ALL
  )
  SELECT
    *
    , SUM(total_received) OVER (
      PARTITION BY drn, country
      ORDER BY week
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_total_received
  FROM week_paid_to_date
)
, paid_to_date_calendar AS (
  WITH paid_to_date_all_weeks AS (
    SELECT
      c.week
      , dc.country
      , dc.driver_sk
      , dc.driver_id
      , dc.drn
      , COALESCE(ptd.total_received, 0) AS week_total_received
      , ptd.cumulative_total_received
    FROM calendar c
    INNER JOIN driver_contracts dc
      ON TRUE
    INNER JOIN (
      SELECT
        country
        , MAX(week) AS max_week
      FROM payment_tbl
      GROUP BY country
    ) cw
      ON dc.country = cw.country
        AND c.week <= cw.max_week -- Limiting the calendar to last week of payments per country
    INNER JOIN (
      SELECT
        driver_sk
        , MIN(week) AS min_week
      FROM paid_to_date_calculation
      GROUP BY driver_sk
    ) mw
      ON dc.driver_sk = mw.driver_sk
        AND c.week >= mw.min_week
    LEFT JOIN paid_to_date_calculation ptd
      ON c.week = ptd.week
        AND dc.driver_sk = ptd.driver_sk
  )
  SELECT
    week
    , country
    , driver_sk
    , driver_id
    , drn
    , week_total_received
    , LAST_VALUE(cumulative_total_received IGNORE NULLS)
      OVER (
        PARTITION BY driver_sk
        ORDER BY week
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
    AS cumulative_total_received
  FROM paid_to_date_all_weeks
)
, paid_to_date_adjustment AS (
  SELECT
    ptd.driver_sk
    , ptd.country
    -- ptd.city,
    , ptd.drn
    , ptd.week
    , ptd.week_total_received
    , hptd.total_received AS historical_total_received
    , ptd.cumulative_total_received AS current_total_received
    , hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
  FROM paid_to_date_calendar ptd
  INNER JOIN historical_paid_to_date hptd
    ON ptd.drn = hptd.drn
      AND ptd.week = hptd.week
)
SELECT *
FROM paid_to_date_calculation
ORDER BY drn, week;




select drn, day, payments, payments_breakdown , 
COALESCE(NULLIF(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins'), ''), '0')::DECIMAL(18, 2)
    + COALESCE(NULLIF(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'sheet_payins'), ''), '0')::DECIMAL(18, 2)
    AS payments_payins
from recon.daily_recon_output where recon_week = '2025-12-01' and 
drn in ('MVS17500', 'MVS21721'
);


-----Payins
select * from payments_aggregator.aggregated_transactions --limit 10;
--where driver_number = 'MVS20772'
where created::DATE between '2025-12-01' and '2025-12-07' and country_code = 'ZA'
group by driver_number order by driver_number;


-----Payins
select distinct driver_number, sum(amount) as payins from payments_aggregator.aggregated_transactions --limit 10;
where created::DATE between '2025-12-01' and '2025-12-07' and country_code = 'ZA'
group by driver_number order by driver_number;



select * from core_dimensions.mart_driver_paid_to_date
where week = '2025-12-01' and drn in ('MVS17500', 'MVS21721');


select * from recon.daily_recon_output where recon_week = '2025-12-01' and 
drn in ('MVS17500', 'MVS21721');


select * from core_dimensions.mart_driver_weekly_recon ---where lower(country) = 'south africa' and recon_week = '2025-12-01'
where drn in ('MVS17500', 'MVS21721');

select * from core_dimensions.fact_recon_daily where lower(country) = 'south africa' and recon_week = '2025-12-01'
and drn in ('MVS17500', 'MVS21721');


select * from recon.recon_output__income_statement rois
where rois.week_date = '2025-12-01' and country = 'South Africa'
and (uber_balance <> 0 or remit <> 0 or discount <> 0 or extra_charges <> 0 or payins <> 0
or payouts <> 0 or adjustments <> 0 or security_deposit_contribution <> 0)
and driver_total_received is not null and drn in ('MVS17500', 'MVS21721');


select * from core_dimensions.fact_recon_daily where lower(country) = 'south africa' and day = '2025-12-07'---and recon_week = '2025-12-01'
and drn not in (select distinct drn from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-12-01');


--Check for Missing DRNs in Weekly But Present in Daily---
select * from recon.daily_recon_output where lower(country) = 'south africa' and recon_week = '2025-12-01'
and drn not in (select distinct drn from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-12-01');




---Query From Vanshika That Updates Weekly Recon Table
WITH selected_drns AS (
  SELECT DISTINCT driver_id
  FROM core_dimensions.dim_driver_contract
)
, daily_recon_tbl AS (
  SELECT *
  FROM core_dimensions.fact_recon_daily
-- FROM dbt.fact_recon_daily
)
, driver_tbl AS (
  SELECT
    dd.driver_sk
    , dd.driver_id
    , dd.drn
    -- , cdd.first_name
    -- , cdd.last_name
  FROM core_dimensions.dim_driver dd
-- INNER JOIN dbt.core__driver_domain AS cdd
--   ON dd.driver_id = cdd.driver_id
)
, driver_contract_tbl AS (
  WITH driver_last_contract AS (
    SELECT
      ddc.driver_id
      , ddc.template_id
      , ddc.contract_id
      , ddc.vehicle_id
      , dct.template_code
    FROM core_dimensions.dim_driver_contract AS ddc
    INNER JOIN core_dimensions.dim_contract_template AS dct
      ON ddc.template_id = dct.template_id
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY ddc.driver_id
      ORDER BY ddc.start_date DESC
    ) = 1
  )
  SELECT
    ddc.driver_id
    , ddc.template_id
    , ddc.contract_id
    , ddc.template_code
    , dct.contract_type
    , dv.registration_no
    , dv.vehicle_make
    , dv.vehicle_model
    , dv.carco_erp_code
  FROM driver_last_contract AS ddc
  INNER JOIN core_dimensions.dim_contract_template AS dct
    ON ddc.template_id = dct.template_id
  INNER JOIN core_dimensions.dim_vehicle AS dv
    ON ddc.vehicle_id = dv.vehicle_id
)
, weekly_recon_tbl AS (
  WITH weekly_recon_data AS (
    SELECT
      -- frd.status,
      'PUBLISHED' AS status
      , frd.driver_sk
      , frd.country
      , frd.city
      , frd.recon_week
      , LISTAGG(DISTINCT frd.uber_id, '|') AS uber_id
      , frd.drn
      , SUM(frd.refund_and_expenses) AS refund_and_expenses
      , SUM(frd.tax_credit_from_uber) AS tax_credit_from_uber
      , NULL AS vehicle_assignment_status
      , SUM(frd.effective_days) AS effective_days
      , SUM(frd.effective_days_ineffective_days) AS ineffective_days
      , SUM(frd.cumulative_effective_days) AS cumulative_effective_days
      , SUM(frd.trips) AS trips
      , SUM(frd.supply_hours) AS supply_hours
      , SUM(
        frd.uber_payments_partner_balance
        - frd.uber_payments_collection
        - frd.uber_payments_witholding_tax
        - frd.uber_payments_cash_collected_by_driver
      ) AS total_earnings
      , SUM(frd.uber_payments_net_fare) AS net_earnings
      , SUM(frd.uber_payments_cash_collected_by_driver) AS cash_collected_by_driver
      , SUM(frd.uber_payments_partner_balance) AS uber_balance
      , SUM(frd.uber_payments_surge_and_promotion) AS surge_and_promotion
      , SUM(frd.taxes) AS taxes
      , ROUND(SUM(frd.driver_remit_for_the_period)) AS driver_remit_for_the_period
      , SUM(
        frd.driver_discounts_dynamic_pricing_discount
        + frd.driver_discounts_uber_dynamic_pricing_program_discount
      ) AS discount
      , SUM(frd.additional_charges_additional_charges) AS additional_charges
      , SUM(frd.additional_charges_extra_charges) AS extra_charges
      , SUM(frd.additional_charges_passthrough_costs) AS passthrough_costs
      , SUM(frd.incentives) AS incentives
      , SUM(frd.adjustments) AS adjustments
      , LISTAGG(frd.adjustment_type, '|') WITHIN GROUP (ORDER BY frd.adjustment_type) AS adjustment_type
      , SUM(frd.payments_payins) AS payins
      , SUM(frd.payments_payouts) AS payouts
      , SUM(frd.driver_balance_for_the_period) AS driver_balance_for_the_period
      , SUM(COALESCE(amount_credit_from_recon, 0)) * (-1) AS security_deposit_contribution
      , NULL AS deposits_inflow -- TODO: Add deposits inflow
      , NULL AS deposits_refunds -- TODO: Add deposits refunds
    FROM daily_recon_tbl AS frd
    GROUP BY
      frd.driver_sk
      , frd.country
      , frd.city
      , frd.recon_week
      , frd.drn
  )
  , balances_weekly AS (
    SELECT
      frd.driver_sk
      , frd.recon_week
      , FIRST_VALUE(frd.driver_opening_balance) OVER (
        PARTITION BY country, drn, recon_week
        ORDER BY day
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
      ) AS driver_opening_balance
      , LAST_VALUE(frd.driver_closing_balance) OVER (
        PARTITION BY country, drn, recon_week
        ORDER BY day
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
      ) AS driver_closing_balance
      , FIRST_VALUE(frd.security_deposit_opening_balance) OVER (
        PARTITION BY country, drn, recon_week
        ORDER BY day
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
      ) AS deposit_opening_balance
      , LAST_VALUE(frd.security_deposit_closing_balance) OVER (
        PARTITION BY country, drn, recon_week
        ORDER BY day
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
      ) AS deposit_closing_balance
    FROM daily_recon_tbl AS frd
    QUALIFY ROW_NUMBER() OVER (PARTITION BY frd.country, frd.drn, frd.recon_week ORDER BY day) = 1
  )
  SELECT
    frd.*
    , bw.driver_opening_balance
    , bw.driver_closing_balance
    , bw.deposit_opening_balance
    , bw.deposit_closing_balance
    , CASE
      WHEN bw.driver_closing_balance < -500 THEN 1 ELSE 0
    END AS default_times
  FROM weekly_recon_data AS frd
  INNER JOIN balances_weekly AS bw
    ON frd.driver_sk = bw.driver_sk
      AND frd.recon_week = bw.recon_week
)
SELECT
  frd.status
  , frd.driver_sk
  , dd.driver_id
  , frd.country
  , frd.city
  , frd.recon_week
  , frd.uber_id
  , frd.drn
  , dct.template_id
  , dct.template_code
  , dct.contract_type
  , dct.registration_no
  , dct.vehicle_make
  , dct.vehicle_model
  , dct.carco_erp_code
  , frd.refund_and_expenses
  , frd.tax_credit_from_uber
  , frd.vehicle_assignment_status
  , frd.effective_days
  , frd.ineffective_days
  , frd.cumulative_effective_days
  , frd.trips
  , frd.supply_hours
  , frd.total_earnings
  , frd.net_earnings
  , frd.cash_collected_by_driver
  , frd.uber_balance
  , frd.surge_and_promotion
  , frd.taxes
  , frd.driver_remit_for_the_period
  , frd.discount
  , frd.additional_charges
  , frd.extra_charges
  , frd.passthrough_costs
  , frd.incentives
  , frd.adjustments
  , frd.adjustment_type
  , frd.payins
  , frd.payouts
  , frd.driver_balance_for_the_period
  , frd.driver_opening_balance
  , frd.driver_closing_balance
  , frd.deposit_opening_balance
  , frd.security_deposit_contribution
  , frd.deposits_inflow
  , frd.deposits_refunds
  , frd.deposit_closing_balance
  -- , dd.first_name || ' ' || dd.last_name AS driver_name
  , frd.default_times
FROM weekly_recon_tbl frd
INNER JOIN driver_tbl AS dd
  ON frd.driver_sk = dd.driver_sk
LEFT JOIN driver_contract_tbl AS dct
  ON dd.driver_id = dct.driver_id
  where frd.drn in ('MVS17500',
'MVS23524',
'MVS12794',
'MVS23208',
'MVS12872',
'MVS12818',
'MVS15196',
'MVS21721') and frd.recon_week = '2025-12-01';



---INCOME STATEMENT---
select * from recon.recon_output__income_statement rois
where rois.week_date = '2025-12-01' and country = 'South Africa'
and (uber_balance <> 0 or remit <> 0 or discount <> 0 or extra_charges <> 0 or payins <> 0
or payouts <> 0 or adjustments <> 0 or security_deposit_contribution <> 0)
and drn in ('MVS17500',
'MVS23524',
'MVS12794',
'MVS23208',
'MVS12872',
'MVS12818',
'MVS15196',
'MVS21721');


and driver_total_received is not null ;



select distinct reconciliation_proxy_current.drivers_outstanding_report_uberx_lagos




-----------------------------------------
---====Dec 15, 2025===-----
--------------------------------------

select * from core_dimensions.mart_driver_paid_to_date
where week = '2025-12-01' and drn in ('MVS12853');

---Contracts Table--
select * from core_dimensions.dim_contract_template limit 10;


select * from core_dimensions.dim_contract_template ct
inner join core_dimensions.dim_driver_contract dc ON ct.template_id = dc.template_id
inner join core_dimensions.dim_driver d on d.driver_id = dc.driver_id
where drn = 'MVS12853';
--where ct.contract_type ='FLR';

select distinct drn, start_date, template_code from (
select * from core_dimensions.dim_contract_template ct
inner join core_dimensions.dim_driver_contract dc ON ct.template_id = dc.template_id
inner join core_dimensions.dim_driver d on d.driver_id = dc.driver_id
);


---Getting loan paid to date for all SA drivers
select distinct drn, week, week_total_received, cumulative_total_received, historical_total_received 
from core_dimensions.mart_driver_paid_to_date
where week = '2025-12-01' and drn in ('MVS11024');

cumulative_total_received

---Getting loan paid to date for all SA drivers
select distinct drn, week, week_total_received, cumulative_total_received, historical_total_received 
from core_dimensions.mart_driver_paid_to_date
where week = '2025-10-20';

select * from core_dimensions.mart_driver_paid_to_date
where drn = 'MVS19999';

 recon.loanbook_sheet_download_sophia_11_12_25
 
 
 
 

 
 with loan_sheets as (
  SELECT city::VARCHAR AS city,product::VARCHAR AS _product, week::DATE AS _week, UPPER(drn::VARCHAR) AS _drn,
       uber_balance::FLOAT AS _uber_balance, extra_charges::FLOAT AS _extra_charges, payins::FLOAT AS _payins, payouts::FLOAT AS _payouts, incentives::FLOAT AS _incentives,
       total_remitted_for_the_loan_emi_opex_::FLOAT AS _total_remitted_for_the_loan_emi_opex
FROM fivetran_gsheets.sa_historical_loanwaterfall
WHERE drn IS NOT null
union all
SELECT city::VARCHAR AS city,product::VARCHAR AS _product, week::DATE AS _week, UPPER(drn::VARCHAR) AS _drn,
       uber_balance::FLOAT AS _uber_balance, extra_charges::FLOAT AS _extra_charges, payins::FLOAT AS _payins, payouts::FLOAT AS _payouts, incentives::FLOAT AS _incentives,
       total_remitted_for_the_loan_emi_opex_::FLOAT AS _total_remitted_for_the_loan_emi_opex
FROM fivetran_gsheets.sa_historical_loanwaterfall_2
WHERE drn IS NOT null and CAST(week AS DATE) >= '2023-10-02'
union all
SELECT city::VARCHAR AS city,product::VARCHAR AS _product, week::DATE AS _week, UPPER(drn::VARCHAR) AS _drn,
       uber_balance::FLOAT AS _uber_balance, extra_charges::FLOAT AS _extra_charges, payins::FLOAT AS _payins, payouts::FLOAT AS _payouts, incentives::FLOAT AS _incentives,
       total_remitted_for_the_loan_emi_opex_::FLOAT AS _total_remitted_for_the_loan_emi_opex
FROM fivetran_gsheets.sa_historical_loanwaterfall_3
WHERE drn IS NOT null and week NOT LIKE '%/%' and CAST(week AS DATE) >= '2024-07-01'
union all
SELECT city::VARCHAR AS city,product::VARCHAR AS _product, week::DATE AS _week, UPPER(drn::VARCHAR) AS _drn,
       uber_balance::FLOAT AS _uber_balance, extra_charges::FLOAT AS _extra_charges, payins::FLOAT AS _payins, payouts::FLOAT AS _payouts, incentives::FLOAT AS _incentives,
       total_remitted_for_the_loan_emi_opex_::FLOAT AS _total_remitted_for_the_loan_emi_opex
FROM fivetran_gsheets.sa_historical_loanwaterfall_4
WHERE drn IS NOT null and week NOT LIKE '%/%' and CAST(week AS DATE) >= '2024-07-01'
union all
SELECT
  city::VARCHAR AS city,
  product::VARCHAR AS _product,
  week::DATE AS _week,
  UPPER(drn::VARCHAR) AS _drn,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(uber_balance::VARCHAR),           '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _uber_balance,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(extra_charges::VARCHAR),          '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _extra_charges,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(payins::VARCHAR),                 '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _payins,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(payouts::VARCHAR),                '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _payouts,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(incentives::VARCHAR),             '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _incentives,
  COALESCE(TRY_CAST(NULLIF(REGEXP_REPLACE(TRIM(total_remitted_for_the_loan_emi_opex_::VARCHAR), '[^0-9.+-]', ''), '') AS FLOAT), 0) AS _total_remitted_for_the_loan_emi_opex
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE drn IS NOT NULL
  AND week NOT LIKE '%/%'
  AND CAST(week AS DATE) between '2025-10-26' and '2025-11-24')
  SELECT
    ls.city,
    ls._product,
    ls._week,
    ls._drn,
    CASE WHEN ls._uber_balance = ls._uber_balance THEN ls._uber_balance ELSE 0 END AS _uber_balance,
    CASE WHEN ls._extra_charges = ls._extra_charges THEN ls._extra_charges ELSE 0 END AS _extra_charges,
    CASE WHEN ls._payins = ls._payins THEN ls._payins ELSE 0 END AS _payins,
    CASE WHEN ls._payouts = ls._payouts THEN ls._payouts ELSE 0 END AS _payouts,
    CASE WHEN ls._incentives = ls._incentives THEN ls._incentives ELSE 0 END AS _incentives,
    CASE WHEN ls._total_remitted_for_the_loan_emi_opex = ls._total_remitted_for_the_loan_emi_opex
         THEN ls._total_remitted_for_the_loan_emi_opex ELSE 0 END AS _total_remitted_for_the_loan_emi_opex
  FROM loan_sheets ls
  where _drn = 'MVS21824'
  order by ls._week;
 
 
 ---AHMED'S LOAN BOOK BREAKDOWN---
 Hey @Sophia Uwoziya here is the query for getting the payments used.

WITH historical_paid_to_date AS (
  SELECT
    UPPER(drn)::VARCHAR AS drn
    , DATE_TRUNC('WEEK', week_start::DATE) AS week
    , total_received_contract::FLOAT AS total_received
  FROM "default".sa_prev_total_received_sophia
  WHERE total_received_contract IS NOT NULL
)
, payment_tbl AS (
  SELECT
    country
    , city
    , drn
    , recon_week AS week
    , day
    , uber_payments_partner_balance AS uber_balance
    , payments_payins AS bank_statement
    , incentives AS incentives
    , payments_payouts AS payouts
    , additional_charges_extra_charges AS extra_charges
    , additional_charges_passthrough_costs AS toll
    , adjustments AS adjustment_amount
    , adjustment_type AS adjustment_type
  FROM core_dimensions.fact_recon_daily
  WHERE country = 'South Africa'
)
, driver_contracts_tbl AS (
  SELECT
    dc.*
    , ct.contract_type
  FROM core_dimensions.dim_driver_contract dc
  INNER JOIN core_dimensions.dim_contract_template ct
    ON dc.template_id = ct.template_id
)
, dim_driver_tbl AS (
  SELECT *
  FROM core_dimensions.dim_driver
)
, calendar AS (
  SELECT DISTINCT DATE_TRUNC('WEEK', date) AS week
  FROM public.dim_calendar
  WHERE date <= CURRENT_DATE
)
, driver_contracts AS (
  WITH last_contract AS (
    SELECT
      dc.driver_id
      , dd.country
      , dc.start_date AS contract_start_date
      , DATE_TRUNC('WEEK', dc.start_date::DATE) AS contract_start_week
      , dc.status AS contract_status
      , dc.contract_type
    FROM driver_contracts_tbl dc
    INNER JOIN dim_driver_tbl dd
      ON dc.driver_id = dd.driver_id
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY dc.driver_id
      ORDER BY dc.start_date DESC, COALESCE(dc.end_date, CURRENT_DATE) DESC, dc.created_on DESC
    ) = 1
  )
  SELECT
    dd.driver_sk
    , dd.drn
    , dd.driver_id
    , dd.country
    , lc.contract_start_date
    , lc.contract_start_week
    , lc.contract_status
  FROM last_contract lc
  INNER JOIN dim_driver_tbl dd
    ON lc.driver_id = dd.driver_id
  WHERE lc.contract_type != 'FLR'
)
, paid_to_date_calculation AS (
  WITH driver_week_payments_data AS (
    SELECT
      country
      , city
      , drn
      , week
      , SUM(uber_balance) AS uber_balance
      , SUM(bank_statement) AS bank_statement
      , SUM(incentives) AS incentives
      , SUM(payouts) AS payouts
      , SUM(extra_charges) AS extra_charges
      , SUM(toll) AS toll
      , SUM(adjustment_amount) AS adjustment_amount
      , MAX(adjustment_type) AS adjustment_type
    FROM payment_tbl
    GROUP BY country, city, drn, week
  )
  , selected_payments AS (
    SELECT
      dc.driver_sk
      , dc.contract_status
      , dp.*
    FROM driver_week_payments_data dp
    INNER JOIN driver_contracts dc
      ON dp.drn = dc.drn
        AND dp.country = dc.country
        AND dp.week >= dc.contract_start_week
  )
  , week_paid_to_date AS (
    SELECT
      sp.driver_sk
      , sp.country
      , sp.city
      , sp.drn
      , sp.week
      , sp.uber_balance
      , sp.bank_statement
      , sp.incentives
      , sp.payouts
      , sp.extra_charges
      , sp.adjustment_amount
      , sp.adjustment_type
      , sp.toll
      , SUM(
        sp.uber_balance
        + (
          CASE
            WHEN sp.country = 'South Africa' AND sp.week <= '2025-09-29' THEN sp.toll
            ELSE 0
          END
        )
        + sp.bank_statement
        + sp.incentives
        + sp.payouts
        + sp.extra_charges
        + (
          CASE
            WHEN sp.adjustment_type ILIKE '%Agreement of Debt%'
              OR sp.adjustment_type ILIKE '%Driver remit adjustment%'
              THEN 0
            ELSE sp.adjustment_amount
          END
        )
      ) AS total_received
    FROM selected_payments sp
    GROUP BY ALL
  )
  SELECT
    *
    , SUM(total_received) OVER (
      PARTITION BY drn, country
      ORDER BY week
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_total_received
  FROM week_paid_to_date
)
, paid_to_date_calendar AS (
  WITH paid_to_date_all_weeks AS (
    SELECT
      c.week
      , dc.country
      , dc.driver_sk
      , dc.driver_id
      , dc.drn
      , COALESCE(ptd.total_received, 0) AS week_total_received
      , ptd.cumulative_total_received
    FROM calendar c
    INNER JOIN driver_contracts dc
      ON TRUE
    INNER JOIN (
      SELECT
        country
        , MAX(week) AS max_week
      FROM payment_tbl
      GROUP BY country
    ) cw
      ON dc.country = cw.country
        AND c.week <= cw.max_week -- Limiting the calendar to last week of payments per country
    INNER JOIN (
      SELECT
        driver_sk
        , MIN(week) AS min_week
      FROM paid_to_date_calculation
      GROUP BY driver_sk
    ) mw
      ON dc.driver_sk = mw.driver_sk
        AND c.week >= mw.min_week
    LEFT JOIN paid_to_date_calculation ptd
      ON c.week = ptd.week
        AND dc.driver_sk = ptd.driver_sk
  )
  SELECT
    week
    , country
    , driver_sk
    , driver_id
    , drn
    , week_total_received
    , LAST_VALUE(cumulative_total_received IGNORE NULLS)
      OVER (
        PARTITION BY driver_sk
        ORDER BY week
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      )
    AS cumulative_total_received
  FROM paid_to_date_all_weeks
)
, paid_to_date_adjustment AS (
  SELECT
    ptd.driver_sk
    , ptd.country
    -- ptd.city,
    , ptd.drn
    , ptd.week
    , ptd.week_total_received
    , hptd.total_received AS historical_total_received
    , ptd.cumulative_total_received AS current_total_received
    , hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
  FROM paid_to_date_calendar ptd
  INNER JOIN historical_paid_to_date hptd
    ON ptd.drn = hptd.drn
      AND ptd.week = hptd.week
)
SELECT *
FROM paid_to_date_calculation
where drn = 'MVS10946'
ORDER BY drn, week;



select * from core_dimensions.mart_driver_weekly_recon_draft where lower(country) = 'south africa' and recon_week = '2025-12-08';




-----Uber Earnings---
select distinct duuid,drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2025-12-08'
and duuid = '13c7bb1d-4ae9-48d4-bec3-4afdd727a52b'
group by duuid,drn  order by drn;



select * from core_dimensions.fact_recon_daily where lower(country) = 'south africa' ---and day = '2025-12-07'---and recon_week = '2025-12-01'
and drn = 'MVS14939' order by day asc;

select * from 
'MVS17942'


---BALANCES CHECK DAILY
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.recon_week as week, r.day, r.driver_opening_balance, r.driver_closing_balance, r.status, r.ingestion_date
FROM recon.raw_daily_recon_output r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon.raw_daily_recon_output
    WHERE recon_week < '2025-12-08' ---get the Monday date of last week.
    and status = 'PUBLISHED' and country = 'South Africa'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.recon_week < '2025-12-08' ---get the Monday date of last week.
and country = 'South Africa'
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance, r.status, r.ingestion_date
FROM (select * from recon.raw_daily_recon_output where recon_week = '2025-12-08' ---get the Monday date of last week.
    and status = 'PUBLISHED' and country = 'South Africa') r
JOIN (
    select drn, min(day) as min_day
    FROM recon.raw_daily_recon_output
    WHERE recon_week = '2025-12-08' ---get the Monday date of last week.
    and status = 'PUBLISHED' and country = 'South Africa'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.recon_week = '2025-12-08' ---get the Monday date of last week.
and country = 'South Africa'
order by drn
),
balance_equality_check as (select a.drn, ROUND(b.driver_closing_balance,2) as previous_last_driver_closing_balance, ROUND(a.driver_opening_balance,2) as this_week_driver_opening_balance,
(ROUND(b.driver_closing_balance,2) - ROUND(a.driver_opening_balance,2)) as gap,
   case
       when ABS(ABS(ROUND(b.driver_closing_balance,2)) - ABS(ROUND(a.driver_opening_balance,2))) <= 1 then 'ok'
       else 'fail'
   end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check ---where drn = 'MVS20604';
--where balance_equality_check = 'fail'
order by drn;




---BALANCES CHECK WEEKLY---
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
----RECON 2.0---
select r.drn, r.recon_week, r.driver_opening_balance , r.driver_closing_balance
FROM core_dimensions.mart_driver_weekly_recon r
WHERE r.recon_week = '2025-12-01' ---get the Monday date of upper week.
and country = 'South Africa'
order by drn
),
output_this_week as (
---RECON 2.0----
select r.drn, r.recon_week, r.driver_opening_balance , r.driver_closing_balance
FROM core_dimensions.mart_driver_weekly_recon_draft r
WHERE r.recon_week = '2025-12-08' ---get the Monday date of upper week.
 and country = 'South Africa'
order by drn
),
balance_equality_check as (select a.drn, ROUND(b.driver_closing_balance,2) as previous_last_driver_closing_balance, ROUND(a.driver_opening_balance,2) as this_week_driver_opening_balance,
(ROUND(b.driver_closing_balance,2) - ROUND(a.driver_opening_balance,2)) as gap,
   case
       when ABS(ABS(ROUND(b.driver_closing_balance,2)) - ABS(ROUND(a.driver_opening_balance,2))) <= 1 then 'ok'
       else 'fail'
   end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check ---where drn = 'MVS20604';
--where balance_equality_check = 'fail'
order by drn;


MVCO01491


-----------------------------------
---Dec 16, 2025----
----------------------------------

select * from recon_south_africa.reconciliation
where week = '2025-10-06' and adjustment_type ilike 'Driver remit adjustment - days' and adjustment_amount >= -200;


select * from recon_south_africa.reconciliation
where week = '2025-10-06' and adjustment_description ilike 'Tolls removal';
order by drn;


select count(distinct drn)drn_count, week from recon_south_africa.reconciliation
where week between '2025-09-29' and '2025-10-14' 
and adjustment_description ilike 'Tolls removal' and adjustment_type ilike 'Driver remit adjustment - days'
group by week order by week;


----Check Mexico New Plans reflect on Copilot---

select * from core.plans limit 10;

select * from core.plans_vehicles limit 10;

select distinct plan_code, remittance_value from core.plans
where plan_code ilike '%MX%';



MVS17942 

select * from core_dimensions.mart_driver_weekly_recon_draft 
where recon_week = '2025-12-08' 
and drn = 'MVS17942';


------------------------------------------
---Dec 17 2025---
---SA COntract Checks----

select * from core_dimensions.mart_driver_paid_to_date
where drn = 'MVS14212';


select * from core_dimensions.mart_driver_weekly_recon_draft 
where recon_week = '2025-12-08' 
and drn = 'MVS17942';


select * from core_dimensions.mart_driver_weekly_recon_draft 
where recon_week = '2025-12-08' 
and drn = 'MVS17942';



select *---distinct drn, start_date, template_code 
from (
select * from core_dimensions.dim_contract_template ct
inner join core_dimensions.dim_driver_contract dc ON ct.template_id = dc.template_id
inner join core_dimensions.dim_driver d on d.driver_id = dc.driver_id
)
where drn in ('MVS10444',
'MVS11308',
'MVS11531',
'MVS12794',
'MVS12818',
'MVS12872',
'MVS15196',
'MVS15529',
'MVS17942',
'MVS20660',
'MVS22573');


select distinct drn, remittance, dc.status, start_date, template_code 
from (
select * from core_dimensions.dim_contract_template ct
inner join core_dimensions.dim_driver_contract dc ON ct.template_id = dc.template_id
inner join core_dimensions.dim_driver d on d.driver_id = dc.driver_id
)
where dc.status = 'ACTIVE' and drn = 'MVS10288';



---SA Loan Paid To Date Checks----

select * from core_dimensions.mart_driver_paid_to_date
where drn = 'MVS14212' and week = '2025-10-20';


select * from recon.loanbook_sheet_download_sophia_11_12_25
where drn = 'MVS14212';

select drn, week, week_total_received, cumulative_total_received, historical_total_received, total_received_adjustment, driver_total_received, last_contract_start_date 
from core_dimensions.mart_driver_paid_to_date
where week = '2025-10-20'
and drn in (
'MVS10426',
'MVS10575',
'MVS10783',
'MVS11876',
'MVS00104',
'MVS12555',
'MVS11933',
'MVS12641',
'MVS12805',
'MVS12899',
'MVS13177',
'MVS11708',
'MVS13230',
'MVS13976',
'MVS14212',
'MVS10557',
'MVS13900',
'MVS14174',
'MVS14312',
'MVS14366',
'MVS13822',
'MVS14316',
'MVS14473',
'MVS14497',
'MVS14504',
'MVS14448',
'MVS11055',
'MVS14592',
'MVS14590',
'MVS14615',
'MVS14287',
'MVS11964',
'MVS13197',
'MVS13346',
'MVS13188',
'MVS13056',
'MVS12565',
'MVS10303',
'MVS10839',
'MVS11782',
'MVS13172',
'MVS13423',
'MVS10982',
'MVS10521',
'MVS11696',
'MVS13297',
'MVS13714',
'MVS12592',
'MVS12910',
'MVS14865',
'MVS11460',
'MVS11754',
'MVS14882',
'MVS13495',
'MVS13623',
'MVS10284',
'MVS13515',
'MVS10484',
'MVS14863',
'MVS13210',
'MVS10299',
'MVS12889',
'MVS12853',
'MVS12717',
'MVS12727',
'MVS12648',
'MVS13072',
'MVS13110',
'MVS13200',
'MVS13157',
'MVS12801',
'MVS12909',
'MVS12763',
'MVS13147',
'MVS11086',
'MVS11108',
'MVS10287',
'MVS12144',
'MVS12859',
'MVS11343',
'MVS10527',
'MVS10274',
'MVS12807',
'MVS11030',
'MVS13701',
'MVS14186',
'MVS10166',
'MVS14076',
'MVS10257',
'MVS11174',
'MVS12039',
'MVS10601',
'MVS12053',
'MVS10312',
'MVS10533',
'MVS14993',
'MVS10986',
'MVS10782',
'MVS13108',
'MVS14738',
'MVS14746',
'MVS14901',
'MVS15039',
'MVS13193',
'MVS15303',
'MVS15305',
'MVS15315',
'MVS15010',
'MVS15347',
'MVS15156',
'MVS15350',
'MVS15358',
'MVS15410',
'MVS10145',
'MVS15446',
'MVS10033',
'MVS13547',
'MVS10204',
'MVS15643',
'MVS11289',
'MVS15710',
'MVS15671',
'MVS15748',
'MVS15811',
'MVS15856',
'MVS15877',
'MVS11804',
'MVS15957',
'MVS13396',
'MVS15942',
'MVS16041',
'MVS16106',
'MVS16110',
'MVS16116',
'MVS16118',
'MVS16180',
'MVS16162',
'MVS16194',
'MVS16190',
'MVS10391',
'MVS16295',
'MVS16352',
'MVS16396',
'MVS16580',
'MVS16669',
'MVS13225',
'MVS16691',
'MVS16532',
'MVS11291',
'MVS16756',
'MVS16772',
'MVS16489',
'MVS16745',
'MVS16804',
'MVS16857',
'MVS16548',
'MVS16681',
'MVS16932',
'MVS16984',
'MVS16060',
'MVS16558',
'MVS15647',
'MVS17049',
'MVS17122',
'MVS17088',
'MVS17123',
'MVS17147',
'MVS17188',
'MVS17293',
'MVS17312',
'MVS17325',
'MVS17361',
'MVS17385',
'MVS17384',
'MVS17407',
'MVS17408',
'MVS17423',
'MVS17454',
'MVS11861',
'MVS17190',
'MVS17497',
'MVS17536',
'MVS17525',
'MVS17573',
'MVS17602',
'MVS17592',
'MVS17650',
'MVS17710',
'MVS17648',
'MVS17769',
'MVS17780',
'MVS17781',
'MVS17791',
'MVS15127',
'MVS17867',
'MVS17919',
'MVS14956',
'MVS17946',
'MVS17950',
'MVS15051',
'MVS17719',
'MVS17813',
'MVS14205',
'MVS10889',
'MVS18026',
'MVS18027',
'MVS12820',
'MVS18040',
'MVS17937',
'MVS16113',
'MVS16469',
'MVS18107',
'MVS14989',
'MVS18108',
'MVS15893',
'MVS18150',
'MVS18152',
'MVS15412',
'MVS17050',
'MVS16644',
'MVS18244',
'MVS18253',
'MVS18276',
'MVS18327',
'MVS18312',
'MVS16227',
'MVS18332',
'MVS14689',
'MVS18369',
'MVS18385',
'MVS16803',
'MVS18404',
'MVS18305',
'MVS18043',
'MVS18448',
'MVS18463',
'MVS18483',
'MVS18506',
'MVS11970',
'MVS18528',
'MVS18583',
'MVS18518',
'MVS16763',
'MVS18640',
'MVS18637',
'MVS18629',
'MVS18675',
'MVS18683',
'MVS18682',
'MVS18711',
'MVS18752',
'MVS18779',
'MVS18798',
'MVS18852',
'MVS18872',
'MVS17868',
'MVS18920',
'MVS18921',
'MVS18894',
'MVS18800',
'MVS18965',
'MVS18975',
'MVS18977',
'MVS19034',
'MVS19082',
'MVS19111',
'MVS19160',
'MVS19192',
'MVS19165',
'MVS19184',
'MVS19218',
'MVS19230',
'MVS19276',
'MVS19255',
'MVS19284',
'MVS19298',
'MVS19341',
'MVS19103',
'MVS17825',
'MVS19354',
'MVS13277',
'MVS19385',
'MVS19388',
'MVS19408',
'MVS19430',
'MVS19427',
'MVS10461',
'MVS19444',
'MVS19432',
'MVS19447',
'MVS19468',
'MVS16686',
'MVS13369',
'MVS19274',
'MVS19512',
'MVS19474',
'MVS19495',
'MVS19523',
'MVS19503',
'MVS19558',
'MVS15910',
'MVS19598',
'MVS16744',
'MVS19635',
'MVS17709',
'MVS19660',
'MVS19688',
'MVS19715',
'MVS19755',
'MVS19751',
'MVS17197',
'MVS19775',
'MVS19780',
'MVS19767',
'MVS19828',
'MVS19816',
'MVS19808',
'MVS19838',
'MVS18189',
'MVS19834',
'MVS19850',
'MVS15821',
'MVS15604',
'MVS14598',
'MVS11747',
'MVS19942',
'MVS19931',
'MVS14263',
'MVS18716',
'MVS19976',
'MVS20018',
'MVS20017',
'MVS19993',
'MVS13109',
'MVS20120',
'MVS20108',
'MVS20176',
'MVS20210',
'MVS20235',
'MVS20242',
'MVS20245',
'MVS20271',
'MVS20286',
'MVS20294',
'MVS20288',
'MVS20317',
'MVS19019',
'MVS20346',
'MVS20358',
'MVS20369',
'MVS20409',
'MVS20403',
'MVS20382',
'MVS18395',
'MVS20407',
'MVS20436',
'MVS20435',
'MVS20446',
'MVS20467',
'MVS20477',
'MVS20513',
'MVS20507',
'MVS20530',
'MVS12174',
'MVS20491',
'MVS20509',
'MVS20556',
'MVS20579',
'MVS20528',
'MVS20603',
'MVS20645',
'MVS16282',
'MVS20633',
'MVS20652',
'MVS20609',
'MVS20672',
'MVS20694',
'MVS20697',
'MVS20706',
'MVS20710',
'MVS20707',
'MVS20726',
'MVS20723',
'MVS20527',
'MVS20716',
'MVS20733',
'MVS20724',
'MVS20751',
'MVS20730',
'MVS20753',
'MVS19601',
'MVS20809',
'MVS20815',
'MVS20816',
'MVS20835',
'MVS15143',
'MVS20850',
'MVS20852',
'MVS20862',
'MVS20870',
'MVS20889',
'MVS20882',
'MVS20903',
'MVS20911',
'MVS20914',
'MVS20939',
'MVS20945',
'MVS20916',
'MVS17681',
'MVS20971',
'MVS21001',
'MVS21007',
'MVS21021',
'MVS21057',
'MVS21059',
'MVS21070',
'MVS21068',
'MVS21093',
'MVS21118',
'MVS21120',
'MVS21100',
'MVS21133',
'MVS16386',
'MVS20610',
'MVS21170',
'MVS21178',
'MVS21197',
'MVS21189',
'MVS21202',
'MVS21167',
'MVS21226',
'MVS12781',
'MVS21275',
'MVS21278',
'MVS21294',
'MVS21299',
'MVS12610',
'MVS21326',
'MVS21330',
'MVS17486',
'MVS21333',
'MVS21363',
'MVS21359',
'MVS21384',
'MVS21377',
'MVS15025',
'MVS21406',
'MVS21429',
'MVS21448',
'MVS18405',
'MVS21464',
'MVS12761',
'MVS21469',
'MVS21484',
'MVS20372',
'MVS21491',
'MVS12021',
'MVS21485',
'MVS21510',
'MVS21504',
'MVS21509',
'MVS21522',
'MVS21022',
'MVS14037',
'MVS13564',
'MVS17575',
'MVS21548',
'MVS21543',
'MVS21546',
'MVS21554',
'MVS21572',
'MVS21606',
'MVS21620',
'MVS21632',
'MVS21643',
'MVS21627',
'MVS21656',
'MVS21658',
'MVS21662',
'MVS16648',
'MVS21680',
'MVS10734',
'MVS21695',
'MVS21323',
'MVS21708',
'MVS21728',
'MVS21725',
'MVS21747',
'MVS21700',
'MVS21752',
'MVS21739',
'MVS14432',
'MVS21783',
'MVS21780',
'MVS21803',
'MVS21811',
'MVS21826',
'MVS21815',
'MVS21844',
'MVS21842',
'MVS21866',
'MVS21858',
'MVS21892',
'MVS21903',
'MVS21909',
'MVS21924',
'MVS17368',
'MVS21960',
'MVS21968',
'MVS21961',
'MVS21804',
'MVS21979',
'MVS22002',
'MVS22019',
'MVS22020',
'MVS21964',
'MVS21934',
'MVS22043',
'MVS21840',
'MVS22045',
'MVS22061',
'MVS20580',
'MVS22049',
'MVS21947',
'MVS22081',
'MVS22053',
'MVS22121',
'MVS22124',
'MVS22147',
'MVS22143',
'MVS22089',
'MVS22173',
'MVS22175',
'MVS21141',
'MVS22196',
'MVS22205',
'MVS22208',
'MVS22217',
'MVS22212',
'MVS22227',
'MVS22230',
'MVS22170',
'MVS22250',
'MVS22153',
'MVS22252',
'MVS22256',
'MVS22240',
'MVS22262',
'MVS22282',
'MVS22293',
'MVS22292',
'MVS22313',
'MVS22315',
'MVS21258',
'MVS22331',
'MVS22327',
'MVS22323',
'MVS22330',
'MVS22351',
'MVS22364',
'MVS21829',
'MVS22360',
'MVS22384',
'MVS22376',
'MVS19847',
'MVS22385',
'MVS22392',
'MVS22402',
'MVS22345',
'MVS22423',
'MVS16351',
'MVS22424',
'MVS22425',
'MVS22453',
'MVS22451',
'MVS21706',
'MVS22464',
'MVS13104',
'MVS22463',
'MVS22486',
'MVS22483',
'MVS22507',
'MVS22491',
'MVS22506',
'MVS22516',
'MVS22512',
'MVS22436',
'MVS22545',
'MVS22546',
'MVS20906',
'MVS22308',
'MVS22515',
'MVS22181',
'MVS22565',
'MVS22574',
'MVS22572',
'MVS22549',
'MVS22566',
'MVS22600',
'MVS22597',
'MVS22599',
'MVS22294',
'MVS22609',
'MVS22593',
'MVS15233',
'MVS22628',
'MVS22627',
'MVS22551',
'MVS22625',
'MVS22640',
'MVS22590',
'MVS22636',
'MVS22645',
'MVS22648',
'MVS22656',
'MVS22037',
'MVS16158',
'MVS22669',
'MVS22657',
'MVS22684',
'MVS22604',
'MVS22693',
'MVS22686',
'MVS22658',
'MVS11545',
'MVS22709',
'MVS22710',
'MVS22727',
'MVS22719',
'MVS22723',
'MVS22718',
'MVS17787',
'MVS22701',
'MVS22751',
'MVS21846',
'MVS22747',
'MVS22770',
'MVS22765',
'MVS22758',
'MVS22768',
'MVS22773',
'MVS22726',
'MVS22775',
'MVS22783',
'MVS20045',
'MVS22767',
'MVS22778',
'MVS22790',
'MVS22815',
'MVS15886'
);



select * from core_dimensions.fact_recon_daily where drn = 'MVS10426';



with 
contracts_data as (
select *,
case when end_date is not null then DATEADD(day, -1, end_date) end as logical_end_date 
from core_dimensions.dim_driver_contract 
where status in ('TERMINATED', 'ACTIVE', 'COMPLETED')
) 
, contracts_exploded as (select b.date, a.* from 
contracts_data a
join public.dim_calendar b 
on b.date BETWEEN a.start_date::date
      AND COALESCE(a.logical_end_date::date, CURRENT_DATE)
where b.date >= '2025-11-01' and b.date<= '2025-12-14' )
, selected_addons_per_contract as 
(
select
driver_contract_id
,sum(fta.addon_charge) AS total_addon
from core_dimensions.fact_contract_addons dcta
join core_dimensions.fact_template_addons fta on dcta.contract_template_addon_id = fta.template_addon_id
where fta.soft_deleted = FALSE
group by driver_contract_id
)
, contract_remit as 
(
select
dc.date
, dc.contract_id
, d.drn
, d.city
, d.country
, ct.remittance AS base_remittance
, COALESCE(sapc.total_addon, 0) as selected_addon
, ct.remittance + selected_addon as net_remittance
, dc.status
from contracts_exploded dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
join core_dimensions.dim_contract_template ct ON dc.template_id = ct.template_id
left join selected_addons_per_contract sapc on dc.contract_id = sapc.driver_contract_id
where d.soft_deleted = false
)
, driver_w_assignments_data as 
(
select 
drn
,city
,country
,"date"
,net_remittance
,registration_no
,start_datetime
,end_datetime
,contract_status
from 
(
select 
a.drn
,a.city
,a.country
,a."date"
,a.net_remittance
,b.registration_no
,b.start_datetime
,b.end_datetime
,a.status as contract_status
,rank()over(partition by a.drn, a.date order by b.start_datetime desc ) as rnk 
from contract_remit a
  LEFT JOIN (select * from core_dimensions.dim_vehicle_driver_assignment WHERE soft_deleted = false) b
    ON a.drn = b.drn and 
    a.date BETWEEN b.start_datetime ::date
      AND COALESCE(b.end_datetime ::date, CURRENT_DATE)) 
      where rnk = 1
)
select * from driver_w_assignments_data where drn = 'MVS13285';






WITH updated_res AS(
  WITH historical_paid_to_date AS (
    SELECT
      UPPER(drn)::VARCHAR AS drn
      , DATE_TRUNC('WEEK', week_start::DATE) AS week
      , total_received_contract::FLOAT AS total_received
    FROM "default".sa_prev_total_received_sophia
    WHERE total_received_contract IS NOT NULL
  )
  , payment_tbl AS (
    SELECT
      country
      , city
      , drn
      , recon_week AS week
      , day
      , uber_payments_partner_balance AS uber_balance
      , payments_payins AS bank_statement
      , incentives AS incentives
      , payments_payouts AS payouts
      , additional_charges_extra_charges AS extra_charges
      , additional_charges_passthrough_costs AS toll
      , adjustments AS adjustment_amount
      , adjustment_type AS adjustment_type
      , driver_opening_balance AS opening_balance
    FROM core_dimensions.fact_recon_daily
    WHERE country = 'South Africa'
  )
  , driver_contracts_tbl AS (
    SELECT
      dc.*
      , ct.contract_type
    FROM core_dimensions.dim_driver_contract dc
    INNER JOIN core_dimensions.dim_contract_template ct
      ON dc.template_id = ct.template_id
  )
  , dim_driver_tbl AS (
    SELECT *
    FROM core_dimensions.dim_driver
  )
  , calendar AS (
    SELECT DISTINCT DATE_TRUNC('WEEK', date) AS week
    FROM public.dim_calendar
    WHERE date <= CURRENT_DATE
  )
  , driver_contracts AS (
    WITH last_contract AS (
      SELECT
        dc.driver_id
        , dd.country
        , dc.start_date AS contract_start_date
        , DATE_TRUNC('WEEK', dc.start_date::DATE) AS contract_start_week
        , dc.status AS contract_status
        , dc.contract_type
      FROM driver_contracts_tbl dc
      INNER JOIN dim_driver_tbl dd
        ON dc.driver_id = dd.driver_id
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY dc.driver_id
        ORDER BY dc.start_date DESC, COALESCE(dc.end_date, CURRENT_DATE) DESC, dc.created_on DESC
      ) = 1
    )
    SELECT
      dd.driver_sk
      , dd.drn
      , dd.driver_id
      , dd.country
      , lc.contract_start_date
      , lc.contract_start_week
      , lc.contract_status
    FROM last_contract lc
    INNER JOIN dim_driver_tbl dd
      ON lc.driver_id = dd.driver_id
    WHERE lc.contract_type != 'FLR'
  )
  , paid_to_date_calculation AS (
    WITH driver_week_payments_data AS (
      SELECT
        country
        , city
        , drn
        , week
        , SUM(uber_balance) AS uber_balance
        , SUM(bank_statement) AS bank_statement
        , SUM(incentives) AS incentives
        , SUM(payouts) AS payouts
        , SUM(extra_charges) AS extra_charges
        , SUM(toll) AS toll
        , SUM(adjustment_amount) AS adjustment_amount
        , MAX(adjustment_type) AS adjustment_type
        , MAX(opening_balance) AS opening_balance
      FROM payment_tbl
      GROUP BY country, city, drn, week
    )
    , selected_payments AS (
      SELECT
        dc.driver_sk
        , dc.contract_status
        , dp.*
      FROM driver_week_payments_data dp
      INNER JOIN driver_contracts dc
        ON dp.drn = dc.drn
          AND dp.country = dc.country
          AND dp.week >= dc.contract_start_week
    )
    , first_week_of_payment AS (
      SELECT
        sp.drn
        , sp.week
      FROM selected_payments sp
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY sp.drn
        ORDER BY sp.week
      ) = 1
    )
    -- Extracting the opening balance of the first week of payment for tracking purposes
    , driver_opening_balance AS (
      SELECT
        sp.drn
        , sp.opening_balance
      FROM selected_payments sp
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY sp.drn
        ORDER BY sp.week
      ) = 1
    )
    , week_paid_to_date AS (
      SELECT
        sp.driver_sk
        , sp.country
        , sp.city
        , sp.drn
        , sp.week
        , sp.toll
        , sp.uber_balance
        , sp.bank_statement
        , sp.incentives
        , sp.payouts
        , sp.extra_charges
        , sp.adjustment_amount
        , sp.adjustment_type
        , SUM(
          sp.uber_balance
          + (
            CASE
              WHEN sp.country = 'South Africa' AND sp.week <= '2025-09-29' THEN sp.toll
              ELSE 0
            END
          )
          + sp.bank_statement
          + sp.incentives
          + sp.payouts
          + sp.extra_charges
          + (
            CASE
              WHEN sp.adjustment_type ILIKE '%Agreement of Debt%'
                OR sp.adjustment_type ILIKE '%Driver remit adjustment%'
                THEN 0
              ELSE sp.adjustment_amount
            END
          )
          + (
            CASE -- Adding the opening balance of the first week of payment
              WHEN fwp.week IS NOT NULL THEN sp.opening_balance
              ELSE 0
            END
          )
        ) AS total_received
      FROM selected_payments sp
      LEFT JOIN first_week_of_payment fwp
        ON sp.drn = fwp.drn
          AND sp.week = fwp.week
      GROUP BY ALL
    )
    , week_paid_to_date_with_opening_balance AS (
      SELECT
        sp.*
        , dob.opening_balance -- Adding the opening balance of the first week for tracking purposes
      FROM week_paid_to_date sp
      INNER JOIN driver_opening_balance dob
        ON sp.drn = dob.drn
    )
    SELECT
      *
      , SUM(total_received) OVER (
        PARTITION BY drn, country
        ORDER BY week
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
      ) AS cumulative_total_received
    FROM week_paid_to_date_with_opening_balance
  )
  , paid_to_date_calendar AS (
    WITH paid_to_date_all_weeks AS (
      SELECT
        c.week
        , dc.country
        , dc.driver_sk
        , dc.driver_id
        , dc.drn
        , COALESCE(ptd.opening_balance, 0) AS opening_balance
        , COALESCE(ptd.total_received, 0) AS week_total_received
        , ptd.cumulative_total_received
      FROM calendar c
      INNER JOIN driver_contracts dc
        ON TRUE
      INNER JOIN (
        SELECT
          country
          , MAX(week) AS max_week
        FROM payment_tbl
        GROUP BY country
      ) cw
        ON dc.country = cw.country
          AND c.week <= cw.max_week -- Limiting the calendar to last week of payments per country
      INNER JOIN (
        SELECT
          driver_sk
          , MIN(week) AS min_week
        FROM paid_to_date_calculation
        GROUP BY driver_sk
      ) mw
        ON dc.driver_sk = mw.driver_sk
          AND c.week >= mw.min_week
      LEFT JOIN paid_to_date_calculation ptd
        ON c.week = ptd.week
          AND dc.driver_sk = ptd.driver_sk
    )
    SELECT
      week
      , country
      , driver_sk
      , driver_id
      , drn
      , opening_balance
      , week_total_received
      , LAST_VALUE(cumulative_total_received IGNORE NULLS)
        OVER (
          PARTITION BY driver_sk
          ORDER BY week
          ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
        )
      AS cumulative_total_received
    FROM paid_to_date_all_weeks
  )
  , paid_to_date_adjustment AS (
    SELECT
      ptd.driver_sk
      , ptd.country
      -- ptd.city,
      , ptd.opening_balance
      , ptd.drn
      , ptd.week
      , ptd.week_total_received
      , hptd.total_received AS historical_total_received
      , ptd.cumulative_total_received AS current_total_received
      , hptd.total_received - ptd.cumulative_total_received AS total_received_adjustment
    FROM paid_to_date_calendar ptd
    INNER JOIN historical_paid_to_date hptd
      ON ptd.drn = hptd.drn
        AND ptd.week = hptd.week
  )
  SELECT
    dc.driver_id 
    , dc.drn AS driver_drn_with_opening_balance
    , dc.contract_start_date AS contract_start_date_with_opening_balance
    , dc.contract_status AS contract_status_with_opening_balance
    , cptd.week
    , cptd.opening_balance
    , cptd.week_total_received AS week_total_received_with_opening_balance
    , cptd.cumulative_total_received AS cumulative_total_received_with_opening_balance
  FROM driver_contracts dc
  INNER JOIN paid_to_date_calendar cptd
    ON dc.drn = cptd.drn
      AND dc.country = cptd.country
      AND cptd.week >= dc.contract_start_week
      AND cptd.week >= '2025-10-20'
  WHERE dc.country = 'South Africa'
)
SELECT 
  mptd.*,
  ur.*
FROM updated_res ur
FULL OUTER JOIN core_dimensions.mart_driver_paid_to_date mptd
  ON ur.driver_id = mptd.driver_id
    AND ur.week = mptd.week
where drn = 'MVS10426'    
ORDER BY ur.driver_id, ur.week;



select * from core_dimensions.mart_driver_paid_to_date
where drn = 'MVS14212' and week = '2025-10-20';


select * from recon.loanbook_sheet_download_sophia_11_12_25
where drn = 'MVS14212';


select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days < 0;


select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days > 6;




-----------------------
----Dec 18, 2025---
-----------------------

select week, drn, total_remitted_for_the_loan 
from recon.loanbook_sheet_download_sophia_11_12_25
where


select week, drn, sum(total_remitted_for_the_loan) as total_received_contract 
from recon.loanbook_sheet_download_sophia_11_12_25
group by week, drn
join



----Historical Loan Paid To Date Starting From Contract Week.----
WITH driver_last_contract AS (
    SELECT
      dd.drn
      ,ddc.*
    FROM core_dimensions.dim_driver_contract AS ddc
    INNER JOIN core_dimensions.dim_contract_template AS dct
      ON ddc.template_id = dct.template_id
    INNER JOIN core_dimensions.dim_driver AS dd
      ON ddc.driver_id = dd.driver_id
    QUALIFY ROW_NUMBER() OVER (
      PARTITION BY ddc.driver_id
      ORDER BY ddc.start_date DESC
    ) = 1
), contract as (
SELECT drn, 
start_date as contract_start_date,
DATE_TRUNC('WEEK', start_date::DATE) AS contract_start_week
FROM driver_last_contract),
historical_loan_paid_to_date AS (
  SELECT
    UPPER(drn)::VARCHAR AS drn
    , DATE_TRUNC('WEEK', week::DATE) AS week
    , total_remitted_for_the_loan::FLOAT AS total_received_contract
  FROM recon.loanbook_sheet_download_sophia_11_12_25 
  WHERE total_received_contract IS NOT null and week <= '2025-10-20'
)
select a.drn, sum(total_received_contract) as total_received_contract, b.contract_start_date, b.contract_start_week
from historical_loan_paid_to_date a
left join contract b
on a.drn = b.drn
where a.week >= b.contract_start_week
and a.drn = 'MVS13822'
group by a.drn, b.contract_start_date, b.contract_start_week;



---UPDATED---
WITH driver_last_contract AS (
      SELECT
        dd.drn
        , ddc.start_date as contract_start_date
        , DATE_TRUNC('WEEK', ddc.start_date::DATE) AS contract_start_week
      FROM core_dimensions.dim_driver_contract AS ddc
      INNER JOIN core_dimensions.dim_driver AS dd
        ON ddc.driver_id = dd.driver_id
      QUALIFY ROW_NUMBER() OVER (
        PARTITION BY ddc.driver_id
        ORDER BY ddc.start_date DESC
      ) = 1
  ),
  historical_loan_paid_to_date AS (
    SELECT
      UPPER(drn)::VARCHAR AS drn
      , DATE_TRUNC('WEEK', week::DATE) AS week
      , total_remitted_for_the_loan::FLOAT AS total_received_contract
    FROM recon.loanbook_sheet_download_sophia_11_12_25 
    WHERE total_received_contract IS NOT null and week <= '2025-10-20'
  )
  SELECT 
    a.drn
    , SUM(total_received_contract) AS total_received
    , MAX(week) AS week_start
  FROM historical_loan_paid_to_date a 
  INNER JOIN driver_last_contract b
    ON a.drn = b.drn
    AND a.week >= b.contract_start_week
    --where a.drn = 'MVS13822'
  GROUP BY a.drn;




----December 22, 2025-----

select * from core_dimensions.mart_driver_paid_to_date limit 10;

with new_loan as (select drn, last_contract_start_date, driver_total_received from core_dimensions.mart_driver_paid_to_date
where week = '2025-10-20'
),
old_loan as (
select distinct drn, min(week) as old_loan_week_start, sum(total_remitted_for_the_loan) as total_remitted_for_the_loan_recon 
from recon.loanbook_sheet_download_sophia_11_12_25 where week <= '2025-10-20'
group by drn
),
comparison as (
select distinct a.drn, old_loan_week_start, last_contract_start_date, (last_contract_start_date - old_loan_week_start) as Gap_in_Days,
NVL(sum(driver_total_received),0.0) as driver_total_received_contract, NVL(sum(total_remitted_for_the_loan_recon),0.0) as total_remitted_for_the_loan_recon,
ROUND((NVL(sum(total_remitted_for_the_loan_recon),0.0) - NVL(sum(driver_total_received),0.0)),2) as gap_in_loan_paid_to_date
from old_loan a
inner join new_loan b
on a.drn = b.drn
group by a.drn, old_loan_week_start, b.last_contract_start_date 
order by a.drn)
select * from comparison
where gap_in_days <> '0';


select distinct week from recon_south_africa.reconciliation 
where drn = 'MVS18695';



with current_loan as ( 
select * from dbt_vanshika.mart_driver_paid_to_date
), ---limit 10;
reviewed_loan as ( 
select * from core_dimensions.mart_driver_paid_to_date
)
select a.drn, a.week, a.week_total_received, a.cumulative_total_received, a.historical_total_received, a.total_received_adjustment, a.driver_total_received, a.last_contract_start_date,
 b.week, b.week_total_received, b.cumulative_total_received, b.historical_total_received, b.total_received_adjustment, b.driver_total_received, b.last_contract_start_date,
 ROUND((a.week_total_received - b.week_total_received),2) as gap_week_total_received,
 ROUND((a.cumulative_total_received - b.cumulative_total_received),2) as gap_cumulative_total_received,
 ROUND((a.historical_total_received -b.historical_total_received),2) as gap_historical_total_received,
 ROUND((a.total_received_adjustment - b.total_received_adjustment),2) as gap_total_received_adjustment,
 ROUND((a.driver_total_received - b.driver_total_received),2) as gap_driver_total_received,
(a.last_contract_start_date - b.last_contract_start_date) as gap_last_contract_start_date
from current_loan a
left join reviewed_loan b
on a.drn = b.drn and a.week = b.week
where gap_cumulative_total_received <> 0;




---------------------------------------------
---Dec 23, 2025-----
select * from core_dimensions.mart_driver_weekly_recon_draft 
where lower(country) = 'south africa' and recon_week = '2025-12-15';


from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-12-15';

select distinct week_date from reconciliation_proxy_current.drivers_outstanding_report_uberx_lagos
order by week_date;

select * from reconciliation_proxy_current.drivers_outstanding_report_uberx_lagos
where week_date = '2025-12-01';






---------------------------------------------
----Jan 5th 2026----
---Investigating India - Delhi Incentive Issue---
--===AGGREGATED===---
---UBER Daily
select driveruuid, event_date, sum(perf_trips)trips, sum(net_earning)net_earnings, sum(collection_cash_collected)collection_cash_collected,
sum(uber_balance)uber_balance, avg(acceptance_rate)acceptance_rate
from partners_data_daily.vw_uber_driver_aggr
where country = 'India' and event_date between '2025-12-22' and '2025-12-28' and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
group by driveruuid, event_date order by event_date;

---UBER Weekly
select driveruuid, event_date, sum(perf_trips)trips, sum(net_earning)net_earnings, sum(collection_cash_collected)collection_cash_collected,
sum(uber_balance)uber_balance, avg(acceptance_rate)acceptance_rate
from partners_data_weekly.vw_uber_driver_aggr
where country = 'India' and event_date = '2025-12-22' and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
group by driveruuid, event_date;


--===SOURCE===---
---UBER Daily - driver_quality
select * from partners_data_daily.mv_uber_harmonized_driver_quality
where source_file_date between '2025-12-22' and '2025-12-28' and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
order by source_file_date;

select paidtoyou__yourearnings
partners_data_daily.mv_uber_harmonized_payments_order



--Comparing Daily & Weekly Trips & Earnings---
SELECT
  driveruuid,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Trips' THEN value ELSE 0 END) AS daily_tripscompleted,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Trips' THEN value ELSE 0 END) AS weekly_tripscompleted,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Acceptance Rate' THEN value ELSE 0 END) AS daily_acceptancerate,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Acceptance Rate' THEN value ELSE 0 END) AS weekly_acceptancerate,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Earnings' THEN value ELSE 0 END) AS daily_earnings,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Earnings' THEN value ELSE 0 END) AS weekly_earnings
FROM (
  SELECT 'Daily' AS granularity, 'Trips' AS metric, driveruuid, tripscompleted AS value
  FROM partners_data_daily.mv_uber_harmonized_driver_activity
  WHERE source_file_date BETWEEN '2025-12-22' AND '2025-12-28'
  --and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Trips' AS metric, driveruuid, tripscompleted AS value
  FROM partners_data_weekly.mv_uber_harmonized_driver_activity
  WHERE source_file_date = '2025-12-22'
  UNION all
  SELECT 'Daily' AS granularity, 'Acceptance Rate' AS metric, driveruuid, avg(acceptancerate) AS value
  FROM partners_data_daily.mv_uber_harmonized_driver_quality
  WHERE source_file_date BETWEEN '2025-12-22' AND '2025-12-28'
  --and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
  group by driveruuid
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Acceptance Rate' AS metric, driveruuid, avg(acceptancerate) AS value
  FROM partners_data_weekly.mv_uber_harmonized_driver_quality
  WHERE source_file_date = '2025-12-22'
  group by driveruuid
  UNION ALL
  SELECT 'Daily' AS granularity, 'Earnings' AS metric, driveruuid, paidtoyou__yourearnings AS value
  FROM partners_data_daily.mv_uber_harmonized_payments_order
  WHERE source_file_date between '2025-12-22' AND '2025-12-28'
  --and driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Earnings' AS metric, driveruuid, paidtoyou__yourearnings AS value
  FROM partners_data_weekly.mv_uber_harmonized_payments_order
  WHERE source_file_date = '2025-12-22'
) AS merged_data
where driveruuid in ('731bb9d2-594f-4bf2-bc41-7ceb48247011',
'6425b8ce-ce79-414e-ad8f-6b881a801cee',
'aa7d2850-41ce-43f3-969d-ef3fcf8ca0c5',
'fcf27169-2890-4db0-a5be-d465ca53d0b9',
'cb015ff5-7ff8-4f56-8302-7f0821aad0cd',
'b9c13c45-e647-488b-bd4c-aaf5b6b0d1d1',
'462a9589-f77a-4a9e-83be-978f78fbdf85',
'28b51fab-c19d-482e-b7c4-c29f36917a2a',
'03de8ef0-1092-4a03-b134-21b5f7fddb78',
'3a81ec77-b2de-407b-9b49-ef52e8f55262')
GROUP BY driveruuid;




---Recon
select drn, week, sum(trips)trips, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(incentives)incentives, vehicle_type
from recon_india.daily_reconciliation
where drn in ('MVIN18467',
'MVIN20150',
'MVIN20374',
'MVIN20498',
'MVIN20510',
'MVIN20702',
'MVIN20846',
'MVIN20961',
'MVIN20985',
'MVIN21014') and week = '2025-12-22'
group by drn, week, vehicle_type
order by drn, week;


---Recon Daily
select drn, week, day, sum(trips)trips, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(refund_and_expenses)refund_and_expenses
from recon_india.daily_reconciliation
where drn in ('MVIN18467',
'MVIN20150',
'MVIN20374',
'MVIN20498',
'MVIN20510',
'MVIN20702',
'MVIN20846',
'MVIN20961',
'MVIN20985',
'MVIN21014') and week = '2025-12-22'
group by drn, week, day
order by drn, week, day;


select * from recon_india.daily_reconciliation
where drn = 'MVIN18467' and week = '2025-12-22';

--===DEEP DIVE====----

select * from persistence_uber_api_reports_weekly.payments_order_report
where driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011' and source_file_date = '2025-12-22';


select * from partners_data_daily.mv_uber_harmonized_driver_activity
where driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011' and source_file_date between '2025-12-22' AND '2025-12-28'; --= '2025-12-22';

select * from partners_data_weekly.mv_uber_harmonized_payments_order
where driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011' and source_file_date = '2025-12-22';



-----------------------------
----Jan 6, 2025-----
-------------------------------

select week_no,
                      licenseplate as vehicle_plate,
                      city,
                      SUM(perf_trips) AS incentive_trips_completed,
                      AVG(acceptance_rate * 100) AS incentive_acceptance_rate
                    FROM
                    partners_data_weekly.mv_uber_driver_aggr
                WHERE
                lower(country) = 'india'
                AND event_date = date_trunc('week', cast('{yesterday_date}' as date))
                AND licenseplate in ('{"', '".join(filtered_dtr_df['vehicle_plate'].astype(str))}')
                group by 1,2,3
                
                
                
select * from partners_data_weekly.mv_uber_driver_aggr muda 
WHERE lower(country) = 'india' AND event_date = '2025-12-25' limit 20;



------------------------------------------
----Jan 6, 2026-----

---===SA Historical Issues Checks====----

---Effective days < 0
select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days < 0;



----Effective days per week/drn > 6
select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days > 6;


----Deep Dives---
select * from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      and week = '2023-05-15' and drn ='MVS11720';



select * from recon_south_africa.days_adjustments 
where drn in ('MVS11720',
'MVS11777',
'MVS15541',
'MVS14951',
'MVS13815',
'MVS12012')
and reconciliation_date between '2023-05-15' and '2023-05-21';



select * from tmp_loan_book.stg_fct_recon
--recon_south_africa.reconciliation
where week = '2023-05-15' and drn ='MVS11720';


       
select * from
(SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where drn ='MVS12012' order by week asc;---and week = '2022-11-14' and ;




select * from recon_south_africa.days_adjustments 
where drn = 'MVS11777'
and reconciliation_date = '2022-10-17';




------------------------------------------------------
----Jan 07, 2026---

select * from recon_prod.india.incentive_programs 

select * from recon_india.incentive;

select * from recon_india.products;



---------------------------------------
----------Jan 8, 2026--------------
----Delhi Missing Incentives Analysis--------

select * from partners_data_weekly.vw_uber_driver_aggr
where country = 'India' and event_date = '2025-12-22' and drn = 'MVIN18467';

select * from partners_data_weekly.mv_uber_driver_aggr
where country = 'India' and week_no = '2025-12-22' and drn = 'MVIN18467';


with uber_records as (
--Comparing Daily & Weekly Trips & Earnings---
SELECT
  driveruuid,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Trips' THEN value ELSE 0 END) AS daily_tripscompleted,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Trips' THEN value ELSE 0 END) AS weekly_tripscompleted,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Acceptance Rate' THEN value ELSE 0 END) AS daily_acceptancerate,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Acceptance Rate' THEN value ELSE 0 END) AS weekly_acceptancerate,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Earnings' THEN value ELSE 0 END) AS daily_earnings,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Earnings' THEN value ELSE 0 END) AS weekly_earnings
FROM (
  SELECT 'Daily' AS granularity, 'Trips' AS metric, driveruuid, tripscompleted AS value
  FROM partners_data_daily.mv_uber_harmonized_driver_activity
  WHERE source_file_date BETWEEN '2025-12-22' AND '2025-12-28'
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Trips' AS metric, driveruuid, tripscompleted AS value
  FROM partners_data_weekly.mv_uber_harmonized_driver_activity
  WHERE source_file_date = '2025-12-22'
  UNION all
  SELECT 'Daily' AS granularity, 'Acceptance Rate' AS metric, driveruuid, sum(acceptancerate) AS value
  FROM partners_data_daily.mv_uber_harmonized_driver_quality
  WHERE source_file_date BETWEEN '2025-12-22' AND '2025-12-28'
  group by driveruuid
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Acceptance Rate' AS metric, driveruuid, acceptancerate AS value
  FROM partners_data_weekly.mv_uber_harmonized_driver_quality
  WHERE source_file_date = '2025-12-22'
  UNION ALL
  SELECT 'Daily' AS granularity, 'Earnings' AS metric, driveruuid, paidtoyou__yourearnings AS value
  FROM partners_data_daily.mv_uber_harmonized_payments_order
  WHERE source_file_date between '2025-12-22' AND '2025-12-28'
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Earnings' AS metric, driveruuid, paidtoyou__yourearnings AS value
  FROM partners_data_weekly.mv_uber_harmonized_payments_order
  WHERE source_file_date = '2025-12-22'
) AS merged_data
where driveruuid = '731bb9d2-594f-4bf2-bc41-7ceb48247011'
GROUP BY driveruuid;


),
recon_records as (
)
select * from




select week_no,
licenseplate as vehicle_plate,
city,
SUM(perf_trips) AS incentive_trips_completed,
AVG(acceptance_rate * 100) AS incentive_acceptance_rate
FROM
partners_data_weekly.mv_uber_driver_aggr
WHERE
lower(country) = 'india'
AND event_date = '2025-12-22'
AND licenseplate in (select vehicle_plate from recon_india.daily_reconciliation
where drn = 'MVIN18467' and week = '2025-12-22')
group by 1,2,3;



select *
FROM
partners_data_weekly.mv_uber_driver_aggr
WHERE
lower(country) = 'india'
AND event_date = '2025-12-22'
AND licenseplate in (select vehicle_plate from recon_india.daily_reconciliation
where drn = 'MVIN18467' and week = '2025-12-22');



---------------------------------------------------------------
------Getting Drivers Eligible for Incentives or Not-----------
---ALL----
with recon_records as (
  SELECT
    week,
    drn,
    MAX(CASE WHEN rn = 1 THEN uber_id END) AS uber_id,
    COUNT(DISTINCT uber_id) AS uuid_count,
    MAX(vehicle_type) AS vehicle_type,
    MAX(vehicle_plate) AS vehicle_plate,
    MAX(city) AS city,
    MAX(driver_type) as driver_type,
    MAX(product) AS product,
    SUM(effective_days) AS effective_days,
    NVL(SUM(trips),0.00) AS trips,
    SUM(supply_hours) AS supply_hours,
    SUM(net_earning) AS net_earning,
    SUM(incentives) AS incentives
  FROM (
    SELECT
      *,
      ROW_NUMBER() OVER (
        PARTITION BY week, drn
        ORDER BY day DESC
      ) AS rn
    FROM recon_india.daily_reconciliation
    WHERE week between '2025-12-22' and '2025-12-29'
  ) d
  GROUP BY week, drn
),
uber_records as (
select week_no, licenseplate as vehicle_plate, city,
NVL(SUM(perf_trips),0.00) AS incentive_trips_completed,
NVL(AVG(acceptance_rate * 100),0.00) AS incentive_acceptance_rate
FROM
partners_data_weekly.mv_uber_driver_aggr
WHERE
lower(country) = 'india'
AND event_date between '2025-12-22' and '2025-12-29'
--AND licenseplate in (select vehicle_plate from recon_india.daily_reconciliation
--where drn = 'MVIN18467' and week = '2025-12-22')
group by 1,2,3
)
select 
  rr.week,
  rr.drn,
  rr.uber_id,
  rr.uuid_count,
  rr.vehicle_type,
  rr.vehicle_plate,
  rr.city,
  rr.product,
  rr.trips,
  ur.incentive_acceptance_rate as acceptance_rate,
  rr.incentives,
  CASE
    WHEN rr.trips >= 60
     AND ur.incentive_acceptance_rate >= 15
    THEN 'YES'
    ELSE 'NO'
  END AS meets_minimum_criteria,
  CASE
    WHEN rr.trips < 60 AND ur.incentive_acceptance_rate < 15
      THEN 'FAILED_TRIPS_AND_AR'
    WHEN rr.trips < 60
      THEN 'FAILED_TRIPS'
    WHEN ur.incentive_acceptance_rate < 15
      THEN 'FAILED_ACCEPTANCE_RATE'
    ELSE 'PASSED'
  END AS criteria_status,
  ur.vehicle_plate,
  NVL(ur.incentive_trips_completed,0.00) as uber_trips_completed,
  NVL(ur.incentive_acceptance_rate,0.00) as uber_acceptance_rate
--  ur.cancellationrate,
  -- ur.completionrate
FROM recon_records rr
LEFT JOIN uber_records ur
  ON rr.vehicle_plate = ur.vehicle_plate
 AND ur.week_no BETWEEN rr.week AND rr.week + INTERVAL '6 day'
-- where vehicle_plate = 'HR55AT5170'
ORDER BY rr.week, rr.drn;


---------------------------------------------------------------
------Getting Drivers Eligible for Incentives or Not-----------
---ALL----Based on Vehicle Plate Only-----
with recon_records as (
  SELECT
    week,
    vehicle_type AS vehicle_type,
    vehicle_plate AS vehicle_plate,
    city AS city,
    product AS product,
    SUM(effective_days) AS effective_days,
    NVL(SUM(trips),0.00) AS trips,
    SUM(supply_hours) AS supply_hours,
    SUM(net_earning) AS net_earning,
    SUM(incentives) AS incentives
  FROM recon_india.daily_reconciliation
    WHERE week between '2025-12-22' and '2025-12-29'
    group by 1,2,3,4,5
),
uber_records as (
select week_no, licenseplate as vehicle_plate, city,
NVL(SUM(perf_trips),0.00) AS incentive_trips_completed,
NVL(AVG(acceptance_rate * 100),0.00) AS incentive_acceptance_rate
FROM
partners_data_weekly.mv_uber_driver_aggr
WHERE
lower(country) = 'india'
AND event_date between '2025-12-22' and '2025-12-29'
--AND licenseplate = 'HR55AS1911'
group by 1,2,3
),
combined as (
select 
  rr.week,
  rr.vehicle_type,
  rr.vehicle_plate as recon_vehicle_plate,
  rr.city,
  rr.product,
  NVL(SUM(rr.trips),0) as recon_trips,
  NVL(AVG(ur.incentive_acceptance_rate),0) as acceptance_rate,
  NVL(SUM(rr.incentives),0) as incentives,
  ur.vehicle_plate as uber_vehicle_plate,
  NVL(SUM(ur.incentive_trips_completed),0.00) as uber_trips_completed,
  NVL(AVG(ur.incentive_acceptance_rate),0.00) as uber_acceptance_rate
FROM recon_records rr
LEFT JOIN uber_records ur
  ON rr.vehicle_plate = ur.vehicle_plate
  and ur.week_no = rr.week
 group by 1,2,3,4,5,ur.vehicle_plate
ORDER BY rr.week
)
--select * from combined
---where recon_vehicle_plate = 'MH01DR9526';
select *,
  CASE
    WHEN recon_trips >= 60
     AND acceptance_rate >= 15
    THEN 'YES'
    ELSE 'NO'
  END AS meets_minimum_criteria,
  CASE
    WHEN recon_trips < 60 AND acceptance_rate < 15
      THEN 'FAILED_TRIPS_AND_AR'
    WHEN recon_trips < 60
      THEN 'FAILED_TRIPS'
    WHEN acceptance_rate < 15
      THEN 'FAILED_ACCEPTANCE_RATE'
    ELSE 'PASSED'
  END AS criteria_status
FROM combined;




select * FROM recon_india.daily_reconciliation
    WHERE week between '2025-12-22' and '2025-12-29'
and vehicle_plate = 'HR55AS1911';


------Getting DELHI Drivers Eligible for Incentives or Not-----------
---ALL----
with recon_records as (
  SELECT
    week,
    drn,
    MAX(CASE WHEN rn = 1 THEN uber_id END) AS uber_id,
    COUNT(DISTINCT uber_id) AS uuid_count,
    MAX(vehicle_type) AS vehicle_type,
    MAX(vehicle_plate) AS vehicle_plate,
    MAX(city) AS city,
    MAX(driver_type) as driver_type,
    MAX(product) AS product,
    SUM(effective_days) AS effective_days,
    SUM(trips) AS trips,
    SUM(supply_hours) AS supply_hours,
    SUM(net_earning) AS net_earning,
    SUM(incentives) AS incentives
  FROM (
    SELECT
      *,
      ROW_NUMBER() OVER (
        PARTITION BY week, drn
        ORDER BY day DESC
      ) AS rn
    FROM recon_india.daily_reconciliation
    WHERE week between '2025-12-22' and '2025-12-29'
  ) d
  GROUP BY week, drn
),
uber_records as (
select week_no, licenseplate as vehicle_plate, city,
NVL(SUM(perf_trips),0) AS incentive_trips_completed,
NVL(AVG(acceptance_rate * 100),0) AS incentive_acceptance_rate
FROM
partners_data_weekly.mv_uber_driver_aggr
WHERE
lower(country) = 'india'
AND event_date between '2025-12-22' and '2025-12-29'
--AND licenseplate in (select vehicle_plate from recon_india.daily_reconciliation
--where drn = 'MVIN18467' and week = '2025-12-22')
group by 1,2,3
)
select 
  rr.week,
  rr.drn,
  rr.uber_id,
  rr.uuid_count,
  rr.driver_type,
  rr.vehicle_type,
  rr.vehicle_plate as recon_vehicle_plate,
  rr.city,
  rr.product,
  rr.trips as recon_trips,
  ur.incentive_acceptance_rate as acceptance_rate,
  rr.incentives,
  CASE
    WHEN NVL(rr.trips,0) >= 60
     AND ur.incentive_acceptance_rate >= 15
    THEN 'YES'
    ELSE 'NO'
  END AS meets_minimum_criteria,
  CASE
    WHEN NVL(rr.trips,0) < 60 AND NVL(ur.incentive_acceptance_rate,0) < 15
      THEN 'FAILED_TRIPS_AND_AR'
    WHEN NVL(rr.trips,0) < 60
      THEN 'FAILED_TRIPS'
    WHEN NVL(ur.incentive_acceptance_rate,0) < 15
      THEN 'FAILED_ACCEPTANCE_RATE'
    ELSE 'PASSED'
  END AS criteria_status,
  ur.vehicle_plate as uber_vehicle_plate,
  NVL(ur.incentive_trips_completed,0) as uber_trips_completed,
  NVL(ur.incentive_acceptance_rate,0) as uber_acceptance_rate
--  ur.cancellationrate,
  -- ur.completionrate
FROM recon_records rr
LEFT JOIN uber_records ur
  ON rr.vehicle_plate = ur.vehicle_plate
 AND ur.week_no BETWEEN rr.week AND rr.week + INTERVAL '6 day'
-- where vehicle_plate = 'HR55AT5170'
ORDER BY rr.week, rr.drn;







-------------------------------------------------
----Jan 9, 2026------------
---- South Africa Solution - Getting the products each driver has been on from inception to date.
select drn, count(distinct week)week_count, count(distinct product)product_count, count(distinct vehicle_type)vehicle_type_count, 
count(distinct city)city_count, count(distinct remit_amount)
from (
---select distinct remit_amount from
select week, drn,product, vehicle_type, city,
ROUND(CEILING(NVL((amount_due/nullif(effective_days,0)),0.0))*6,-1) as remit_amount
from
(SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
------
where drn in (
'MVS10846','MVS17937',
'MVS10501','MVS13401',
'MVS17947','MVS11086',
'MVS14598','MVS18305',
'MVS10517','MVS10484',
'MVS16187','MVS17787',
'MVS19032','MVS12866',
'MVS20044','MVS11349',
'MVS13168','MVS21959',
'MVS11110','MVS16472',
'MVS16655','MVS20077',
'MVS11535','MVS11278','MVS10877',
'MVS12917','MVS10390',
'MVS19738','MVS11964',
'MVS10329','MVS15541',
'MVS13714','MVS16555',
'MVS12912','MVS13423',
'MVS10367','MVS16439',
'MVS13210','MVS22798',
'MVS10814','MVS15773',
'MVS10089','MVS18571',
'MVS16644','MVS14352','MVS22808',
'MVS18157','MVS14346',
'MVS19658','MVS18064',
'MVS13273','MVS16433',
'MVS10527','MVS12672',
'MVS16710','MVS19627',
'MVS11782','MVS17197',
'MVS11970','MVS15233',
'MVS11563','MVS15798',
'MVS13860','MVS17868',
'MVS17039','MVS10992',
'MVS21888','MVS10401',
'MVS13443','MVS18935',
'MVS14134','MVS16640',
'MVS10601','MVS16642',
'MVS14865','MVS17772',
'MVS12654','MVS10433',
'MVS22472','MVS12030',
'MVS20134','MVS11187',
'MVS11531','MVS13674',
'MVS10968','MVS10236',
'MVS16233','MVS10692',
'MVS17806','MVS11466',
'MVS21092','MVS12021',
'MVS17050','MVS10461',
'MVS16001','MVS10998',
'MVS10982','MVS11229',
'MVS12648','MVS13056',
'MVS11956','MVS10414',
'MVS15351','MVS13647',
'MVS22105','MVS13132',
'MVS21370','MVS12626',
'MVS11406','MVS20713',
'MVS11055','MVS12023',
'MVS11061','MVS10308',
'MVS16915','MVS17390',
'MVS10288','MVS11129',
'MVS16125','MVS13320',
'MVS12623','MVS19847',
'MVS14680','MVS11046',
'MVS11240','MVS14157',
'MVS12828','MVS16744',
'MVS22452','MVS13170',
'MVS12644','MVS12772',
'MVS10458','MVS17816',
'MVS12039','MVS21729',
'MVS22037','MVS11343',
'MVS11291','MVS12028',
'MVS16136','MVS16558',
'MVS10287','MVS10363',
'MVS21829','MVS10626',
'MVS10314','MVS18181','MVS16113',
'MVS22771','MVS12141',
'MVS16784','MVS11957',
'MVS11402','MVS14056',
'MVS13088','MVS17107',
'MVS13891','MVS18405',
'MVS14514','MVS12533',
'MVS13222','MVS12053',
'MVS18027','MVS10860',
'MVS12889','MVS18586',
'MVS13094','MVS16743',
'MVS12781','MVS17917',
'MVS18350','MVS12552',
'MVS10986','MVS11842',
'MVS10553','MVS16060',
'MVS22694','MVS22802',
'MVS13425','MVS12702',
'MVS11252','MVS22752',
'MVS12786','MVS13638',
'MVS11175','MVS22001',
'MVS10257','MVS12649',
'MVS12935','MVS13277',
'MVS12947','MVS17742',
'MVS10528','MVS17422',
'MVS15647','MVS13065',
'MVS18992','MVS10833',
'MVS14205','MVS11487',
'MVS13022','MVS12848',
'MVS18021','MVS20076',
'MVS12003','MVS12853',
'MVS13609','MVS12661',
'MVS13072','MVS18141',
'MVS13001','MVS17918',
'MVS13195','MVS15604',
'MVS20463','MVS13188',
'MVS11005','MVS13287',
'MVS13283','MVS13769',
'MVS13147','MVS17845',
'MVS18339','MVS19757',
'MVS12622','MVS13047',
'MVS17132','MVS21372',
'MVS18329','MVS19527',
'MVS11642','MVS15379',
'MVS11526','MVS10222',
'MVS13856','MVS10620',
'MVS12522','MVS22967',
'MVS16826','MVS15429',
'MVS14016','MVS11823',
'MVS12047','MVS14596',
'MVS17570','MVS12685',
'MVS15342','MVS13200',
'MVS13236','MVS11093',
'MVS13383','MVS11207',
'MVS11159','MVS10597',
'MVS13197','MVS10839',
'MVS19768','MVS19769',
'MVS15886','MVS17452',
'MVS11063','MVS13153',
'MVS11766','MVS10912',
'MVS14737','MVS22283',
'MVS22448','MVS14218',
'MVS15486','MVS21022',
'MVS15043','MVS17681',
'MVS14004','MVS10491',
'MVS16686','MVS21792',
'MVS12565','MVS12144',
'MVS21840','MVS12753',
'MVS13602','MVS22129',
'MVS11266','MVS15887',
'MVS12763','MVS20279',
'MVS12653','MVS11576',
'MVS11092','MVS11476',
'MVS17616','MVS16648',
'MVS12910','MVS12918',
'MVS21161','MVS18779',
'MVS17368','MVS14686',
'MVS15983','MVS12555',
'MVS12164','MVS10200',
'MVS13903','MVS22835',
'MVS12819','MVS10091',
'MVS12617','MVS17709',
'MVS22725','MVS14010',
'MVS10623','MVS13515',
'MVS16803','MVS14432',
'MVS16506','MVS15925',
'MVS11630','MVS22957',
'MVS15188','MVS16287',
'MVS12852','MVS12145',
'MVS16469','MVS13344',
'MVS11024','MVS13125',
'MVS19219','MVS13804',
'MVS12568','MVS11314',
'MVS13312','MVS17951',
'MVS23000','MVS15401',
'MVS20263','MVS21995',
'MVS16327','MVS13285',
'MVS12556','MVS14556',
'MVS10299','MVS17534',
'MVS16467','MVS17700',
'MVS13422','MVS11130',
'MVS10985','MVS21774',
'MVS11974','MVS14592',
'MVS10033','MVS11116',
'MVS11747','MVS16216',
'MVS13246','MVS18449',
'MVS16145','MVS11289',
'MVS13762','MVS11374',
'MVS13252','MVS15143',
'MVS11416','MVS11899',
'MVS19280','MVS10698',
'MVS10166','MVS16763',
'MVS10130','MVS10271',
'MVS20622','MVS20754',
'MVS11220','MVS11545',
'MVS10884','MVS10957',
'MVS13911','MVS19564',
'MVS11774','MVS10355',
'MVS14677','MVS13858',
'MVS10538','MVS17598',
'MVS14076','MVS11384',
'MVS10581','MVS14770',
'MVS10533','MVS12110',
'MVS14297','MVS22961',
'MVS16418','MVS11626',
'MVS14180','MVS16009',
'MVS11755','MVS17403',
'MVS13430','MVS10318',
'MVS10481','MVS16282',
'MVS22853','MVS15025',
'MVS12788','MVS20703',
'MVS11460','MVS12134',
'MVS10480','MVS14985',
'MVS11909','MVS18001',
'MVS11371','MVS11432',
'MVS21303','MVS10532',
'MVS19923','MVS12886',
'MVS16798','MVS20116',
'MVS16604','MVS11030',
'MVS22876','MVS10574',
'MVS14500','MVS11045',
'MVS19559','MVS13239',
'MVS21517','MVS12807',
'MVS12820','MVS10787',
'MVS14497','MVS15235',
'MVS17508','MVS13241',
'MVS14294','MVS11295',
'MVS13676','MVS20722',
'MVS15910','MVS16810',
'MVS17383','MVS12878',
'MVS16400','MVS10652',
'MVS18601','MVS12592','MVS12091',
'MVS10334','MVS18043',
'MVS10303','MVS21532',
'MVS11708','MVS12909',
'MVS17123','MVS22294',
'MVS10782','MVS17825',
'MVS10349','MVS13495',
'MVS18756','MVS19784',
'MVS10946','MVS12955',
'MVS16158','MVS17942',
'MVS15083','MVS10383',
'MVS17971','MVS12851',
'MVS13208','MVS15127',
'MVS16003','MVS19274',
'MVS21534','MVS10771',
'MVS14263','MVS12924',
'MVS20577','MVS10312',
'MVS10777','MVS14186',
'MVS11906','MVS13623',
'MVS21258','MVS14122',
'MVS12713','MVS21271',
'MVS13297','MVS14126',
'MVS22276','MVS17949',
'MVS10562','MVS10797',
'MVS13947','MVS17555',
'MVS13620','MVS17440',
'MVS10876','MVS11852','MVS19285',
'MVS18190','MVS14037',
'MVS10284','MVS17297',
'MVS10322','MVS14366',
'MVS12892','MVS11800',
'MVS11174','MVS18395',
'MVS12084','MVS20906',
'MVS10256','MVS13537',
'MVS13109','MVS17858',
'MVS13226','MVS16386',
'MVS11060','MVS10618',
'MVS16156','MVS12040',
'MVS13069','MVS21019',
'MVS19844','MVS17546',
'MVS20675','MVS11470',
'MVS15070','MVS22577',
'MVS13068','MVS11308',
'MVS12716','MVS12801',
'MVS17750','MVS10111',
'MVS16070','MVS20066',
'MVS10675','MVS21635',
'MVS15854','MVS14552',
'MVS12920','MVS13028',
'MVS17016','MVS14528',
'MVS12799','MVS11503',
'MVS13346','MVS13435',
'MVS16130','MVS11335',
'MVS14502','MVS12881',
'MVS10970','MVS12074',
'MVS11696','MVS20898',
'MVS10267','MVS16799',
'MVS12783','MVS12634',
'MVS12618','MVS13616',
'MVS18104','MVS15412',
'MVS17914','MVS11528',
'MVS18308','MVS16414',
'MVS14209','MVS15960',
'MVS16621','MVS15072',
'MVS20496','MVS17463',
'MVS11827','MVS19050',
'MVS14054','MVS20418',
'MVS10444','MVS11288',
'MVS16241','MVS16351',
'MVS12717','MVS19694',
'MVS11397','MVS13481',
'MVS14287','MVS17226',
'MVS12888','MVS13954',
'MVS21802','MVS13077',
'MVS16372','MVS14733',
'MVS10146','MVS21846','MVS11628',
'MVS11754','MVS22498',
'MVS18495','MVS14936',
'MVS15669','MVS17019', 'MVS12859','MVS12856','MVS13701','MVS21645','MVS18332',
'MVS10492','MVS22136',
'MVS16778','MVS11525',
'MVS21807','MVS20643',
'MVS11244','MVS19576',
'MVS14630' )
)
------
where remit_amount != '0'
group by drn; ----and week = '2025-10-06';



---Deep Dive > 3 remits----
---select distinct remit_amount from
select week, drn,product, vehicle_type, city,amount_due, effective_days,
ROUND(CEILING(NVL((amount_due/nullif(effective_days,0)),0.0))*6,-1) as remit_amount
from
(SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where drn = 'MVS14016' ---and week = '2023-08-07'
order by week;



SELECT ROUND(CEILING(2449.9900000000002),-2) AS CeilValue;


select * from 
core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa'

---- South Africa Solution - Getting the products each driver has been on from inception to date.
with recon_history as 
(
select week, drn,product, vehicle_type, city---,remit_amount
--count(distinct week)week_count, count(distinct product)product_count, count(distinct vehicle_type)vehicle_type_count, 
--count(distinct city)city_count, count(distinct remit_amount)
from (
---select distinct remit_amount from
select week, drn,product, vehicle_type, city, amount_due, effective_days
---ROUND(CEILING(NVL((amount_due/nullif(effective_days,0)),0.0))*6,-1) as remit_amount
from
(SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where drn in (
'MVS10846','MVS17937',
'MVS10501','MVS13401',
'MVS17947','MVS11086',
'MVS14598','MVS18305',
'MVS10517','MVS10484',
'MVS16187','MVS17787',
'MVS19032','MVS12866',
'MVS20044','MVS11349',
'MVS13168','MVS21959',
'MVS11110','MVS16472',
'MVS16655','MVS20077',
'MVS11535','MVS11278','MVS10877',
'MVS12917','MVS10390',
'MVS19738','MVS11964',
'MVS10329','MVS15541',
'MVS13714','MVS16555',
'MVS12912','MVS13423',
'MVS10367','MVS16439',
'MVS13210','MVS22798',
'MVS10814','MVS15773',
'MVS10089','MVS18571',
'MVS16644','MVS14352','MVS22808',
'MVS18157','MVS14346',
'MVS19658','MVS18064',
'MVS13273','MVS16433',
'MVS10527','MVS12672',
'MVS16710','MVS19627',
'MVS11782','MVS17197',
'MVS11970','MVS15233',
'MVS11563','MVS15798',
'MVS13860','MVS17868',
'MVS17039','MVS10992',
'MVS21888','MVS10401',
'MVS13443','MVS18935',
'MVS14134','MVS16640',
'MVS10601','MVS16642',
'MVS14865','MVS17772',
'MVS12654','MVS10433',
'MVS22472','MVS12030',
'MVS20134','MVS11187',
'MVS11531','MVS13674',
'MVS10968','MVS10236',
'MVS16233','MVS10692',
'MVS17806','MVS11466',
'MVS21092','MVS12021',
'MVS17050','MVS10461',
'MVS16001','MVS10998',
'MVS10982','MVS11229',
'MVS12648','MVS13056',
'MVS11956','MVS10414',
'MVS15351','MVS13647',
'MVS22105','MVS13132',
'MVS21370','MVS12626',
'MVS11406','MVS20713',
'MVS11055','MVS12023',
'MVS11061','MVS10308',
'MVS16915','MVS17390',
'MVS10288','MVS11129',
'MVS16125','MVS13320',
'MVS12623','MVS19847',
'MVS14680','MVS11046',
'MVS11240','MVS14157',
'MVS12828','MVS16744',
'MVS22452','MVS13170',
'MVS12644','MVS12772',
'MVS10458','MVS17816',
'MVS12039','MVS21729',
'MVS22037','MVS11343',
'MVS11291','MVS12028',
'MVS16136','MVS16558',
'MVS10287','MVS10363',
'MVS21829','MVS10626',
'MVS10314','MVS18181','MVS16113',
'MVS22771','MVS12141',
'MVS16784','MVS11957',
'MVS11402','MVS14056',
'MVS13088','MVS17107',
'MVS13891','MVS18405',
'MVS14514','MVS12533',
'MVS13222','MVS12053',
'MVS18027','MVS10860',
'MVS12889','MVS18586',
'MVS13094','MVS16743',
'MVS12781','MVS17917',
'MVS18350','MVS12552',
'MVS10986','MVS11842',
'MVS10553','MVS16060',
'MVS22694','MVS22802',
'MVS13425','MVS12702',
'MVS11252','MVS22752',
'MVS12786','MVS13638',
'MVS11175','MVS22001',
'MVS10257','MVS12649',
'MVS12935','MVS13277',
'MVS12947','MVS17742',
'MVS10528','MVS17422',
'MVS15647','MVS13065',
'MVS18992','MVS10833',
'MVS14205','MVS11487',
'MVS13022','MVS12848',
'MVS18021','MVS20076',
'MVS12003','MVS12853',
'MVS13609','MVS12661',
'MVS13072','MVS18141',
'MVS13001','MVS17918',
'MVS13195','MVS15604',
'MVS20463','MVS13188',
'MVS11005','MVS13287',
'MVS13283','MVS13769',
'MVS13147','MVS17845',
'MVS18339','MVS19757',
'MVS12622','MVS13047',
'MVS17132','MVS21372',
'MVS18329','MVS19527',
'MVS11642','MVS15379',
'MVS11526','MVS10222',
'MVS13856','MVS10620',
'MVS12522','MVS22967',
'MVS16826','MVS15429',
'MVS14016','MVS11823',
'MVS12047','MVS14596',
'MVS17570','MVS12685',
'MVS15342','MVS13200',
'MVS13236','MVS11093',
'MVS13383','MVS11207',
'MVS11159','MVS10597',
'MVS13197','MVS10839',
'MVS19768','MVS19769',
'MVS15886','MVS17452',
'MVS11063','MVS13153',
'MVS11766','MVS10912',
'MVS14737','MVS22283',
'MVS22448','MVS14218',
'MVS15486','MVS21022',
'MVS15043','MVS17681',
'MVS14004','MVS10491',
'MVS16686','MVS21792',
'MVS12565','MVS12144',
'MVS21840','MVS12753',
'MVS13602','MVS22129',
'MVS11266','MVS15887',
'MVS12763','MVS20279',
'MVS12653','MVS11576',
'MVS11092','MVS11476',
'MVS17616','MVS16648',
'MVS12910','MVS12918',
'MVS21161','MVS18779',
'MVS17368','MVS14686',
'MVS15983','MVS12555',
'MVS12164','MVS10200',
'MVS13903','MVS22835',
'MVS12819','MVS10091',
'MVS12617','MVS17709',
'MVS22725','MVS14010',
'MVS10623','MVS13515',
'MVS16803','MVS14432',
'MVS16506','MVS15925',
'MVS11630','MVS22957',
'MVS15188','MVS16287',
'MVS12852','MVS12145',
'MVS16469','MVS13344',
'MVS11024','MVS13125',
'MVS19219','MVS13804',
'MVS12568','MVS11314',
'MVS13312','MVS17951',
'MVS23000','MVS15401',
'MVS20263','MVS21995',
'MVS16327','MVS13285',
'MVS12556','MVS14556',
'MVS10299','MVS17534',
'MVS16467','MVS17700',
'MVS13422','MVS11130',
'MVS10985','MVS21774',
'MVS11974','MVS14592',
'MVS10033','MVS11116',
'MVS11747','MVS16216',
'MVS13246','MVS18449',
'MVS16145','MVS11289',
'MVS13762','MVS11374',
'MVS13252','MVS15143',
'MVS11416','MVS11899',
'MVS19280','MVS10698',
'MVS10166','MVS16763',
'MVS10130','MVS10271',
'MVS20622','MVS20754',
'MVS11220','MVS11545',
'MVS10884','MVS10957',
'MVS13911','MVS19564',
'MVS11774','MVS10355',
'MVS14677','MVS13858',
'MVS10538','MVS17598',
'MVS14076','MVS11384',
'MVS10581','MVS14770',
'MVS10533','MVS12110',
'MVS14297','MVS22961',
'MVS16418','MVS11626',
'MVS14180','MVS16009',
'MVS11755','MVS17403',
'MVS13430','MVS10318',
'MVS10481','MVS16282',
'MVS22853','MVS15025',
'MVS12788','MVS20703',
'MVS11460','MVS12134',
'MVS10480','MVS14985',
'MVS11909','MVS18001',
'MVS11371','MVS11432',
'MVS21303','MVS10532',
'MVS19923','MVS12886',
'MVS16798','MVS20116',
'MVS16604','MVS11030',
'MVS22876','MVS10574',
'MVS14500','MVS11045',
'MVS19559','MVS13239',
'MVS21517','MVS12807',
'MVS12820','MVS10787',
'MVS14497','MVS15235',
'MVS17508','MVS13241',
'MVS14294','MVS11295',
'MVS13676','MVS20722',
'MVS15910','MVS16810',
'MVS17383','MVS12878',
'MVS16400','MVS10652',
'MVS18601','MVS12592','MVS12091',
'MVS10334','MVS18043',
'MVS10303','MVS21532',
'MVS11708','MVS12909',
'MVS17123','MVS22294',
'MVS10782','MVS17825',
'MVS10349','MVS13495',
'MVS18756','MVS19784',
'MVS10946','MVS12955',
'MVS16158','MVS17942',
'MVS15083','MVS10383',
'MVS17971','MVS12851',
'MVS13208','MVS15127',
'MVS16003','MVS19274',
'MVS21534','MVS10771',
'MVS14263','MVS12924',
'MVS20577','MVS10312',
'MVS10777','MVS14186',
'MVS11906','MVS13623',
'MVS21258','MVS14122',
'MVS12713','MVS21271',
'MVS13297','MVS14126',
'MVS22276','MVS17949',
'MVS10562','MVS10797',
'MVS13947','MVS17555',
'MVS13620','MVS17440',
'MVS10876','MVS11852','MVS19285',
'MVS18190','MVS14037',
'MVS10284','MVS17297',
'MVS10322','MVS14366',
'MVS12892','MVS11800',
'MVS11174','MVS18395',
'MVS12084','MVS20906',
'MVS10256','MVS13537',
'MVS13109','MVS17858',
'MVS13226','MVS16386',
'MVS11060','MVS10618',
'MVS16156','MVS12040',
'MVS13069','MVS21019',
'MVS19844','MVS17546',
'MVS20675','MVS11470',
'MVS15070','MVS22577',
'MVS13068','MVS11308',
'MVS12716','MVS12801',
'MVS17750','MVS10111',
'MVS16070','MVS20066',
'MVS10675','MVS21635',
'MVS15854','MVS14552',
'MVS12920','MVS13028',
'MVS17016','MVS14528',
'MVS12799','MVS11503',
'MVS13346','MVS13435',
'MVS16130','MVS11335',
'MVS14502','MVS12881',
'MVS10970','MVS12074',
'MVS11696','MVS20898',
'MVS10267','MVS16799',
'MVS12783','MVS12634',
'MVS12618','MVS13616',
'MVS18104','MVS15412',
'MVS17914','MVS11528',
'MVS18308','MVS16414',
'MVS14209','MVS15960',
'MVS16621','MVS15072',
'MVS20496','MVS17463',
'MVS11827','MVS19050',
'MVS14054','MVS20418',
'MVS10444','MVS11288',
'MVS16241','MVS16351',
'MVS12717','MVS19694',
'MVS11397','MVS13481',
'MVS14287','MVS17226',
'MVS12888','MVS13954',
'MVS21802','MVS13077',
'MVS16372','MVS14733',
'MVS10146','MVS21846','MVS11628',
'MVS11754','MVS22498',
'MVS18495','MVS14936',
'MVS15669','MVS17019', 'MVS12859','MVS12856','MVS13701','MVS21645','MVS18332',
'MVS10492','MVS22136',
'MVS16778','MVS11525',
'MVS21807','MVS20643',
'MVS11244','MVS19576',
'MVS14630' 
) order by week)
where amount_due != '0' --group by drn
),
ordered_data AS (
    SELECT
        week,
        drn, product, vehicle_type, city, ---remit_amount,
        LAG(product)        OVER (PARTITION BY drn ORDER BY week) AS prev_product,
        LAG(vehicle_type)   OVER (PARTITION BY drn ORDER BY week) AS prev_product_type,
        ---LAG(remit_amount)  OVER (PARTITION BY drn ORDER BY week) AS prev_remit_amount,
        LAG(city)           OVER (PARTITION BY drn ORDER BY week) AS prev_city
    FROM recon_history
    order by week
)
SELECT
    drn, week,
    product,
    vehicle_type,
    --remit_amount,
    city,
    ROW_NUMBER() OVER (PARTITION BY drn ORDER BY week) AS all_change_order,
    ROW_NUMBER() OVER (PARTITION BY drn,product ORDER BY week) AS contract_change_order,
    ROW_NUMBER() OVER (PARTITION BY drn, vehicle_type ORDER BY week) AS product_change_order,
    CASE 
	    WHEN prev_product IS NULL THEN ''
	    WHEN product       IS DISTINCT FROM prev_product       THEN 'product_contract' END AS product_contract_changed,
    CASE 
	    WHEN prev_product_type IS NULL THEN ''
	    WHEN vehicle_type  IS DISTINCT FROM prev_product_type  THEN 'product_type' END AS product_type_changed,
    --CASE WHEN product_price IS DISTINCT FROM prev_product_price THEN 'product_price' END AS product_price_changed,
    CASE 
	    WHEN prev_city IS NULL THEN ''
	    WHEN city          IS DISTINCT FROM prev_city          THEN 'city' END AS city_changed
FROM ordered_data
WHERE
      product       is distinct from prev_product
   OR vehicle_type  is distinct from prev_product_type
   ---OR remit_amount <> prev_remit_amount
   OR city          is distinct from prev_city
   and drn = 'MVS12672'
order by drn, week;








select * from core_dimensions.mart_driver_weekly_recon where lower(country) = 'south africa' and recon_week = '2025-12-15' limit 10;




-----------------------------------------------------------
-------January 14, 2026---------

---===SA Historical Issues Checks====----

---Effective days < 0
select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days < 0;



----Effective days per week/drn > 6
select distinct week, drn, effective_days
from (select week, drn, sum(effective_days) as effective_days
      from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      group by week, drn)
where effective_days > 6;


----Deep Dives---
select * from tmp_loan_book.stg_fct_recon
      where country = 'South Africa'
      and week = '2023-05-15' and drn ='MVS11720';




select * from recon_south_africa.reconciliation
where drn = 'MVS14755' and week >= ''
order by week;

select * from tmp_loan_book.stg_fct_recon
where drn = 'MVS11720'
order by week;

select * from tmp_loan_book.stg_fct_recon
where drn = 'MVS14755' 
order by week;



select * from tmp_loan_book.stg_fct_recon
where drn in ('MVS14755',
'MVS13227',
'MVS15782',
'MVS11238',
'MVS15955',
'MVS15789',
'MVS14293',
'MVS13227',
'MVS14659')
order by drn, week;





select week, drn, adjustment_amount, adjustment_type, adjustment_description
from recon_ghana.reconciliation
where adjustment_amount <> 0
and adjustment_type = '';

select distinct adjustment_type from
recon_ghana.reconciliation;

select week, drn, adjustment_amount, adjustment_type, adjustment_description
from recon_ghana.reconciliation
where adjustment_type ilike '%additional services%';
--where drn = 'MVG11271' and day = '2025-07-19';







-------------------------------------------------------------
------January 19, 2025---------

----VERIFICATION----
-- Generate the most recent daily remittance charged per drn, excluding sundays and dates <2022
SELECT r.day, r.drn, r.remittance recon_remittance
	FROM recon_ghana.reconciliation r
	JOIN (
	    SELECT drn, MAX(day) AS latest_day
	    FROM recon_ghana.reconciliation r
	    where remittance > 0 and day >= '2023-01-01'
	    GROUP BY drn
	) latest
	ON r.drn = latest.drn AND r.day = latest.latest_day
	---where drn = 'MVG13280'
	ORDER BY drn;


select * from recon_ghana.products;


SELECT distinct r.vehicle_type,  r.remittance recon_remittance
	FROM recon_ghana.reconciliation r
	JOIN (
	    SELECT drn, vehicle_type, MAX(day) AS latest_day
	    FROM recon_ghana.reconciliation r
	    where remittance > 0 and day >= '2023-01-01'
	    GROUP BY drn
	) latest
	ON r.drn = latest.drn AND r.day = latest.latest_day
	ORDER BY vehicle_type;


select distinct drn, vehicle_type, remittance
FROM recon_ghana.reconciliation
where remittance > 0 
and drn = 'MVG13280';





-------------------------------------------------------------------
----Jan 20 2026----
----Ineffective Days Fields for SMR Use----

select * ---distinct drn, (NVL(sum(extra_charges),0) + NVL(SUM(passthrough_costs),0)) as input_extracharges_passthrough 
from reconciliation_data.recon_inputs__extra_charges
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly'
and partition_date = (
select max(partition_date) from reconciliation_data.recon_inputs__extra_charges 
where country_code = 'South Africa' and date between '2025-12-08' and '2025-12-14' and frequency = 'weekly');


select * from reconciliation_data.extra_charges limit 10;


select * from reconciliation_data.extra_charges
where country_code = 'SA' 
order by log_date desc limit 10;

select * from reconciliation_data.days_off 
order by log_date desc limit 10;


select * from reconciliation_data.recon_inputs__ineffective_days
limit 10;


select * from reconciliation_data.recon_inputs__extra_charges
limit 10;

recon.recon_input__driver_extra_charges - driver extra charges sourced from copilot
recon.recon_input__uber_payments_data - driver uber payments info
recon.recon_input__driver_ineffective_days - driver ineffective days info sourced from copilot

select * from recon.recon_input__driver_ineffective_days 
order by end_date desc limit 10;

select * from recon.recon_input__driver_extra_charges limit 10;
order by end_date desc limit 10;

drn, country, charge_type, charge_reason, status, charge_date, amount, description, charge_id




drn, start_date, end_date, request_status, country, reason_code






---------------------------------------------------------
-----Jan 21 2026--------

select * from tmp_loan_book.stg_fct_driver_payment limit 100;


select * from recon_ghana.extra_charge where drn = 'MVG12980';

select * from recon_ghana.extra_charge 
order by recon_ghana.extra_charge.reconciliation_date desc;


select * from recon_ghana.reconciliation


select * from core.driver_extra_charges limit 10;

where driver

select * from core.driver_extra_charges
where country_code = 'GHA';



----------------------------------
----Jan 27, 2026----
----Adjusting Dates for SA Missed Transactions----

select * from core_dimensions.mart_driver_weekly_recon
where drn = 'MVS20114' and recon_week >= '2026-01-12'
order by recon_week desc;

select * from reconciliation_data.recon_inputs__extra_charges 
where country_code = 'South Africa' and date between '2026-01-19' and '2026-01-25' and frequency = 'weekly'
and drn = 'MVS18087';

select * from recon.daily_recon_output
where drn = 'MVS23809' and recon_week >= '2026-01-12'
order by recon_week desc;

select distinct d.drn, start_date, max(end_date)end_date, status

select distinct d.drn, max(start_date) as contract_start_date, 
end_date as contract_end_date, status
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
--where drn = 'MVS17020'
where drn in (
'MVS22366',
'MVS17446',
'MVS22788',
'MVS22760',
'MVS22661',
'MVS12174',
'MVS22392',
'MVS23809',
'MVS23299',
'MVS11005',
'MVS22000',
'MVS22491',
'MVS11005',
'MVS23081',
'MVS20571',
'MVS22540',
'MVS21667',
'MVS22094',
'MVS13028',
'MVS17020',
'MVS19565',
'MVS18557',
'MVS19775',
'MVS18087',
'MVS10130',
'MVS11110',
'MVS15062',
'MVS19565',
'MVS18087',
'MVS20114',
'MVS20730',
'MVS22423'
)
group by drn,end_date,status
order by drn, end_date is not null, end_date desc;

select distinct d.drn, max(start_date) as contract_start_date, 
end_date as contract_end_date, status
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where drn = 'MVS17020'





select drn, dc.start_date, end_date
--max(end_date) as contract_end_date--, status
from core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
where drn = 'MVS17020'
order by end_date is not null, end_date desc;

select * from reconciliation_data.recon_inputs__adjustments 
where country_code = 'South Africa' and date between '2026-01-19' and '2026-01-25' and frequency = 'weekly'
and drn = 'MVS17020';




---Getting the latest contract details Per DRN---
select distinct drn, start_date as contract_start_date, 
end_date as contract_end_date, status from (
SELECT
    distinct d.drn, start_date, end_date, status,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY end_date is not null, end_date DESC
    ) AS rk
  FROM core_dimensions.dim_driver_contract dc
join core_dimensions.dim_driver d 
ON dc.driver_id = d.driver_id)
  WHERE rk = 1 and drn in (
'MVS22366',
'MVS17446',
'MVS22788',
'MVS22760',
'MVS22661',
'MVS12174',
'MVS22392',
'MVS23809',
'MVS23299',
'MVS11005',
'MVS22000',
'MVS22491',
'MVS11005',
'MVS23081',
'MVS20571',
'MVS22540',
'MVS21667',
'MVS22094',
'MVS13028',
'MVS17020',
'MVS19565',
'MVS18557',
'MVS19775',
'MVS18087',
'MVS10130',
'MVS11110',
'MVS15062',
'MVS19565',
'MVS18087',
'MVS20114',
'MVS20730',
'MVS22423'
) order by drn, start_date;


----Checking for Uber Earnings---
 (select distinct duuid,drn, sum(net_fare)net_earnings from recon.recon_input__uber_payments_data
where country = 'southafrica' and frequency = 'weekly' and source_file_date = '2026-01-19'
and duuid not in 
---Moove Fleet IDs
('943a1d1f-d1d4-4acd-b7f9-10b17344ab1f',
'64bed3ed-12a2-4eec-b5f2-f453202b3f33',
'945eaa40-b215-48d4-9e51-9fb10781e6a3',
'009c1303-82b5-4930-bdae-b6f2e6526a7e',
'686c4863-876a-4b7e-9a44-15c899ceafa7',
'd25a67d5-f772-4529-b78c-a4449240c8aa',
'f828fe43-fc6c-4cfe-aacb-1190a2e85b12',
'c8a568ab-1f4f-4c6a-8184-2dcdbc6820ba',
'16811eca-a0ac-45f2-9cba-f5a2df2b191d',
'a29a4936-53df-466f-900c-dfdc476cc3c8',
'feb26b3a-c134-41d0-9600-02a76f4aad11',
'44db17e2-f7c6-4259-b9da-528dd8cdbbe5',
'c6b0d226-8336-4b4b-bad1-5c1fff553ad7',
'8ef0ada4-f2df-4417-a3f8-669c7399846f',
'b8cc7e08-8a97-4b46-a631-485d211e111a',
'03bfa0f3-5cb0-4dce-b491-040659f67a1b',
'ae00c14d-c207-4378-8a11-aa9495d7b2c7',
'19c079b7-fe94-4066-9a4d-f5db237a5de8',
'0120e89a-fab5-4e59-9c56-44b51ca24166',
'63847379-edec-45e1-9094-f540854b72e6',
'ef4658ed-acf6-4c7a-a379-7fa2cf0138ed',
'7f0eee71-d1d6-4bd1-ab74-435a12911f62',
'848330a9-7852-4aef-9729-43ac3b2b6cc7',
'bbe787cd-f70b-407d-afe9-4fbe57a13bce',
'0bc556a9-c75e-4590-af18-e8025790a1d0',
'e260de13-1cde-439d-b6ea-cae0e552be6b',
'428c7180-b0a5-4b0d-9d6e-af9e15a5ff16',
'035f9c4f-becf-41b1-846e-becae97541e4',
'cab123a4-c3e0-490f-85f0-d3eeec1c2e91',
'4cec0c4d-1182-494a-b508-23989b190c57',
'50f6d72b-e3bb-4263-9a52-6678e1d8f988',
'85c889eb-34c4-4939-9081-63342034b76a',
'4d10a11f-45cd-409c-bf46-bfc1b5274ca6',
'3e26ade0-c5aa-48f0-8a54-8298ccd64bc9',
'841ef0cc-21b0-4227-b7a3-a8a877ab028c',
'00000000-0000-0000-0000-000000000000')
----Considering only active contract---
--and drn in 
--(select distinct d.drn
--from core_dimensions.dim_driver_contract dc
--join core_dimensions.dim_driver d ON dc.driver_id = d.driver_id
--where status = 'ACTIVE' )
and drn is not null
group by duuid,drn  order by drn);








---------------------------------------------------------
----Jan 28 2026-----
---Investigating India's Product---

IN-IN01-BOM-052

select * from recon_india.products;


select * from core_dimensions.stg_recon_legacy_union_raw limit 100;





---------------------------------------------------------------------------
---Jan 29, 2026----
---Ghana Historical Checks---
select * from "dev"."dbt_vitalii"."tr_ghana__negative_remittance";
select * from "dev"."dbt_vitalii"."tr_ghana__effective_days_gt_seven";
select * from "dev"."dbt_vitalii"."tr_ghana__duplicate_drn_day";
select * from "dev"."dbt_vitalii"."tr_ghana__cumm_outstanding_calc";
select * from "dev"."dbt_vitalii"."tr_ghana__all_metrics_zero";



---------------------------------------------------------------------------
---Jan 29, 2026----
---India Product Checks---
select * from recon_india.products;


select distinct vehicle_type from recon_india.daily_reconciliation
where lower(city) = 'mumbai';

select distinct week, sum(remittance)remittance from recon_india.daily_reconciliation
where vehicle_type = 'BOM - SPresso II 2025 (rele.)' 
group by week
order by week asc;

select distinct week, drn, sum(remittance)remittance from recon_india.daily_reconciliation
where vehicle_type = 'BOM - SPresso II' 
group by week, drn
order by week asc limit 1000;



-----------------------------------------------------------------
----Select 
select * from recon_ghana.reconciliation
where drn = 'MVG10107' and week = '2021-08-02';

reconciliation_history.drivers_data_reconciliation_accra

select * from 
reconciliation_history.drivers_data_reconciliation_accra_03_21_03_22
where drn = 'MVG10563' and week between '2022-04-18' and '2022-04-25';

select * from core_dimensions.stg_recon_legacy_union_raw
where drn = 'MVG10563' and week = '2022-04-25';

select * from 
reconciliation_history.drivers_data_reconciliation_accra
where drn = 'MVG10563' and week between '2022-04-18' and '2022-04-25';


select * from 
reconciliation_history.drivers_data_reconciliation_accra
where drn = 'MVG11462' and week between '2023-01-30' and '2023-02-06';


select * from 
reconciliation_history.drivers_data_reconciliation_accra
where drn = 'MVG10549' and week between '2022-08-01' and '2022-08-08';

select * from 
core_dimensions.stg_recon_legacy_union_raw
where drn = 'MVG10549' and week between '2022-08-01' and '2022-08-08';

select * from 
reconciliation_history.drivers_data_reconciliation_accra
where drn = 'MVG10599' and week between '2023-02-27' and '2023-03-06';

select * from recon_ghana.reconciliation
where drn = 'MVG10599' and week between '2023-02-27' and '2023-03-06';



