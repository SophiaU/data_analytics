---FINAL SCRIPT---
--Using Uber Harmonised---

with recon as (
select *
from recon.recon_output__weekly_summary t
where drn in ('MVCO01272', 'MVCO00144', 'MVCO00172', 'MVCO00978')
order by t.week_date desc
),
uber_api as (
select 	driveruuid,
		driverfirstname,
		driverlastname,
 		recon_week,
 		sum(trips) as trips,
 		sum(cash) as cash,
 		sum(uber_net_of_fees) as uber_net_of_fees,
 		sum(uber_balance ) as uber_balance
from (select 	driveruuid,
				driverfirstname,
				driverlastname,
				source_file_date,
				date_trunc('week', source_file_date)::date AS recon_week,
				count(distinct tripuuid) as trips,
				sum(paidtoyou__tripbalance__payouts__cashcollected) as cash,
				sum(paidtoyou) as uber_balance,
				(sum(paidtoyou) + sum(-paidtoyou__tripbalance__payouts__cashcollected)) as uber_net_of_fees
from partners_data_weekly.mv_uber_harmonized_payments_order
--where description ilike '%trip completed%'
group by 1,2,3,4,5
order by source_file_date asc)
where driveruuid in ('8b93baeb-4204-4c2f-83c6-fd418f58c55c', '20f9aa06-2edd-422c-a0a4-78a5dedef646', 'e555065b-5e2d-4a81-8ed3-34ad515d099a')
group by all
order by recon_week  desc
)
select 	r.drn,
		a.driveruuid,
		a.recon_week, sum(r.uber_net_of_fees) recon_netearnings, sum(a.uber_net_of_fees)uber_netearnings,
		sum(r.uber_net_of_fees - a.uber_net_of_fees) as delta_earnings,
		sum(r.trips - a.trips) as delta_trips
from recon r right join uber_api a
on r.uber_id = a.driveruuid and r.week_date = a.recon_week
group by all
order by a.recon_week desc;




---FIRST DRAFT----
with recon as (
select *
from core_dimensions.mart_driver_weekly_recon t
where drn in ('MVCO01272', 'MVCO00144', 'MVCO00172', 'MVCO00978')
and status = 'PUBLISHED'
order by t.recon_week desc
),
uber_data as (
select
    duuid, drn,
    sum(net_fare) as net_earnings,
    date_trunc('week', date::date)::date as recon_week
from ( select * from 
	(select *,
        max(case when frequency = 'weekly' then partition_date end)
            over (partition by date) as max_weekly_partition_date
    from reconciliation_data.recon_inputs__uber_payments
    where country_code = 'Colombia' --and date >= '2026-01-26' 
    )
where --drn = 'MVCO01272' and
  partition_date = max_weekly_partition_date
order by date)
group by duuid, drn, date_trunc('week', date::date)::date
)
select 	r.drn,
		a.duuid,
		a.recon_week, sum(r.net_earnings) as recon_net_earnings, sum(a.net_earnings) as uber_net_earnings,
		sum(r.net_earnings - a.net_earnings) as delta_earnings
from recon r join uber_data a
on r.uber_id = a.duuid and r.recon_week = a.recon_week
group by 1,2,3
order by a.recon_week desc;


--UBER SOURCE--
select 
    duuid, drn, date, net_fare, receivable_trans_svc_net_of_fees
from ---reconciliation_data.recon_inputs__uber_payments
( select *,
        --max(case when frequency = 'weekly' then partition_date end)
        max(partition_date)
            over (partition by drn) as max_weekly_partition_date
    from reconciliation_data.recon_inputs__uber_payments
    where frequency = 'weekly' and country_code = 'Colombia' and date >= '2026-01-26' )
where drn = 'MVCO01272'
  and partition_date = max_weekly_partition_date
order by date;



---RECON SOURCE
select drn, uber_id, recon_week, uber_payments_net_fare, uber_payments_partner_balance
from core_dimensions.fact_recon_daily ---mart_driver_weekly_recon 
where drn = 'MVCO01272' and recon_week = '2026-01-26'
order by recon_week desc;


