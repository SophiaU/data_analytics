--------------------------------------------------------------------------
------DATE LEVEL------
------THE QUERY----Base Table vs Simplified Recon Table Comparison---
with driver_list as (
select drn, country, uber_id, DATE(week)week, DATE(day)as day, license_plate_moove, plan_code, first_assignment_date, churn_date
from latam_recon.daily_recon_consolidated_output --where week >= '2025-06-02'
), 
----AUTO RECON----
main_recon_output AS (
  SELECT
    country, drn, uber_id, week, day, license_plate_moove,
    SUM(gross_fare) AS gross_fare,
    SUM(dynamic_pricing_discount) AS dynamic,
    SUM(moove_subsidies) AS moove_subsidies,
    SUM(days_off) AS days_off,
    SUM(days_off_vehicle_status) AS status_days_off,
    SUM(extra_charges) AS extra_charges,
    SUM(passthrough_costs) AS passthrough_costs,
    SUM(adjustment_amount) AS adjustments,
    SUM(payins) AS payins,
    SUM(payouts) AS payouts,
    SUM(driver_remit_for_the_period::float) AS driver_remit_for_the_period,
    SUM(driver_opening_balance::float) as driver_opening_balance,
    SUM(driver_balance_for_the_period::float) as driver_balance_for_the_period,
    SUM(driver_closing_balance::float) as driver_closing_balance
  FROM latam_recon.daily_recon_consolidated_output 
  ---WHERE week = '2025-06-16' ----AND lower(country) = 'colombia'
  GROUP BY country, drn, uber_id, week, day, license_plate_moove),
simplified_Recon AS (
  SELECT
    country, drn, uber_id, week, day, registration_no,
    SUM(JSON_EXTRACT_PATH_TEXT(net_earnings_post_partner_adjustments_breakdown, 'gross_fare')::float) as gross_fare,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')) as dynamic_pricing_discount,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'onboarding_discount')::float) as moove_subsidies,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'driver_days_off')) as driver_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'vehicle_days_off')) as vehicle_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'extra_charges')::float) as extra_charges,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'passthrough_costs')::float) as passthrough_costs,
    SUM(adjustments) AS adjustments,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float) as payouts,
    SUM(driver_remit_for_the_period::float) AS driver_remit_for_the_period,
    SUM(driver_opening_balance::float) as driver_opening_balance,
    SUM(driver_balance_for_the_period::float) as driver_balance_for_the_period,
    SUM(driver_closing_balance::float) as driver_closing_balance
    FROM recon.daily_recon_output   ---recon.raw_daily_recon_output ---WHERE week >= '2025-06-02'
  -------AND lower(country) = 'colombia'
  GROUP BY country, drn, uber_id, week, day, registration_no ),
output as (
select ---dl.drn, dl.uber_id, dl.license_plate_moove, dl.plan_code, dl.first_assignment_date, dl.churn_date,
dl.country, dl.week, dl.day, 
  -- Gross Fare
  NVL(m.gross_fare::float, 0.0) as gross_fare,
  NVL(sr.gross_fare::float,0.0) as simplified_gross_fare,
  (NVL(m.gross_fare::float,0.0) - NVL(sr.gross_fare::float,0.0)) AS diff_gross_fare,
  -- Dynamic Discount
  NVL(m.dynamic::float,0.0) as dynamic,
  NVL(sr.dynamic_pricing_discount::float,0.0) as simp_dynamic_pricing_discount,
  (NVL(m.dynamic::float,0.0) - NVL(sr.dynamic_pricing_discount::float, 0.0)) AS diff_dynamic,
  -- Moove Subsidies
  NVL(m.moove_subsidies::float,0.0) as moove_subsidies,
  NVL(sr.moove_subsidies::float,0.0) as simp_moove_subsidies,
  (NVL(m.moove_subsidies::float,0.0) - NVL(sr.moove_subsidies::float,0.0)) AS diff_moove_subsidies,
  -- Driver Days Off
  NVL(m.days_off::float,0.0) as days_off,
  NVL(sr.driver_days_off::float,0.0) as simp_driver_days_off,
  (NVL(m.days_off::float,0.0) - NVL(sr.driver_days_off::float,0.0)) AS diff_days_off,
  -- Vehicle Status Days Off
  NVL(m.status_days_off::float,0.0) as status_days_off,
  NVL(sr.vehicle_days_off::float,0.0) as simp_vehicle_days_off,
  (NVL(m.status_days_off::float,0.0) - NVL(sr.vehicle_days_off::float,0.0)) AS diff_status_days_off,
  -- Extra Charges
  NVL(m.extra_charges::float,0.0) as extra_charges,
  NVL(sr.extra_charges::float,0.0) as simp_extra_charges,
  NVL((m.extra_charges - sr.extra_charges)::float,0.0) AS diff_extra_charges,
  -- Passthrough Costs
  NVL(m.passthrough_costs::float,0.0) as passthrough_costs,
  NVL(sr.passthrough_costs ::float,0.0) as simp_passthrough_costs,
  (NVL(m.passthrough_costs::float,0.0) - NVL(sr.passthrough_costs::float,0.0)) AS diff_passthrough_costs,
  -- Adjustments
  NVL(m.adjustments::float,0.0) as adjustments,
  NVL(sr.adjustments::float,0.0) as simp_adjustments,
  (NVL(m.adjustments::float,0.0) - NVL(sr.adjustments::float,0.0)) AS diff_adjustments,
  -- Payins
  NVL(m.payins::float,0.0) as payins,
  NVL(sr.payins::float,0.0) as simp_payins,
  (NVL(m.payins::float,0.0) - NVL(sr.payins::float,0.0)) AS diff_payins,
  -- Payouts
  NVL(m.payouts::float,0.0) as payouts,
  NVL(sr.payouts::float,0.0) as simp_payouts,
  (NVL(m.payouts::float,0.0) - NVL(sr.payouts::float,0.0)) AS diff_payouts,
  ---Balances
  NVL(m.driver_remit_for_the_period::float,0.0) as driver_remit_for_the_period,
  NVL(sr.driver_remit_for_the_period::float,0.0) as simp_driver_remit_for_the_period,
  (NVL(m.driver_remit_for_the_period::float,0.0) - NVL(sr.driver_remit_for_the_period::float,0.0)) as diff_driver_remit_for_the_period,
  NVL(m.driver_opening_balance::float,0.0) as driver_opening_balance,
  NVL(sr.driver_opening_balance::float,0.0) as simp_driver_opening_balance,
  (NVL(m.driver_opening_balance::float,0.0) - NVL(sr.driver_opening_balance::float,0.0)) as diff_driver_opening_balance,
  NVL(m.driver_balance_for_the_period::float,0.0) as driver_balance_for_the_period,
  NVL(sr.driver_balance_for_the_period::float,0.0) as simp_driver_balance_for_the_period,
  (NVL(m.driver_balance_for_the_period::float,0.0) - NVL(sr.driver_balance_for_the_period::float,0.0)) as diff_driver_balance_for_the_period,
  NVL(m.driver_closing_balance::float,0.0) as driver_closing_balance,
  NVL(sr.driver_closing_balance::float,0.0) as simp_driver_closing_balance,
  (NVL(m.driver_closing_balance::float,0.0) - NVL(sr.driver_closing_balance::float,0.0)) as diff_driver_closing_balance
FROM driver_list dl
left join main_recon_output m on dl.drn = m.drn and DATE(dl.day) = DATE(m.day)
LEFT JOIN simplified_Recon sr on dl.drn = sr.drn and DATE(dl.day) = DATE(sr.day)
)
select distinct week, day, country, sum(gross_fare)gross_fare, sum(simplified_gross_fare)simplified_gross_fare, sum(diff_gross_fare)diff_gross_fare,
sum(dynamic)dynamic, sum(simp_dynamic_pricing_discount)simp_dynamic_pricing_discount, sum(diff_dynamic) diff_dynamic, 
sum(moove_subsidies)moove_subsidies, sum(simp_moove_subsidies)simp_moove_subsidies, sum(diff_moove_subsidies)diff_moove_subsidies,
sum(days_off)days_off, sum(simp_driver_days_off)simp_driver_days_off, sum(diff_days_off)diff_days_off,
sum(status_days_off)status_days_off, sum(simp_vehicle_days_off)simp_vehicle_days_off, sum(diff_status_days_off)diff_status_days_off, 
sum(extra_charges)extra_charges, sum(simp_extra_charges)simp_extra_charges, sum(diff_extra_charges)diff_extra_charges, 
sum(passthrough_costs)passthrough_costs, sum(simp_passthrough_costs)simp_passthrough_costs, sum(diff_passthrough_costs)diff_passthrough_costs, 
sum(adjustments)adjustments, sum(simp_adjustments)simp_adjustments, sum(diff_adjustments)diff_adjustments, 
sum(payins)payins, sum(simp_payins)simp_payins, sum(diff_payins)diff_payins, 
sum(payouts)payouts, sum(simp_payouts)simp_payouts, sum(diff_payouts)diff_payouts, 
sum(driver_remit_for_the_period::float)driver_remit_for_the_period, sum(simp_driver_remit_for_the_period::float)simp_driver_remit_for_the_period, sum(diff_driver_remit_for_the_period::float)diff_driver_remit_for_the_period, 
sum(driver_opening_balance::float)driver_opening_balance, sum(simp_driver_opening_balance::float)simp_driver_opening_balance, sum(diff_driver_opening_balance::float)diff_driver_opening_balance, 
sum(driver_balance_for_the_period::float)driver_balance_for_the_period, sum(simp_driver_balance_for_the_period::float)simp_driver_balance_for_the_period, sum(diff_driver_balance_for_the_period::float)diff_driver_balance_for_the_period, 
sum(driver_closing_balance::float)driver_closing_balance, sum(simp_driver_closing_balance ::float)simp_driver_closing_balance, sum(diff_driver_closing_balance::float)diff_driver_closing_balance
from output ---where lower(country) = 'colombia' 
group by week, day, country
order by week,day asc; 










------DRIVER LEVEL------
------THE QUERY----Base Table vs Simplified Recon Table Comparison---
with driver_list as (
select drn, country, uber_id, DATE(week)week, DATE(day)as day, license_plate_moove, plan_code, first_assignment_date, churn_date
from latam_recon.daily_recon_consolidated_output  where week = '2025-06-16'
),
----AUTO RECON----
main_recon_output AS (
  SELECT
    country, drn, uber_id, week, day, license_plate_moove,
    SUM(gross_fare) AS gross_fare,
    SUM(dynamic_pricing_discount) AS dynamic,
    SUM(moove_subsidies) AS moove_subsidies,
    SUM(days_off) AS days_off,
    SUM(days_off_vehicle_status) AS status_days_off,
    SUM(extra_charges) AS extra_charges,
    SUM(passthrough_costs) AS passthrough_costs,
    SUM(adjustment_amount) AS adjustments,
    SUM(payins) AS payins,
    SUM(payouts) AS payouts,
    SUM(driver_remit_for_the_period) AS driver_remit_for_the_period,
    SUM(driver_opening_balance) as driver_opening_balance,
    SUM(driver_balance_for_the_period) as driver_balance_for_the_period,
    SUM(driver_closing_balance) as driver_closing_balance
  FROM latam_recon.daily_recon_consolidated_output
  WHERE week = '2025-06-16' ----AND lower(country) = 'colombia'
  GROUP BY country, drn, uber_id, week, day, license_plate_moove),
simplified_Recon AS (
  SELECT
    country, drn, uber_id, week, day, registration_no,
    SUM(JSON_EXTRACT_PATH_TEXT(net_earnings_post_partner_adjustments_breakdown, 'gross_fare')::float) as gross_fare,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')) as dynamic_pricing_discount,
    SUM(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'onboarding_discount')) as moove_subsidies,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'driver_days_off')) as driver_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'vehicle_days_off')) as vehicle_days_off,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'extra_charges')::float) as extra_charges,
    SUM(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'passthrough_costs')::float) as passthrough_costs,
    SUM(adjustments) AS adjustments,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins,
    SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float) as payouts,
    SUM(driver_remit_for_the_period) AS driver_remit_for_the_period,
    SUM(driver_opening_balance) as driver_opening_balance,
    SUM(driver_balance_for_the_period) as driver_balance_for_the_period,
    SUM(driver_closing_balance) as driver_closing_balance
    FROM recon.raw_daily_recon_output
  WHERE week = '2025-06-16' ----AND lower(country) = 'colombia'
  GROUP BY country, drn, uber_id, week, day, registration_no ),
output as (
select dl.drn, dl.country, dl.uber_id, dl.week, dl.day, dl.license_plate_moove, dl.plan_code, dl.first_assignment_date, dl.churn_date,
  -- Gross Fare
  m.gross_fare as hist_gross_fare,
  sr.gross_fare,
  m.gross_fare - sr.gross_fare AS diff_gross_fare,
  -- Dynamic Discount
  m.dynamic,
  sr.dynamic_pricing_discount,
  m.dynamic - sr.dynamic_pricing_discount AS diff_dynamic,
  -- Driver Days Off
  m.days_off,
  sr.driver_days_off,
  m.days_off - sr.driver_days_off AS diff_days_off,
  -- Vehicle Status Days Off
  m.status_days_off,
  sr.vehicle_days_off,
  m.status_days_off - sr.vehicle_days_off AS diff_status_days_off,
  -- Extra Charges
  m.extra_charges,
  sr.extra_charges,
  m.extra_charges - sr.extra_charges AS diff_extra_charges,
  -- Passthrough Costs
  m.passthrough_costs,
  sr.passthrough_costs,
  m.passthrough_costs - sr.passthrough_costs AS diff_passthrough_costs,
  -- Adjustments
  m.adjustments,
  sr.adjustments,
  m.adjustments - sr.adjustments AS diff_adjustments,
  -- Payins
  m.payins,
  sr.payins,
  m.payins - sr.payins AS diff_payins,
  -- Payouts
  m.payouts,
  sr.payouts,
  m.payouts - sr.payouts AS diff_payouts,
  ---Balances
  m.driver_remit_for_the_period,
  sr.driver_remit_for_the_period,
  m.driver_remit_for_the_period - sr.driver_remit_for_the_period as diff_driver_remit_for_the_period,
  m.driver_opening_balance,
  sr.driver_opening_balance,
  m.driver_opening_balance - sr.driver_opening_balance as diff_driver_opening_balance,
  m.driver_balance_for_the_period,
  sr.driver_balance_for_the_period,
  m.driver_balance_for_the_period - sr.driver_balance_for_the_period as diff_driver_balance_for_the_period,
  m.driver_closing_balance,
  sr.driver_closing_balance,
  m.driver_closing_balance - sr.driver_closing_balance as diff_driver_closing_balance
FROM driver_list dl
left join main_recon_output m on dl.drn = m.drn and DATE(dl.day) = DATE(m.day)
LEFT JOIN simplified_Recon sr on dl.drn = sr.drn and DATE(dl.day) = DATE(sr.day)
)
select * from output ---where lower(country) = 'colombia'
order by day asc; ---drn = 'MVCO00084';


