---H2 2025 DATA REQUESTS AND ANALYSIS---------

----------------------------------------------------------------------------------------------------------------------
------July 28, 2025--------
----Just returned from exam leave.


select * from recon.daily_recon_output dro 
WHERE drn IS null
order by week DESC; 




----------------------------------------------------------------
----Answering Ahmed's questions
---Jul 29, 2025---

select * from reconciliation_proxy_current.riders_data_reconciliation_uberconnect_lagos;

select distinct day from 
reconciliation_history.drivers_data_reconciliation_ubergo_lagos
order by day;

select * from reconciliation_history.drivers_data_reconciliation_ubergo_lagos order by day;

select * from recon_nigeria.reconciliation_spresso
where week = '2024-06-17' and drn = 'DRN002981';



---Recon for LatAm----
---Jul 29, 2025---

recon.daily_recon_output
recon.raw_daily_recon_output

select * from recon.daily_recon_output
where lower(country) = 'colombia'
order by week desc;


select * from recon.raw_daily_recon_output
where week is null
order by week desc;



WITH total_extra_charges AS (
   -- Calculating total/full/listed extra charges per driver
   SELECT
       drn,
       SUM(total_amount) AS total_extra_charges
   FROM recon_nigeria.extra_charge
   GROUP BY drn
), charged_extra_charges AS (
   -- Calculating total extra charges charged per driver on recon
   SELECT
       drn,
       SUM(extra_charges) AS charged_extra_charges
   FROM reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
   WHERE extra_charges > 0
   GROUP BY drn
), last_worked AS (
   -- Geting the last worked (most recent appearance) per driver
   SELECT
       drn,
       MAX(day) AS last_worked_date
   FROM reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
   GROUP BY drn
), last_charged AS (
   -- Geting the last  charged date (most recent extra charge > 0) per driver
   SELECT
       drn,
       MAX(day) AS last_charged_date
   FROM reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
   WHERE extra_charges > 0
   GROUP BY drn
)
-- Main CTE joining & filtering the data
SELECT
   t.drn,
   t.total_extra_charges,
   c.charged_extra_charges as recon_charged_extra_charges,
   (t.total_extra_charges > c.charged_extra_charges) AS charges_comparison,
   lw.last_worked_date,
   lc.last_charged_date,
   lw.last_worked_date - lc.last_charged_date as days_not_charged
FROM total_extra_charges t
LEFT JOIN charged_extra_charges c ON t.drn = c.drn
LEFT JOIN last_worked lw ON t.drn = lw.drn
LEFT JOIN last_charged lc ON t.drn = lc.drn
WHERE
   (t.total_extra_charges > c.charged_extra_charges) -- Extra charges > charged extra charges
   AND lw.last_worked_date >= '2025-07-07' -- Driver must have worked on or after the start date
   AND NOT EXISTS (
       -- Picking only records where no charges have been applied in the last 2 weeks
       SELECT 1
       FROM reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
       WHERE drn = t.drn
       AND extra_charges > 0
       --AND day >= '2025-07-07' -- The provided start date
       and drn = 'DRN002981'
   )
ORDER BY lw.last_worked_date desc;


----------------
select * from recon_nigeria.extra_charge
where drn = 'DRN002981';

-- Calculating total extra charges charged per driver on recon
   SELECT
       drn,
       SUM(extra_charges) AS charged_extra_charges
   FROM reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout
   WHERE extra_charges > 0 and drn = 'DRN002981'
   GROUP BY drn;

  
  
  select * from recon_nigeria.reconciliation_spresso
where week between '2024-06-10' and '2024-06-24' and extra_charges > 0;   ---drn = 'DRN002981'



select * from recon_nigeria.reconciliation_spresso
where week >= '2025-07-07' and extra_charges > 0;



--------------------------------------
------THE EXTRA CHARGES VALIDATION ANALYSIS------
---JULY 29, 2025----
with base as(
select week, day, drn,moove_balance, remittance, extra_charges, adjustment_amount, prev_outstanding, NVL(amount_due,0.0) as amount_due, 
NVL(outstanding,0.0) as outstanding
from recon_nigeria.reconciliation_spresso
where extra_charges > 0
order by day),
simulation as(
select week, day, drn, (NVL(remittance+extra_charges+ prev_outstanding+ adjustment_amount,0.0)) as check_amount_due,
NVL(((remittance+extra_charges+ adjustment_amount) - moove_balance),0.0) as check_outstanding
from base
),
combo as (select b.week, b.day, b.drn,moove_balance, b.remittance, b.extra_charges, b.adjustment_amount, b.prev_outstanding, b.amount_due, b.outstanding, 
s.check_amount_due , s.check_outstanding  
from base b
left join simulation s
on b.drn = s.drn and b.day = s.day )
select *, 
case 
	when (NVL(amount_due,0.0) - NVL(check_amount_due,0.0)) = 0 then true
	when (NVL(outstanding,0.0) - NVL(check_outstanding,0.0)) = 0 then true
	else false
end as validation
from combo
order by day;



----------------
select week, day, drn, extra_charges
from recon_nigeria.reconciliation_spresso
where extra_charges > 0 and drn = 'DRN008658'
order by day asc;

-----------------
select distinct day from reconciliation_history.aggregated_ubergo_reconciliation
order by day asc;

select * from reconciliation_history.aggregated_ubergo_reconciliation
order by day asc;


------------------------------------------------------------------
-----July 30, 2025----

---Latam Recon checks---

---Rental Uber API----
---Daily---
SELECT t.*
FROM persistence_uber_api_reports_weekly.rental_payments_transaction t
LIMIT 501;


---Weekly---
SELECT t.*
FROM persistence_uber_api_reports_daily.rental_payments_transaction t
LIMIT 501;

select * from recon.daily_recon_output
where lower(country) = 'colombia'
order by week desc


----------------------------------------------------

Views were moving under dbt.latam_recon now:
dbt.latam_recon__driver_ineffective_days
dbt.latam_recon__driver_extra_charges


select * from recon.daily_recon_output
where lower(country) = 'colombia'
order by recon_week desc;



select * from recon.raw_daily_recon_output
where lower(country) = 'colombia'
order by recon_week desc limit 100;



------THE EXTRA CHARGES VALIDATION ANALYSIS------
---JULY 30, 2025----
with base as(
select week, day, drn,moove_balance, remittance, extra_charges, adjustment_amount, prev_outstanding, NVL(amount_due,0.0) as amount_due, 
NVL(outstanding,0.0) as outstanding
from recon_nigeria.reconciliation_alto
where extra_charges > 0
order by day),
simulation as(
select week, day, drn, (NVL(remittance+extra_charges+ prev_outstanding+ adjustment_amount,0.0)) as check_amount_due,
NVL(((remittance+extra_charges+ adjustment_amount) - moove_balance),0.0) as check_outstanding
from base
),
combo as (select b.week, b.day, b.drn,moove_balance, b.remittance, b.extra_charges, b.adjustment_amount, b.prev_outstanding, b.amount_due, b.outstanding, 
s.check_amount_due , s.check_outstanding  
from base b
left join simulation s
on b.drn = s.drn and b.day = s.day )
select *, 
case 
	when (NVL(amount_due,0.0) - NVL(check_amount_due,0.0)) = 0 then true
	when (NVL(outstanding,0.0) - NVL(check_outstanding,0.0)) = 0 then true
	else false
end as validation
from combo
order by day;




select * from recon.recon_output__weekly_summary
--where lower(country) = 'colombia'
order by week desc limit 100;



----Getting the Vehicle Assignment Records for Spresso Drivers with Unapplied Extra Charges----
-------Most recent vehicle assignment
WITH assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
select drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from assignments
where rn = 1 and drn IN ('DRN015645',
'DRN008658',
'DRN011919',
'DRN001144',
'DRN013798',
'DRN015091',
'DRN015441',
'DRN015206',
'DRN012062',
'DRN012460',
'DRN015226',
'DRN015742',
'DRN011838',
'DRN015596',
'DRN014613',
'DRN013997',
'DRN002981',
'DRN014750',
'DRN015640',
'DRN015253',
'DRN013663',
'DRN015644',
'DRN010817',
'DRN017154',
'DRN014193',
'DRN015619',
'DRN016389',
'DRN016404',
'DRN016125',
'DRN015883',
'DRN016476',
'DRN017042',
'DRN011268',
'DRN014475',
'DRN016326',
'DRN011932');


select * from recon_nigeria.reconciliation_spresso rs 
where drn = 'DRN011156'
order by day asc;





----Mexico Recon Checks------
--CHECK 7: Trips & No Earnings----
with output as (
select drn, week, sum(trips)as week_trips, sum(net_earnings_post_partner_adjustments)as week_earnings 
from recon.daily_recon_output --where week = (CURRENT_DATE - INTERVAL '7 days' - INTERVAL '1 day' * ((EXTRACT(DOW FROM CURRENT_DATE)::int + 6) % 7)) ---get the Monday date of last week.
group by drn, week
),
trips_no_earnings_check as (select drn, week, week_trips, week_earnings,
    case 
    when week_trips > 0 and week_earnings <= 0 THEN 'fail'
      else 'ok'
      end as trips_no_earnings_check
from output
order by drn, week asc)
select * from trips_no_earnings_check where trips_no_earnings_check = 'fail';


select * from recon.daily_recon_output
where recon_week = '2025-06-16' and drn = 'MVMX00009';




----------------------------------
---AUGUST 01, 2025----

SELECT * FROM recon.recon_output__weekly_summary limit 100;


select * from recon.daily_recon_output limit 100;





-- recon.recon_output__weekly_summary source

-----CURRENT VIEW-------
create view recon.recon_output__weekly_summary as (

	with first_day_week_drn as (
		select drn, cast(recon_week as date) as week_date, min(cast(day as date)) as first_day
		from recon.daily_recon_output group by drn, week_date
	),

	driver_opening_balances as (
		select cast(recon_week as date) as week_date, recon.daily_recon_output.drn, driver_opening_balance
		from recon.daily_recon_output join first_day_week_drn
		on first_day_week_drn.first_day = cast(recon.daily_recon_output.day as date)
		and first_day_week_drn.drn = recon.daily_recon_output.drn
	),

	last_day_week_drn as (
		select drn, cast(recon_week as date) as week_date, max(cast(day as date)) as last_day
		from recon.daily_recon_output group by drn, week_date
	),

	driver_closing_balances as (
		select cast(recon_week as date) as week_date, recon.daily_recon_output.drn, driver_closing_balance
		from recon.daily_recon_output join last_day_week_drn
		on last_day_week_drn.last_day = cast(recon.daily_recon_output.day as date)
		and last_day_week_drn.drn = recon.daily_recon_output.drn
	),

	weekly_aggregated_data as (
		select max(city) as city,
			country_code,
			cast(recon_week as date) as week_date,
			drn,
			sum(effective_days) as effective_days,
			sum (CASE 
			         WHEN 
			           JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'vehicle_days_off')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'driver_days_off')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'ineffective_days')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'date_equal_to_pickup_date')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'date_greater_than_equal_to_drop_off_date')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'assignment_start_date_is_null')::float = 1.0
			         THEN 1
			         ELSE 0
			       end) AS ineffective_days,
			sum(trips) as trips,
			sum(supply_hours) as supply_hours,
			sum(net_earnings_post_partner_adjustments) - (sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'partner_fees')::float) + sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'tax_partner_sales_tax')::float) + sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'tax_moove_output_vat')::float) ) as gross_bookings,
			sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'partner_fees')::float) as uber_fees,
			sum(net_earnings_post_partner_adjustments) as uber_net_of_fees,
			nvl(sum(taxes::float),0) as witholding_tax,
			round(sum(driver_remit_for_the_period)) as weekly_remit,
			nvl(sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')::float) + sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'uber_dynamic_pricing_program_discount')::float),0) as dynamic_pricing,
			sum(net_earnings_post_partner_adjustments + driver_remit_for_the_period + driver_discounts) + witholding_tax as driver_payable_before_additional_fees,
			sum(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'extra_charges')::float) as extra_charges,
			sum(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'passthrough_costs')::float) as passthrough_costs,
			sum(adjustments) as adjustments,
			sum(additional_charges + adjustments) + driver_payable_before_additional_fees as adjusted_driver_payable,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'partner_cash_collected_by_driver')::float) as cash_collected_in_the_week,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float) as payouts,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins,
			max(status) as status

		from recon.daily_recon_output
		group by country_code, drn, recon_week
	)

	select
		city,
		country_code,
		weekly_aggregated_data.week_date,
		weekly_aggregated_data.drn,
		effective_days,
		ineffective_days,
		trips,
		supply_hours,
		gross_bookings,
		uber_fees,
		uber_net_of_fees,
		witholding_tax,
		weekly_remit,
		dynamic_pricing,
		driver_payable_before_additional_fees,
		extra_charges,
		passthrough_costs,
		adjustments,
		adjusted_driver_payable,
		cast(driver_opening_balance as integer),
		cash_collected_in_the_week,
		payouts,
		payins,
		cast(driver_closing_balance as integer),
		status 

	from weekly_aggregated_data
	join driver_opening_balances on weekly_aggregated_data.week_date = driver_opening_balances.week_date and weekly_aggregated_data.drn = driver_opening_balances.drn
	join driver_closing_balances on weekly_aggregated_data.week_date = driver_closing_balances.week_date and weekly_aggregated_data.drn = driver_closing_balances.drn
	
)  with no schema binding;



----UPDATED VIEW------

	with first_day_week_drn as (
		select drn, cast(recon_week as date) as week_date, min(cast(day as date)) as first_day
		from recon.daily_recon_output group by drn, week_date
	),
	driver_opening_balances as (
		select cast(recon_week as date) as week_date, recon.daily_recon_output.drn, driver_opening_balance
		from recon.daily_recon_output join first_day_week_drn
		on first_day_week_drn.first_day = cast(recon.daily_recon_output.day as date)
		and first_day_week_drn.drn = recon.daily_recon_output.drn
	),
	last_day_week_drn as (
		select drn, cast(recon_week as date) as week_date, max(cast(day as date)) as last_day
		from recon.daily_recon_output group by drn, week_date
	),
	driver_closing_balances as (
		select cast(recon_week as date) as week_date, recon.daily_recon_output.drn, driver_closing_balance
		from recon.daily_recon_output join last_day_week_drn
		on last_day_week_drn.last_day = cast(recon.daily_recon_output.day as date)
		and last_day_week_drn.drn = recon.daily_recon_output.drn
	),
	weekly_aggregated_data as (
		select max(city) as city,
			country_code,
			cast(recon_week as date) as week_date,
			drn,
			sum(effective_days) as effective_days,
			sum (CASE 
			         WHEN 
			           JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'vehicle_days_off')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'driver_days_off')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'ineffective_days')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'date_equal_to_pickup_date')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'date_greater_than_equal_to_drop_off_date')::float = 1.0
			           OR JSON_EXTRACT_PATH_TEXT(effective_days_breakdown, 'assignment_start_date_is_null')::float = 1.0
			         THEN 1
			         ELSE 0
			       end) AS ineffective_days,
			sum(trips) as trips,
			sum(supply_hours) as supply_hours,
			sum(net_earnings_post_partner_adjustments) - (sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'partner_fees')::float) + sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'tax_partner_sales_tax')::float) + sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'tax_moove_output_vat')::float) ) as gross_bookings,
			sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'partner_fees')::float) as uber_fees,
			sum(net_earnings_post_partner_adjustments) as uber_net_of_fees,
			(NVL(sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'gross_fare')::float),0.0) + 
			NVL(sum(JSON_EXTRACT_PATH_TEXT(uber_payments_breakdown, 'partner_fees')::float),0.0) ) as net_fare,
			nvl(sum(taxes::float),0) as witholding_tax,
			round(sum(driver_remit_for_the_period)) as weekly_remit,
			nvl(sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')::float),0.0) + nvl(sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'uber_dynamic_pricing_program_discount')::float),0) as total_dynamic_pricing,
			nvl(sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'dynamic_pricing_discount')::float),0.0) as dynamic_pricing_discount,
			NVL(sum(JSON_EXTRACT_PATH_TEXT(driver_discounts_breakdown, 'uber_dynamic_pricing_program_discount')::float),0.0) as uber_dynamic_pricing_program_discount,
			sum(net_earnings_post_partner_adjustments + driver_remit_for_the_period + driver_discounts) + witholding_tax as driver_payable_before_additional_fees,
			sum(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'extra_charges')::float) as extra_charges,
			sum(JSON_EXTRACT_PATH_TEXT(additional_charges_breakdown, 'passthrough_costs')::float) as passthrough_costs,
			sum(adjustments) as adjustments,
			sum(additional_charges + adjustments) + driver_payable_before_additional_fees as adjusted_driver_payable,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'partner_cash_collected_by_driver')::float) as cash_collected_in_the_week,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payouts')::float) as payouts,
			sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins,
			max(status) as status

		from recon.daily_recon_output
		group by country_code, drn, recon_week
	)
	select
		city,
		country_code,
		weekly_aggregated_data.week_date,
		weekly_aggregated_data.drn,
		effective_days,
		ineffective_days,
		trips,
		supply_hours,
		gross_bookings,
		uber_fees,
		uber_net_of_fees,
		net_fare,
		witholding_tax,
		weekly_remit,
		total_dynamic_pricing,
		dynamic_pricing_discount,
		uber_dynamic_pricing_program_discount,
		driver_payable_before_additional_fees,
		extra_charges,
		passthrough_costs,
		adjustments,
		adjusted_driver_payable,
		cast(driver_opening_balance as integer),
		cash_collected_in_the_week,
		payouts,
		payins,
		cast(driver_closing_balance as integer),
		status 
	from weekly_aggregated_data
	join driver_opening_balances on weekly_aggregated_data.week_date = driver_opening_balances.week_date and weekly_aggregated_data.drn = driver_opening_balances.drn
	join driver_closing_balances on weekly_aggregated_data.week_date = driver_closing_balances.week_date and weekly_aggregated_data.drn = driver_closing_balances.drn;
	
	


select * from recon_india.daily_reconciliation
where drn = 'MVINT94273';

select * from recon_india.daily_reconciliation
where drn = 'MVIN12358';

select * from recon_india.reconciliation where drn = 'MVINT1111';


select * from recon_india.daily_reconciliation
where uber_name = 'SYED SADIQ UR RAHMAN';



--------------------------------------------------------------------------------------------------
---August 4, 2025------


SELECT * FROM dbt.core__vehicle_driver_assignment
WHERE drn = 'DRN017667';


select * from recon_nigeria.reconciliation_spresso
where drn = 'DRN017667';


----NIGERIA LOANS DATA ON DB------

Spresso
 fivetran_gsheets.ng_current_spresso_vehicle_loans
 fivetran_gsheets.ng_historical_spresso_vehicle_loans_1
Altos
fivetran_gsheets.ng_current_altos_vehicle_loans
UberX Lagos
fivetran_gsheets.ng_current_uberx_vehicle_loans
UberGo18
fivetran_gsheets.ng_ubergo_18_driver_loans





-----LATAM RECON VIEW---
select * from recon.recon_output__weekly_summary limit 100;




select * from recon.daily_recon_output limit 100;

select * from recon.daily_recon_output 
where recon_week in( '2025-06-09', '2025-06-16') and drn = 'MVMX00229' ;


select * from recon.recon_ouput__latest_published_vs_draft_comparison
where recon_week in( '2025-06-09', '2025-06-16') and drn = 'MVMX00229' ;



select * from reconciliation_data.recon_inputs__uber_payments limit 100;

select * from reconciliation_data.recon_inputs__uber_payments
where account = 'MVMX00229' and date between '2025-06-09' and  '2025-06-15';


select date, account, sum(source_uber_payments) as receivable_trans_svc_net_of_fees
from reconciliation_data.recon_inputs__uber_payments
where account = 'MVMX00229' and date between '2025-06-09' and '2025-06-15'
group by date, account
order by date asc;



select * from dbt.latam_recon__uber_payments_data limit 100;


select * from recon.recon_output__colombia_mailchimp_output limit 100;

select * from recon.recon_output__colombia_payouts limit 100;

select * from recon.recon_output__mexico_payouts limit 100;




dbt.latam_recon__uber_trips_data

select count (distinct drn),  from dbt.latam_recon__uber_payments_data



----NIGERIA RECON-----
WITH missing_transactions AS (
    SELECT weekly.org_id
         , weekly.vsreporting
         , weekly.transactionuuid
    FROM partners_data_weekly.mv_uber_harmonized_payments_order weekly
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order daily
                   ON
                       weekly.transactionuuid = daily.transactionuuid
    WHERE daily.transactionuuid IS NULL
      AND weekly.source_file_date >= '2025-07-28'
      AND weekly.vsreporting < (SYSDATE - 1)
)
SELECT DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions;


---NG SPRESSO--
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_nigeria.reconciliation_spresso
group by day 
order by day desc;


---NG ALTOS---
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_nigeria.reconciliation_alto
group by day 
order by day desc;


SELECT * FROM dbt.core__vehicle_driver_assignment
WHERE drn = 'DRN007819';


---GHANA---
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_ghana.reconciliation
group by day 
order by day desc;

MVG10347

select * from partners_data_daily.mv_uber_harmonized_driver_activity
where driveruuid = '39a93eed-1532-4233-bfcd-a5bb02e1f92c'
and source_file_date = '2025-08-03';



select * from partners_data_daily.mv_uber_harmonized_payments_order
where driveruuid = '39a93eed-1532-4233-bfcd-a5bb02e1f92c'
and source_file_date = '2025-08-03';




---GHANA---
select day, sum(trips) as trips,
sum(supply_hours) as supply_hours,
sum(net_earning) as net_earning,
sum(uber_balance) as uber_balance
from recon_ghana.reconciliation
where drn = 'MVG10347' and day = '2025-08-03'
group by day 
order by day desc;



------------------------------------------------------
-----AUGUST 5 2025------

select drn from recon.recon_output__colombia_mailchimp_output limit 100;


----Current mailchimp view----
CREATE OR REPLACE VIEW recon.recon_output__colombia_mailchimp_output
AS create or replace view recon.recon_output__colombia_mailchimp_output as
select week_date,
	   drn,
	   'UBXDTO60'as product,
	   'Renault Logan' as vehicle,
	   uber_net_of_fees as gearnings,
	   cash_collected_in_the_week as cash,
	   (uber_net_of_fees + cash_collected_in_the_week) as saldouber,
	   weekly_remit as wremit,
	   dynamic_pricing as discount,
	   extra_charges,
	   passthrough_costs,
	   (driver_opening_balance + payins) as pbalance,
	   payins,
	   driver_closing_balance as balance
from recon.recon_output__weekly_summary
where status = 'PUBLISHED' and country_code = 'Colombia'
and week_date = (select max(week_date) from recon.recon_output__weekly_summary ) 
with no schema binding  




;



select * from recon.recon_output__weekly_summary limit 10;

----UPDATE MAILCHIMP VIEW------
CREATE OR REPLACE VIEW recon.recon_output__colombia_mailchimp_output
AS create or replace view recon.recon_output__colombia_mailchimp_output as
select week_date,
	   drn,
	   'UBXDTO60'as product,
	   'Renault Logan' as vehicle,
	   uber_net_of_fees as gearnings,
	   cash_collected_in_the_week as cash,
	   (uber_net_of_fees + cash_collected_in_the_week) as saldouber,
	   weekly_remit as wremit,
	   dynamic_pricing_discount as discount,
	   extra_charges,
	   passthrough_costs,
	   (driver_opening_balance + payins) as pbalance,
	   payins,
	   driver_closing_balance as balance
from recon.recon_output__weekly_summary
where status = 'PUBLISHED' and country_code = 'Colombia'
and week_date = (select max(week_date) from recon.recon_output__weekly_summary ) 
with no schema binding  

;



dynamic_pricing_discount









----------------------
---CHECKING FOR MISSING ORG IDS----


----NIGERIA RECON-----
----Checking for missing Org ids - DAILY---
WITH missing_transactions AS (
    SELECT previous.org_id
         , previous.vsreporting
         , previous.transactionuuid
    FROM (select * from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date <= '2025-08-05') previous
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order yesterday
                   ON
                       previous.transactionuuid = yesterday.transactionuuid
    WHERE yesterday.transactionuuid IS NULL
      AND yesterday.source_file_date > '2025-08-05'
      AND previous.vsreporting < (SYSDATE - 1)
)
SELECT DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions;



select * from recon.daily_recon_output
where week >= '2025-06-09' and lower(country) = 'mexico'
and trips >0 and net_earnings_post_partner_adjustments = 0 ;


---Mexico Recon Checks---
with trips as (select driveruuid,org_id,sum(tripscompleted) as tripscompleted
from partners_data_daily.mv_uber_harmonized_driver_activity
where lower(country) = 'mexico'
and source_file_date between '2025-06-23' and '2025-06-29'
group by driveruuid,org_id
),
earnings as (select driveruuid,org_id,sum(paidtoyou__yourearnings) as net_earnings
from partners_data_daily.mv_uber_harmonized_payments_order
where lower(country) = 'mexico'
and source_file_date between '2025-06-23' and '2025-06-29'
group by driveruuid,org_id
)
select a.driveruuid,a.org_id,a.tripscompleted,b.net_earnings,
CASE
  WHEN (tripscompleted IS NULL OR tripscompleted = 0) AND (net_earnings IS NOT NULL AND net_earnings <> 0) THEN 'FAIL'
  WHEN (net_earnings IS NULL OR net_earnings = 0) AND (tripscompleted IS NOT NULL AND tripscompleted <> 0) THEN 'FAIL'
  ELSE 'OK'
  END AS trips_vs_earnings_check
from trips a join earnings b
on a.driveruuid = b.driveruuid
where a.driveruuid = 'ee969d8f-1511-48b3-bfe2-8c117ddb6f37'


select drn, uber_id, first_name, last_name,recon_week, sum(trips)trips, sum(net_earnings_post_partner_adjustments)net_earnings_post_partner_adjustments 
from recon.daily_recon_output
where week >= '2025-06-09' and lower(country) = 'mexico'
and trips >0 and net_earnings_post_partner_adjustments = 0 
group by drn, uber_id, first_name, last_name,recon_week;


with trips_no_earnings as(
select drn, uber_id, first_name, last_name,recon_week, sum(trips)trips, sum(net_earnings_post_partner_adjustments)net_earnings_post_partner_adjustments 
from recon.daily_recon_output
where week = '2025-06-09' and lower(country) = 'mexico'
and trips >0 and net_earnings_post_partner_adjustments = 0 
group by drn, uber_id, first_name, last_name,recon_week
),
uber_data as (
select * from dbt.latam_recon__uber_payments_data 
where source_file_date = '2025-06-09' 
)
select tne.drn, tne.uber_id, tne.first_name, tne.last_name,tne.recon_week,
sum(ud.receivable_trans_svc_net_of_fees)receivable_trans_svc_net_of_fees, sum(ud.cash_collected_by_driver)cash_collected_by_driver
from trips_no_earnings tne
left join uber_data ud
on tne.uber_id = ud.duuid
group by tne.drn, tne.uber_id, tne.first_name, tne.last_name,tne.recon_week;






select * from recon.daily_recon_output
where drn = 'MVMX00026' and recon_week = '2025-06-09';

SELECT * FROM dbt.core__vehicle_driver_assignment-- limit 5;
WHERE drn = 'MVMX00536';


select * from reconciliation_data.recon_inputs__adjustments limit 100;

select drn, sum(adjustment_amount) adjustment_amount
from reconciliation_data.recon_inputs__adjustments
where adjustment_date >= '2025-06-16' and lower(country_code) = 'mexico'
and source_adjustments in ('','')
group by drn;


---USING THE RAW ADJUSTMENTS DATA---
select * from reconciliation_data.adjustments limit 100;

select drn, sum(amount) adjustment_amount
from reconciliation_data.adjustments
where adjustment_date between '2025-06-16' and '2025-06-30'
and lower(country_code) = 'mx'
and adjustment_type in ('Extra Charges Adjustment')
group by drn;


select drn, sum(adjustments) adjustment_amount
from recon.daily_recon_output
where recon_week between '2025-06-16' and '2025-06-30'
and lower(country) = 'Mexico'
and adjustment_type in ('Extra Charges Adjustment')
group by drn;



--------------------------------------------------------
-----August 06, 2025------
---EXTRA CHARGES ISSUE---

with ec_adj_odi as (
select drn, sum(amount) extracharges_adjustment_amount
from reconciliation_data.adjustments
where adjustment_date between '2025-06-16' and '2025-06-30'
and lower(country_code) = 'mx'
and adjustment_type in ('Extra Charges Adjustment')
group by drn),
uber_adj_odi as (
select drn, sum(amount) uber_adjustment_amount
from reconciliation_data.adjustments
where adjustment_date between '2025-06-16' and '2025-06-30'
and lower(country_code) = 'mx'
and adjustment_type in ('Partner Balance Adjustment')
group by drn),
total_adj as (
select drn, sum(adjustments) recon_adjustment_amount
from recon.daily_recon_output
where recon_week between '2025-06-16' and '2025-06-30'
and lower(country) = 'mexico'
group by drn
)
select ta.drn, ta.recon_adjustment_amount, NVL(ec.extracharges_adjustment_amount,0.00) as extracharges_adjustment_amount, 
NVL(ua.uber_adjustment_amount,0.00) as uber_adjustment_amount,
(NVL(ec.extracharges_adjustment_amount,0.00) + NVL(ua.uber_adjustment_amount,0.00)) as total_logged_adjustments
from total_adj ta
left join ec_adj_odi ec
on ta.drn = ec.drn
left join uber_adj_odi ua
on ta.drn = ua.drn;


select recon_week, drn, adjustments from recon.daily_recon_output
--where recon_week between '2025-06-16' and '2025-06-30'
where recon_week >= '2025-06-16'
and DRN = 'MVMX00536';

----Total Logged Extra Charges---
select sum(amount) extracharges_adjustment_amount
from reconciliation_data.adjustments
where adjustment_date between '2025-06-16' and '2025-06-30'
and lower(country_code) = 'mx'
and adjustment_type in ('Extra Charges Adjustment');


select distinct drn, recon_week from recon.daily_recon_output
--where recon_week between '2025-06-16' and '2025-06-30'
where DRN = 'MVMX00536'
order by recon_week desc;

select drn, recon_week, adjustments from recon.daily_recon_output
where recon_week between '2025-06-16' and '2025-06-30'
and DRN = 'MVMX00203'
order by recon_week desc;

SELECT drn, vehicle_assignment_start_date, vehicle_assignment_end_date
FROM dbt.core__vehicle_driver_assignment-- limit 5;
WHERE drn in ( 'MVMX00536',
'MVMX00518',
'MVMX00529',
'MVMX00023',
'MVMX00224',
'MVMX00732',
'MVMX00203',
'MVMX00146',
'MVMX00243',
'MVMX00062',
'MVMX00657',
'MVMX00024',
'MVMX00689',
'MVMX00237',
'MVMX00740',
'MVMX00363',
'MVMX00368');



---EXTRACT EXTRA CHARGES APPLIED ON RECON----
select drn, sum(additional_charges) recon_additional_charges
from recon.daily_recon_output
where recon_week = '2025-06-09'
and lower(country) = 'mexico'
group by drn
having sum(additional_charges) <> 0;


--Check--
select drn, recon_week, adjustments from recon.daily_recon_output
where recon_week between '2025-06-09' and '2025-06-30'
and DRN in ('MVMX00531', 'MVMX00416')
order by recon_week desc;



----MEXICO FLEET RECON CHECK---
select * from recon.daily_recon_output
where recon_week = '2025-07-28'
and lower(country) = 'mexico';


select recon_week, count(distinct drn)drn, status from recon.daily_recon_output
where lower(country) = 'mexico' --and status = 'DRAFT'
group by recon_week, status
order by recon_week desc;


select distinct drn, recon_week from recon.daily_recon_output
where lower(country) = 'mexico' and recon_week = '2025-07-28'

----MX Fleet Drivers Jul 28 Analysis----
-------Most recent vehicle assignment
WITH mx_fleet_drivers as (
select distinct drn from recon.daily_recon_output
where lower(country) = 'mexico' and recon_week = '2025-07-28'
),
assignments AS (
SELECT * from (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment )
  WHERE rn = 1
),
with_uber_earnings as (
select distinct drn, nvl(sum(trips),0.00) as trips, nvl(sum(net_earnings_post_partner_adjustments),0.00) as net_earnings_post_partner_adjustments 
from recon.daily_recon_output
where lower(country) = 'mexico' and recon_week = '2025-07-28'
group by drn
having nvl(sum(net_earnings_post_partner_adjustments),0.00) >0
)
select mfd.drn, a.vehicle_assignment_start_date, a.vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status,
trips, net_earnings_post_partner_adjustments
from mx_fleet_drivers mfd
left join assignments a
on mfd.drn = a.drn
left join with_uber_earnings ue
on mfd.drn = ue.drn;
--where a.rn = 1 ;



---Checking the View----
select week_date, count(distinct drn)drn
from recon.recon_output__weekly_summary where country_code = 'Mexico' --and week = '2025-07-28'
group by week_date
order by week_date desc;



select * from recon.recon_output__weekly_summary where country_code = 'Mexico' and week_date = '2025-07-28';



----August 7, 2025---

select * from recon.recon_output__weekly_summary where country_code = 'Mexico'
and drn = 'MVMX00736';

----Nigeria Investigation for Duplicate Records Affecting the Nigeria Performance view on Copilot---
select drn, date, vehicle_type, product, product_id, product_start_date, product_end_date from vehicle.data_dump 
where date >= '2025-07-25' and city = 'Lagos' and drn = 'DRN017660';

select * from recon_nigeria.reconciliation_alto
where drn = 'DRN017660' and day >= '2025-07-25';

select * from recon_nigeria.reconciliation_spresso
where drn = 'DRN017660' and day >= '2025-07-25';

recon.recon_output__weekly_summary

select * FROM dbt.core__vehicle_driver_assignment
where drn = 'DRN017660' 




----August 7, 2025---
----MEXICO RENTAL RECON----

--Rental Issues
-- Payments - Uber Rental API Re-ingestion
-- Difference between Uber payments from Rodrigo and Uber API
-- Missed adjustments due to no formula update
-- Orphan UUIDs to DRNs mapping causing missed Uber payments
-- Adjustments applied based on the difference between Uber payments from Rodrigo and Uber API in the week of July 14.
-- ODI Adjustments to be applied to drivers who have moved from Fleet to Rental


----Getting driver profile data of drivers on the Rental & Financial models only-----
select country, dp.city, week, date, final_license_plate, dp.uber_id, dp.drn, first_name, last_name, carco_name, 
plan_code, first_assignment_date, churn_date
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' and week = '2025-07-21'
and drn in (select drn from reconciliation_data.driver_revenue_model where revenue_model in ('RENTAL', 'FINANCIAL'))
order by week, date, drn asc;

--Count of drns By Day---
select date, count(drn)drn_count
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' --and week = '2025-07-21'
and drn in (select drn from reconciliation_data.driver_revenue_model where revenue_model in ('RENTAL', 'FINANCIAL'))
group by date
order by date;

select * from reconciliation_data.driver_revenue_model;

select distinct drn
from dbt.latam_recon__driver_profile dp
where country = 'Mexico'-- and week = '2025-07-21'
and drn in (select drn from reconciliation_data.driver_revenue_model where revenue_model in ('RENTAL', 'FINANCIAL'));

select *
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' and week = '2025-07-21'
and drn = 'MVMX01534';

--Getting the details of drivers on rental & financial on driver profile but not on Recon---
select *
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' --and week = '2025-07-21'
and drn in (
'MVMX00724',
'MVMX00867',
'MVMX01108',
'MVMX01378',
'MVMX01411',
'MVMX01440',
'MVMX01450',
'MVMX01452',
'MVMX01456',
'MVMX01466',
'MVMX01492',
'MVMX01508',
'MVMX01534',
'MVMX01549',
'MVMX01551',
'MVMX01562',
'MVMX01573',
'MVMX01579',
'MVMX01581',
'MVMX01582',
'MVMX01583',
'MVMX01584',
'MVMX01586',
'MVMX01587',
'MVMX01588',
'MVMX01590',
'MVMX01591',
'MVMX01593',
'MVMX01594',
'MVMX01596',
'MVMX01597',
'MVMX01601',
'MVMX01602',
'MVMX01605',
'MVMX01609',
'MVMX01610',
'MVMX01612',
'MVMX01613',
'MVMX01614',
'MVMX01617',
'MVMX01621',
'MVMX01633',
'MVMX01635',
'MVMX01636'
)
order by date, drn asc;


--Getting the details of these missed drivers on rental & financial on Fleet Recon---
select * from
recon.recon_output__weekly_summary where country_code = 'Mexico'
and drn in (
'MVMX00724',
'MVMX00867',
'MVMX01108',
'MVMX01378',
'MVMX01411',
'MVMX01440',
'MVMX01450',
'MVMX01452',
'MVMX01456',
'MVMX01466',
'MVMX01492',
'MVMX01508',
'MVMX01534',
'MVMX01549',
'MVMX01551',
'MVMX01562',
'MVMX01573',
'MVMX01579',
'MVMX01581',
'MVMX01582',
'MVMX01583',
'MVMX01584',
'MVMX01586',
'MVMX01587',
'MVMX01588',
'MVMX01590',
'MVMX01591',
'MVMX01593',
'MVMX01594',
'MVMX01596',
'MVMX01597',
'MVMX01601',
'MVMX01602',
'MVMX01605',
'MVMX01609',
'MVMX01610',
'MVMX01612',
'MVMX01613',
'MVMX01614',
'MVMX01617',
'MVMX01621',
'MVMX01633',
'MVMX01635',
'MVMX01636'
)
order by week_date, drn asc;




---Rental Uber API----
---Weekly---
SELECT t.*
FROM persistence_uber_api_reports_weekly.rental_payments_transaction t
LIMIT 501;


---Daily---
SELECT t.*
FROM persistence_uber_api_reports_daily.rental_payments_transaction t
LIMIT 501;

select * from recon.daily_recon_output
where lower(country) = 'colombia'
order by week desc


SELECT t.*
FROM persistence_uber_api_reports_weekly.rental_payments_transaction t
where termsuuid = 'c78f9ee3-1d43-49f4-9d5c-f9df119431db';

SELECT distinct termsuuid, driverfirstname, driverlastname, account
FROM persistence_uber_api_reports_weekly.rental_payments_transaction
where vsreporting <= '2025-07-21' and type = 'Payment'
order by termsuuid;


select distinct account 
FROM persistence_uber_api_reports_weekly.rental_payments_transaction;


---RENTAL PAYMENTS QUERY---
with 
	uber_id_drn_map as (
	select *,
	rank()over(partition by uber_id order by created_date desc, updated_date desc ) as rnk
	from public.bridge_drn_uber_id
	)
select source_file_date, drn, termsuuid, driverfirstname, driverlastname, type, description, sum(amount) 
from persistence_uber_api_reports_weekly.rental_payments_transaction 
left join uber_id_drn_map on uber_id = termsuuid 
where source_file_date = '2025-06-30' and type = 'Payment'
group by source_file_date, termsuuid, drn, driverfirstname, driverlastname, type, description;



--Complete List: Getting the details of these missed drivers on rental & financial on Fleet Recon---
select * from
recon.recon_output__weekly_summary where country_code = 'Mexico'
and drn in (
'MVMX01450',
'MVMX01378',
'MVMX01240',
'MVMX01456',
'MVMX01222',
'MVMX01411',
'MVMX00867',
'MVMX01466',
'MVMX01508',
'MVMX00724',
'MVMX01108',
'MVMX01440',
'MVMX01452',
'MVMX01492',
'MVMX01534',
'MVMX01549',
'MVMX01551',
'MVMX01562',
'MVMX01573',
'MVMX01579',
'MVMX01581',
'MVMX01582',
'MVMX01583',
'MVMX01584',
'MVMX01586',
'MVMX01587',
'MVMX01588',
'MVMX01590',
'MVMX01591',
'MVMX01593',
'MVMX01594',
'MVMX01596',
'MVMX01597',
'MVMX01601',
'MVMX01602',
'MVMX01605',
'MVMX01609',
'MVMX01610',
'MVMX01612',
'MVMX01613',
'MVMX01614',
'MVMX01617',
'MVMX01621',
'MVMX01633',
'MVMX01635',
'MVMX01636'
);



---Do this by extracting their assignment start date and first appearance date on Rental API table
WITH base_table as (
select distinct drn, uber_id 
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' --and week <= '2025-07-21'
and drn in (
'MVMX01450', 'MVMX01378', 'MVMX01240', 'MVMX01456', 'MVMX01222', 'MVMX01411', 'MVMX00867', 'MVMX01466',
'MVMX01508', 'MVMX00724', 'MVMX01108', 'MVMX01440', 'MVMX01452', 'MVMX01492', 'MVMX01534', 'MVMX01549',
'MVMX01551', 'MVMX01562', 'MVMX01573', 'MVMX01579', 'MVMX01581', 'MVMX01582', 'MVMX01583', 'MVMX01584',
'MVMX01586', 'MVMX01587', 'MVMX01588', 'MVMX01590', 'MVMX01591', 'MVMX01593', 'MVMX01594', 'MVMX01596',
'MVMX01597', 'MVMX01601', 'MVMX01602', 'MVMX01605', 'MVMX01609', 'MVMX01610', 'MVMX01612', 'MVMX01613',
'MVMX01614', 'MVMX01617', 'MVMX01621', 'MVMX01633', 'MVMX01635', 'MVMX01636')
),
driver_profile as (
select country, city, week, date, final_license_plate, uber_id, drn, first_name, last_name, carco_name, 
plan_code, first_assignment_date, churn_date, vehicle_assignment_start_date, vehicle_assignment_end_date
from dbt.latam_recon__driver_profile dp
where country = 'Mexico' --and week = '2025-07-21'
),
--assignment as (
--SELECT * from (
--  SELECT
--    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
--    ROW_NUMBER() OVER (
--      PARTITION BY drn
--      ORDER BY vehicle_assignment_start_date DESC
--    ) AS rn
--  FROM dbt.core__vehicle_driver_assignment )
--  WHERE rn = 1
--),
rental_api as (
select source_file_date, termsuuid, driverfirstname, driverlastname, type, description, sum(amount) as uber_payment 
from persistence_uber_api_reports_daily.rental_payments_transaction 
where type = 'Payment'  --and source_file_date >= '2025-07-21' 
group by source_file_date, termsuuid, driverfirstname, driverlastname, type, description
)
select bt.drn, bt.uber_id, ra.source_file_date
from base_table bt
left join rental_api ra
on bt.uber_id = ra.termsuuid;
where bt.drn = 'MVMX00724'

select *  
from driver_profile dp
,rental_api ra
where dp.drn = 'MVMX00724'
order by dp.date, dp.drn;


select * from (
(select 
--COALESCE(dp.uber_id, ra.termsuuid) as uuid,
--case
--	when dp.date = ra.source_file_date then dp.date
--	else COALESCE(dp.date, ra.source_file_date)
--end as date_,
dp.*, ra.source_file_date, ra.termsuuid, ra.uber_payment
from driver_profile dp
full join rental_api ra
on dp.uber_id = ra.termsuuid and dp.date = ra.source_file_date
where dp.drn = 'MVMX00724' ---in (select distinct drn from base_table)
order by dp.date, dp.drn)
union
(select 
dp.*, ra.source_file_date, ra.termsuuid, ra.uber_payment
from driver_profile dp
full join rental_api ra
on dp.uber_id = ra.termsuuid --and dp.date = ra.source_file_date
where dp.drn = 'MVMX00724' ---in (select distinct drn from base_table)
and dp.date is distinct from ra.source_file_date
order by dp.date, dp.drn asc))
order by date, drn;





---Rental Drivers Not Assigned---
select * FROM dbt.core__vehicle_driver_assignment
where drn in ('MVMX01240','MVMX01222');

select * FROM dbt.core__vehicle_driver_assignment
where drn in ('MVMX00724');

---Check




----August 08, 2025---
partners_data_daily.mv_uber_harmonized_driver_activity
partners_data_daily.mv_uber_harmonized_driver_quality
partners_data_daily.mv_uber_harmonized_payments_driver
partners_data_daily.mv_uber_harmonized_payments_order
partners_data_daily.mv_uber_harmonized_trip_activity
partners_data_daily.vw_uber_driver_aggr

--Correct table
partners_data_daily.vw_uber_driver_aggr

recon_nigeria.reconciliation_spresso


recon_nigeria.reconciliation_alto


recon_ghana.reconciliation

recon_india.daily_reconciliation

recon_south_africa.reconciliation



select * from core.carcos;

select * from dbt.core__vehicle_driver_assignment limit 10;

select * from core.vehicle_models limit 10;



select * from dbt.carco_fleet_mapping limit 100;


select * from dbt.core__int_vehicle_domain limit 100;

select * from dbt.core__vehicle_domain limit 100;


select distinct carco_name, make, model_name
from dbt.core__vehicle_domain
where country = 'Nigeria';




---Nigeria Loan Analysis---

select * from dbt.core__vehicle_driver_assignment
where drn = 'DRN018637';



----NIGERIA LOANS DATA ON DB------

Spresso
 fivetran_gsheets.ng_current_spresso_vehicle_loans
 fivetran_gsheets.ng_historical_spresso_vehicle_loans_1
Altos
fivetran_gsheets.ng_current_altos_vehicle_loans
UberX Lagos
fivetran_gsheets.ng_current_uberx_vehicle_loans
UberGo18
fivetran_gsheets.ng_ubergo_18_driver_loans


select * from fivetran_gsheets.ng_current_altos_vehicle_loans limit 100;

select week, drn, effective_days
from fivetran_gsheets.ng_current_altos_vehicle_loans
where week = '2025-05-19';

select week, drn, effective_days
from fivetran_gsheets.ng_current_spresso_vehicle_loans
where week = '2025-05-19';

select * 
from fivetran_gsheets.ng_current_altos_vehicle_loans
where week = '2024-10-21' and drn = 'DRN017463';

select week, day, drn, effective_days, remittance from
recon_nigeria.reconciliation_alto
where week = '2025-07-21' and drn = 'DRN018302';


select week, day, drn, effective_days, remittance from
recon_nigeria.reconciliation_spresso
where week = '2025-07-21' and drn = 'DRN018302';


SELECT *
    FROM dbt_ahmed.fct_driver_loan_book_v1
    WHERE week = '2025-07-21' and drn = 'DRN018302'
    AND country = 'Nigeria';
    
select * from reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout limit 10;
   








--------------------------------------------
----Saturday Aug 9 2025-----

--Investigating why Recon did not Run for Nigeria & Ghana---
select * from partners_data_daily.mv_uber_harmonized_payments_order
where source_file_date = '2025-08-08'
and lower(country) = 'nigeria' limit 200;

select * from partners_data_daily.mv_uber_harmonized_payments_order
where source_file_date = '2025-08-08'
and lower(country) = 'ghana' limit 200;


select * from reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_tryout 
where day = '2025-08-08'; 

select * from reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_dto48_altos
where day = '2025-08-08'; 


----Checking for missing Org ids - DAILY---
WITH missing_transactions AS (
    SELECT previous.org_id
         , previous.vsreporting
         , previous.transactionuuid
    FROM (select * from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date <= '2025-08-07') previous
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order yesterday
                   ON
                       previous.transactionuuid = yesterday.transactionuuid
    WHERE yesterday.transactionuuid IS NULL
      AND yesterday.source_file_date > '2025-08-07'
      AND previous.vsreporting < (SYSDATE - 1)
)
SELECT DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions;


---Check for trips per org id---
select org_id, sum(tripscompleted)trips 
from partners_data_daily.mv_uber_harmonized_driver_activity
         where source_file_date = '2025-08-08' and org_id in ('GHA_ACC_14','GHA_ACC_02')
        group by org_id;
         
select org_id, sum(paidtoyou)trips from partners_data_daily.mv_uber_harmonized_payments_order
         where source_file_date = '2025-08-08' and org_id in ('GHA_ACC_14','GHA_ACC_02');
         partners_data_daily.mv_uber_harmonized_driver_activity

         

         
 --------August 13, 2025------------
         
select * from recon_nigeria.reconciliation_spresso limit 10;

---===Gbary's Loan Book===-----

select distinct week from recon_loan_book.loan_waterfall where country = 'South Africa' order by week desc;


select distinct week from recon_loan_book.loan_waterfall where country = 'South Africa' order by week desc;

select * from recon_loan_book.loan_waterfall limit 100;

 loan_book.products

recon_nigeria
 
 
 recon_nigeria.reconciliation_alto
 
 recon_nigeria.reconciliation_spresso
 
 
 select distinct org_id,source_file_date,to_date(vsreporting, 'yyyy-mm-dd'), count(transactionuuid)transactionuuid
-- select 
from partners_data_weekly.mv_uber_harmonized_payments_order where source_file_date >= '2025-07-28'
and org_id = 'GHA_ACC_04'--like '%GHA%'
group by 1,2,3
order by org_id, source_file_date desc;
 


 select distinct org_id,source_file_date, count(transactionuuid)transactionuuid
-- select 
from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date >= '2025-07-28'
and org_id = 'GHA_ACC_04'--like '%GHA%'
group by 1,2
order by org_id, source_file_date desc;


 
 recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental ;
 
 
 
 
 --ONE--
----Checking for missing Org ids - WEEKLY---
WITH missing_transactions AS (
    SELECT weekly.org_id
         , weekly.vsreporting
         , weekly.transactionuuid
    FROM partners_data_weekly.mv_uber_harmonized_payments_order weekly
         LEFT JOIN partners_data_daily.mv_uber_harmonized_payments_order daily
                   ON
                       weekly.transactionuuid = daily.transactionuuid
    WHERE daily.transactionuuid IS NULL
      AND weekly.source_file_date >= '2025-08-04'
      AND weekly.vsreporting < (SYSDATE - 1)
)
SELECT * ---DISTINCT org_id, to_date(vsreporting, 'yyyy-mm-dd')
FROM missing_transactions;
 
 
 
 
 select * from reconciliation_data.recon_inputs__uber_payments limit 10;
 
 


select source_file_date, termsuuid, driverfirstname, driverlastname, type, description, sum(amount) as uber_payment 
from persistence_uber_api_reports_weekly.rental_payments_transaction 
where type = 'Payment' and source_file_date >= '2025-07-21' 
group by source_file_date, termsuuid, driverfirstname, driverlastname, type, description;

select * from persistence_uber_api_reports_weekly.rental_payments_transaction limit 100;

select source_file_date, to_date(vsreporting, 'yyyy-mm-dd'), termsuuid, driverfirstname, driverlastname, type, description, sum(amount) as uber_payment 
from persistence_uber_api_reports_weekly.rental_payments_transaction 
where type = 'Payment' and source_file_date <= '2025-07-21' 
group by source_file_date, to_date(vsreporting, 'yyyy-mm-dd'),termsuuid, driverfirstname, driverlastname, type, description;


----UBER RENTAL PAYMENTS----
with uber_id_drn_map as (
	select *,
	rank()over(partition by uber_id order by created_date desc, updated_date desc ) as rnk
	from public.bridge_drn_uber_id
	)
	
select
	a."date",
	a.country,
	b.drn,
	LISTAGG(DISTINCT termsuuid, ', ') WITHIN GROUP (ORDER BY termsuuid) as rental_duuid,
	sum(a.amount) * (-1) as rental_payments
    
    from 
	(select *, DATE(TO_TIMESTAMP(vsreporting, 'YYYY-MM-DD HH24:MI:SS.MS') - INTERVAL '4 hours')  as "date"
	from persistence_uber_api_reports_weekly.rental_payments_transaction) a
 	left join (select uber_id, drn from uber_id_drn_map where rnk = 1) b
 	on b.uber_id = a.termsuuid

where a.type = 'Payment' and a.country = 'mexico'
group by a."date", a.country, drn;



select source_file_date, DATE(TO_TIMESTAMP(vsreporting, 'YYYY-MM-DD HH24:MI:SS.MS') - INTERVAL '4 hours')  as "date", 
termsuuid, driverfirstname, driverlastname, type, description, sum(amount) as uber_payment 
from persistence_uber_api_reports_weekly.rental_payments_transaction 
where type = 'Payment' and source_file_date <= '2025-07-21' 
group by 1,2,3,4,5,6,7;

select * from persistence_uber_api_reports_daily.rental_payments_transaction limit 100;

'a606c343-d723-4534-bfab-8afbf578c720';


select distinct vsreporting from persistence_uber_api_reports_daily.rental_payments_transaction 
where source_file_date = '2025-07-08';


select distinct vsreporting from (
select vsreporting, DATE(TO_TIMESTAMP(vsreporting, 'YYYY-MM-DD HH24:MI:SS.MS') - INTERVAL '4 hours')  as "date"
from persistence_uber_api_reports_weekly.rental_payments_transaction 
where type = 'Payment' and "date" = '2025-07-08');



---===Rental Recon History====----
select sum(amount) as total from persistence_uber_api_reports_weekly.rental_payments_transaction 
where type = 'Payment' and source_file_date <= '2025-07-21' and 
termsuuid not in ('2a34307a-64b7-487f-a8ab-d765c25de873','df9fe289-729a-4a25-863e-bf674147217c','0b454c1a-3dc0-4aca-8d16-d056bb5de33b')

select sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'rental_payments')::float) as total from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental;




select * from reconciliation_data.recon_inputs__driver_profile 
where drn = 'MVMX00839'
limit 100;

select distinct city,carco_name, plan_code
from reconciliation_data.recon_inputs__driver_profile dp
where drn = 'MVMX00359';

select distinct carco_name, plan_code
from dbt.latam_recon__driver_profile dp
where drn = 'MVMX00839';


country, city, week, date, final_license_plate, uber_id, drn, first_name, last_name, carco_name, 
plan_code, first_assignment_date, churn_date, vehicle_assignment_start_date, vehicle_assignment_end_date


select * from dbt.core__vehicle_domain
where registration_no_cleaned = 'JFP565A';

select * from 
dbt.core__vehicle_product_plan_assignment
where registration_no = 'JFP565A';


select * 
from dbt_recon.recon_input__driver_profile dp
where drn = 'MVMX00359' limit 10;

select distinct city from dbt_recon.recon_input__driver_profile dp
where drn = 'MVMX00839';


--Rental Excel History---
select * 
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental limit 10;


---Getting drivers with plan codes > 1
select distinct drn, count(distinct plan_code)
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
group by drn
having count(distinct plan_code) >1;


---Getting drivers with city > 1
select distinct drn, count(distinct city)
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
group by drn
having count(distinct city) >1;



select *
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
where drn = 'MVMX00203';

select * from recon.raw_daily_recon_output_mexico_temp_14_08_25 rdromt 

select * from dbt.core__vehicle_driver_assignment
where drn = 'MVMX01005';


--====August 18 2025===----

select * from recon.raw_daily_recon_output_mexico_temp_14_08_25 limit 10; 


---FInal Rental History---
select distinct drn, week, day, driver_opening_balance, driver_closing_balance 
from recon.raw_daily_recon_output_mexico_temp_14_08_25
where week = '2025-07-21';





_with_first_day_week_drn_as_select_drn_cast_recon_week_as_date_a_202508152225																											


country_code	city	week_date	drn	uber_id	registration_no	effective_days	trips	supply_hours	gross_bookings	uber_fees	uber_net_of_fees	witholding_tax	weekly_remit	moove_subsidies	dynamic_pricing_discount	driver_payable_before_additional_fees	extra_charges	passthrough_costs	adjustments	adjusted_driver_payable	driver_opening_balance	cash_collected_in_the_week	payouts	payins	rental_payments	driver_closing_balance	status


select * from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental limit 10;




country, city, week as week_date, day, registration_no, uber_id, drn, first_name, last_name, carco_name, plan_code, contract_start_date, contract_end_date, assignment_start_date, assignment_end_date, uber_payments_breakdown, partner_fleet_account_number, trips, supply_hours, effective_days, effective_days_breakdown, cumulative_effective_days, net_earnings_post_partner_adjustments, net_earnings_post_partner_adjustments_breakdown, taxes, taxes_breakdown, driver_remit_for_the_period, additional_charges, additional_charges_breakdown, adjustments, driver_discounts, driver_discounts_breakdown, payments, payments_breakdown, driver_opening_balance, driver_balance_for_the_period, driver_balance_for_the_period_breakdown, driver_closing_balance, driver_closing_balance_breakdown, deposit_opening_balance, deposit_payments, deposit_payments_breakdown, deposit_closing_balance, deposit_closing_balance_breakdown, previous_day_drn_was_on_recon, country_code, recon_week, status, ingestion_date


select * from dbt_recon.recon_output__weekly_summary
where lower(country_code) = 'mexico'
order by week_date desc limit 100;



select * from dbt_recon.recon_output__weekly_summary
where lower(country_code) = 'mexico'
order by week_date, drn;




-----Aug 19, 2025-----

select * from recon_nigeria.reconciliation_spresso limit 100;

select * recon_nigeria.reconciliation_spresso_backup limit 100;

select * recon_nigeria.reconciliation_alto_backup
where day <= '2023-12-31';

select * 
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
where drn = 'MVMX00107';

select week, drn, NVL(sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'rental_payments')::float),0.0) as total_rental_payments 
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
where drn = 'MVMX00107' ---and week = '2025-07-21'
group by week, drn
order by week desc;

select week, drn, sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'rental_payments')::float) as total_rental_payments 
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental
where drn = 'MVMX00566' and week = '2025-07-21'
group by week, drn
order by week desc;



----Compare Daily and Weekly Transansaction Ids to Find the Org_IDs with Missing Weekly Transaction IDs--------
select daily_org_id, count(distinct daily_duuid), sum(daily_net_earnings) from (
select
a.transactionuuid as daily_transactionuuid,
a.driveruuid as daily_duuid,
a.paidtoyou__yourearnings as daily_net_earnings,
a.source_file_date as daily_source_file_date,
a.org_id as daily_org_id,
b.transactionuuid as weekly_transactionuuid,
-- b.net_earnings as weekly_net_earnings,
b.source_file_date as weekly_source_file_date
from
partners_data_daily.mv_uber_harmonized_payments_order  a left join
partners_data_weekly.mv_uber_harmonized_payments_order  b
on a.transactionuuid = b.transactionuuid
where b.transactionuuid is null and a.source_file_date between '2025-08-01' and '2025-08-19'
and lower(a.country) in ('colombia', 'mexico'))
group by daily_org_id
order by 1,2; 



-----FINAL MEXICO RECON---
recon.daily_recon_output
dbt_recon.recon_output__weekly_summary

select * from dbt_recon.recon_output__weekly_summary limit 10;

select * from recon.daily_recon_output limit 10;


select * from dbt_recon.recon_output__weekly_summary
where week_date = '2025-07-21' and lower(country_code) = 'mexico';


select week_date, count(drn)record_count, count(drn)record_count, nvl(sum(driver_closing_balance),0.0) as closing_balance 
from dbt_recon.recon_output__weekly_summary
where week_date = '2025-07-21' and lower(country_code) = 'mexico'
group by week_date;


select week_date, count(distinct drn)drn_count,
nvl(sum(trips),0.0) as trips, nvl(sum(weekly_remit),0.0) as weekly_remit, 
nvl(sum(driver_opening_balance),0.0) as driver_opening_balance, nvl(sum(driver_closing_balance),0.0) as closing_balance 
from dbt_recon.recon_output__weekly_summary
where week_date = '2025-07-21' and lower(country_code) = 'mexico'
group by week_date;


select week, count(distinct drn)drn_count,
nvl(sum(trips),0.0) as trips, nvl(sum(driver_remit_for_the_period),0.0) as weekly_remit, 
nvl(sum(driver_opening_balance),0.0) as driver_opening_balance, nvl(sum(driver_closing_balance),0.0) as closing_balance 
from recon.daily_recon_output
where week = '2025-07-21' and lower(country) = 'mexico'
group by week;


select recon_week, nvl(sum(trips),0.0) as trips, nvl(sum(driver_remit_for_the_period),0.0) as weekly_remit, 
nvl(sum(driver_closing_balance),0.0) as closing_balance 
from recon.daily_recon_output
where recon_week = '2025-07-21' and lower(country_code) = 'mexico'
group by recon_week;


select week, nvl(sum(weekly_remit),0.0) as weekly_remit, nvl(sum(driver_closing_balance),0.0) as closing_balance 
from recon.raw_daily_recon_output_mexico_temp_14_08_25_w_rental


recon.daily_recon_output





---CHECKS----

--Weekly---
select distinct drn, week_date, driver_opening_balance,driver_closing_balance
from dbt_recon.recon_output__weekly_summary
where week_date = '2025-07-21' and lower(country_code) = 'mexico'
order by week_date, drn;


---Daily---
select distinct drn, week, day, driver_opening_balance,driver_closing_balance
from recon.daily_recon_output
where week = '2025-07-21' and lower(country) = 'mexico'
order by week, drn, day;

select * from recon.daily_recon_output
where drn = 'MVMX00342' and week = '2025-07-21';

select max(recon_week)week from recon.daily_recon_output
where drn in ('MVMX00342','MVMX00707');

select max(week_date)week from dbt_recon.recon_output__weekly_summary
where drn = 'MVMX00342' --and week = '2025-07-21';






---AUg 20, 2025---

select * from alerting.event_notifications limit 100;


select * from alerting.exploded_missing_drn_alert limit 100;


select *
from alerting.event_notifications
where subject = 'Redshift Validation'
and event_date >= '2025-08-01';





select * from reconciliation_data.recon_inputs__uber_dynamic_pricing_program limit 200;


select * from reconciliation_data.recon_inputs__uber_dynamic_pricing_program 
where drn = 'MVCO00053';

to_date(vsreporting, 'yyyy-mm-dd')

select * from recon.raw_daily_recon_output
where drn = 'MVCO00291' and week = '2025-08-11'and ingestion_date = '2025-08-20 16:44:05.000';

select * from dbt_recon.recon_output__colombia_mailchimp_output limit 100;

select * from dbt_recon.recon_output__colombia_payouts limit 100;




----August 21, 2025----
--UBER DRIVER UUID NOW AVAILABLE ON THE API!!!
select count( driver_id) from persistence_uber_api.drivers__feature_dtt_12125 where org_id = 'IND_BOM_03';

  select sum(validation_value::int) from monitoring.uber_api_drivers_metadata__feature_dtt_12125 
  where ingestion_date = '2025-08-20' and file_path like '%IND_BOM_03%'
  
  
  
  ---August 22, 2025----
  
  ---Checking MX missed weeks claim---
  --DAILY TABLE--
  select week, count(drn)record_count, count (distinct drn) drn_count , 
  sum(driver_remit_for_the_period)driver_remit_for_the_period
  from recon.raw_daily_recon_output where country = 'Mexico'
  and lower(status) = 'published'
  group by week
  having max(ingestion_date) = max(ingestion_date)
 order by week;
  
--WEEKLY TABLE---
select week_date, count(drn)record_count, count (distinct drn) drn_count, sum(weekly_remit) weekly_remit
  from dbt_recon.recon_output__weekly_summary where lower(country_code) = 'mexico'
  and lower(status) = 'published'
  group by week_date
 order by week_date;


select * from recon.raw_daily_recon_output limit 100;

select * from dbt_recon.recon_output__weekly_summary limit 100;


----Identifying the missing DRNs for MX
with daily_recon as(
select distinct drn, week,
  sum(driver_remit_for_the_period)driver_remit_for_the_period
  from recon.raw_daily_recon_output where country = 'Mexico'
  and lower(status) = 'published'
  group by drn,week
  having max(ingestion_date) = max(ingestion_date)
  order by drn, week
),
weekly_recon as (
select distinct drn, week_date, sum(weekly_remit) weekly_remit
  from dbt_recon.recon_output__weekly_summary where lower(country_code) = 'mexico'
  and lower(status) = 'published'
  group by drn,week_date
 order by drn, week_date
)
select drn, week from daily_recon
where week between '2025-06-30' and '2025-07-28'
and drn not in (select drn from weekly_recon where week_date between '2025-06-30' and '2025-07-28')
order by week, drn;


MVMX00587

select distinct ingestion_date
from recon.raw_daily_recon_output
where week = '2025-06-30';

select week, day, drn, trips, supply_hours, effective_days, driver_remit_for_the_period, 
payments, driver_opening_balance, driver_closing_balance, recon_week, status,ingestion_date
from recon.raw_daily_recon_output
where ingestion_date = '2025-07-09 14:18:05.000'
and country = 'Mexico' and week = '2025-06-30';

select * 
from dbt_recon.recon_output__weekly_summary where lower(country_code) = 'mexico'
and lower(status) = 'published' and week_date = '2025-06-30';




----====August 25, 2025====----

select * from reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_dto48_altos limit 100;



select * from recon_nigeria.reconciliation_alto limit 100;

select * from recon_nigeria.reconciliation_spresso limit 10;

updated_at

---India Checks---

select * from recon_india.daily_reconciliation limit 10;

select week, day, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(refund_and_expenses)refund_and_expenses
from recon_india.daily_reconciliation
group by week, day
order by week, day;

select week, day, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(refund_and_expenses)refund_and_expenses
from recon_india.daily_reconciliation
group by week, day
order by week, day;

select week, day,drn, sum(refund_and_expenses)refund_and_expenses
from recon_india.daily_reconciliation
group by week, day,drn
having sum(refund_and_expenses) <0
order by week, day,drn;



--=====UUID HUNTER====----

Count of drivers with one-many relationship [DRN<>UUID] per market & overall.
Count of drivers with many-many relationship [DRN<>UUID] per market & overall.
Number of data dump sheets in use
Number of orphan UUIDs (Unmatched UUIDs)
Number of trips/ sum of net earnings generated by these IDs and the impact of their miss.
Time current process take.






reconciliation_data




--=======August 26 2025=====--------

--South Africa Recon--

--Comparing Daily & Weekly Trips & Earnings---
SELECT
  country,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Trips' THEN value ELSE 0 END) AS daily_tripscompleted,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Trips' THEN value ELSE 0 END) AS weekly_tripscompleted,
  SUM(CASE WHEN granularity = 'Daily' AND metric = 'Earnings' THEN value ELSE 0 END) AS daily_earnings,
  SUM(CASE WHEN granularity = 'Weekly' AND metric = 'Earnings' THEN value ELSE 0 END) AS weekly_earnings
FROM (
  SELECT 'Daily' AS granularity, 'Trips' AS metric, country, tripscompleted AS value
  FROM partners_data_daily.mv_uber_harmonized_driver_activity
  WHERE source_file_date BETWEEN '2025-08-18' AND '2025-08-24'
    --AND country IN ('india')-- For specific countries, uncomment and replace as needed
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Trips' AS metric, country, tripscompleted AS value
  FROM partners_data_weekly.mv_uber_harmonized_driver_activity
  WHERE source_file_date = '2025-08-18'
    --AND country IN ('india')
  UNION ALL
  SELECT 'Daily' AS granularity, 'Earnings' AS metric, country, paidtoyou__yourearnings AS value
  FROM partners_data_daily.mv_uber_harmonized_payments_order
  WHERE source_file_date BETWEEN '2025-08-18' AND '2025-08-24'
    --AND country IN ('ghana')
  UNION ALL
  SELECT 'Weekly' AS granularity, 'Earnings' AS metric, country, paidtoyou__yourearnings AS value
  FROM partners_data_weekly.mv_uber_harmonized_payments_order
  WHERE source_file_date = '2025-08-18'
    --AND country IN ('ghana')
) AS merged_data
GROUP BY country;




select * from recon_south_africa.reconciliation limit 10;

select week, sum(bank_statement)bank_statement from recon_south_africa.reconciliation
where week = '2025-08-18'
group by week;


select * from recon_south_africa.reconciliation
where week = '2025-08-18' and
drn = 'MVS20287';


select week, count(drn)drn_count, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(bank_statement)bank_statement from recon_south_africa.reconciliation
where week = '2025-08-18'
group by week;






--=====UUID HUNTER====----

Count of drivers with one-many relationship [DRN<>UUID] per market & overall.
Count of drivers with many-many relationship [DRN<>UUID] per market & overall.
Number of data dump sheets in use
Number of orphan UUIDs (Unmatched UUIDs)
Number of trips/ sum of net earnings generated by these IDs and the impact of their miss.
Time current process take.



---ONE:----
--Multiple driver UUID assignments for 1 DRN per country - 179 DRNs
WITH drn_uuid_counts AS (
   SELECT
       country,
       drn,
       COUNT(DISTINCT driver_uuid) as uuid_count
   FROM quality_reporting.gsheet_driver_data
   WHERE partition_date IN (SELECT MAX(partition_date) FROM quality_reporting.gsheet_driver_data)
     AND driver_uuid IS NOT NULL
     AND drn IS NOT NULL
   GROUP BY country, drn
   HAVING COUNT(DISTINCT driver_uuid) > 1
),
    drn_uuid_list AS (
        SELECT
            country,
            drn,
            LISTAGG(DISTINCT driver_uuid, ', ') WITHIN GROUP (ORDER BY driver_uuid) as driver_uuids
        FROM quality_reporting.gsheet_driver_data
        WHERE partition_date IN (SELECT MAX(partition_date) FROM quality_reporting.gsheet_driver_data)
          AND driver_uuid IS NOT NULL
          AND drn IS NOT NULL
        GROUP BY country, drn
    )
SELECT
   c.country,
   c.drn,
   c.uuid_count,
   l.driver_uuids
FROM drn_uuid_counts c
        JOIN drn_uuid_list l ON c.country = l.country AND c.drn = l.drn
ORDER BY c.country, c.uuid_count DESC, c.drn;





---Colombia Recon---
select * from reconciliation_data.recon_inputs__ineffective_days
where drn = 'MVCO00978';


select * from reconciliation_data.recon_inputs__ineffective_days
order by date, partition_date desc limit 200;

select distinct partition_date from reconciliation_data.recon_inputs__ineffective_days
order by partition_date desc;

select distinct date from reconciliation_data.recon_inputs__ineffective_days
where lower(country_code) = 'colombia'
order by date desc;

select * from reconciliation_data.days_off limit 100;


select * from reconciliation_data.recon_inputs__ineffective_days
where partition_date = '2025-08-26'and lower(country_code) = 'colombia'
order by date desc;






select * from dbt_recon.recon_input__driver_ineffective_days limit 100;

select * from dbt_recon.recon_input__driver_ineffective_days
where drn = 'MVCO00978';


select * from core.ineffective_days_requests
where driver_id = 'a4657bed-80a2-407e-96c2-6285fa543666';
--where drn = 'MVCO00978';

select driver_id from core.drivers
where drn = 'MVCO00978';



---TWO:--
---Multiple DRNs per 1 UUID per country - 92 cases
WITH uuid_drn_counts AS (
   SELECT
       country,
       driver_uuid,
       COUNT(DISTINCT drn) as drn_count
   FROM quality_reporting.gsheet_driver_data
   WHERE partition_date IN (SELECT MAX(partition_date) FROM quality_reporting.gsheet_driver_data)
     AND driver_uuid IS NOT NULL
     AND drn IS NOT NULL
   GROUP BY country, driver_uuid
   HAVING COUNT(DISTINCT drn) > 1
),
    uuid_drn_list AS (
        SELECT
            country,
            driver_uuid,
            LISTAGG(DISTINCT drn, ', ') WITHIN GROUP (ORDER BY drn) as drns
        FROM quality_reporting.gsheet_driver_data
        WHERE partition_date IN (SELECT MAX(partition_date) FROM quality_reporting.gsheet_driver_data)
          AND driver_uuid IS NOT NULL
          AND drn IS NOT NULL
        GROUP BY country, driver_uuid
    )
SELECT
   c.country,
   c.driver_uuid,
   c.drn_count,
   l.drns
FROM uuid_drn_counts c
        JOIN uuid_drn_list l ON c.country = l.country AND c.driver_uuid = l.driver_uuid
ORDER BY c.country, c.drn_count DESC, c.driver_uuid;


----August 27, 2025---
--THREE:
--Amount of Not assigned UUIDs in Data Dump for active drivers who have Payments data & Trips data
select event_date,
      --country,
      count(distinct driveruuid) from alerting.exploded_missing_drn_alert
group by event_date
      --, country
order by event_date desc


--FOUR:
--Monthly analysis
 SELECT
   DATE_TRUNC('month', event_date) as month,
   country,
   COUNT(DISTINCT driveruuid) as unique_drivers_affected_in_month,
   COUNT(DISTINCT event_date) as active_days_in_month,
   COUNT(*) as total_alert_records_in_month,
   ROUND(COUNT(*) * 1.0 / COUNT(DISTINCT event_date), 2) as avg_alerts_per_active_day
FROM alerting.exploded_missing_drn_alert
WHERE event_date >= CURRENT_DATE - INTERVAL '2 years'
GROUP BY DATE_TRUNC('month', event_date), country
ORDER BY month DESC, country;


--FIVE:
--Summary statistics for missing DRNs for active drivers for last 3 months 
WITH daily_counts AS (
   SELECT
       event_date,
       country,
       city,
       COUNT(DISTINCT driveruuid) as daily_missing_count
   FROM alerting.exploded_missing_drn_alert
   WHERE event_date >= CURRENT_DATE - INTERVAL '3 months'
   GROUP BY event_date, country, city
),
    basic_stats AS (
        SELECT
            country,
            city,
            COUNT(DISTINCT event_date) as days_with_missing_mappings,
            AVG(daily_missing_count) as avg_daily_missing,
            MIN(daily_missing_count) as min_daily_missing,
            MAX(daily_missing_count) as max_daily_missing,
            STDDEV(daily_missing_count) as stddev_daily_missing
        FROM daily_counts
        GROUP BY country, city
    ),
    median_stats AS (
        SELECT
            country,
            city,
            PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY daily_missing_count) as median_daily_missing
        FROM daily_counts
        GROUP BY country, city
    )
SELECT
   b.country,
   b.city,
   b.days_with_missing_mappings,
   ROUND(b.avg_daily_missing, 2) as avg_daily_missing,
   b.min_daily_missing,
   b.max_daily_missing,
   ROUND(m.median_daily_missing, 2) as median_daily_missing,
   ROUND(b.stddev_daily_missing, 2) as stddev_daily_missing
FROM basic_stats b
        JOIN median_stats m ON b.country = m.country AND b.city = m.city
ORDER BY b.avg_daily_missing DESC;


--SIX:
--Daily trend analysis for scatter plot - start of the week vs end of the week missing assignment for active drivers who have performance and payments data
   WITH daily_missing AS (
   SELECT
       event_date,
       DATE_TRUNC('week', event_date) as week_start,
       EXTRACT(dow FROM event_date) as day_of_week, -- 0=Sunday, 1=Monday, etc.
       country,
       city,
       COUNT(DISTINCT driveruuid) as daily_missing_count
   FROM alerting.exploded_missing_drn_alert
   WHERE event_date >= CURRENT_DATE - INTERVAL '8 weeks'
   GROUP BY event_date, DATE_TRUNC('week', event_date), EXTRACT(dow FROM event_date), country, city
),
    weekly_comparison AS (
        SELECT
            week_start,
            country,
            city,
            AVG(CASE WHEN day_of_week IN (1, 2) THEN daily_missing_count END) as avg_missing_early_week,
            AVG(CASE WHEN day_of_week IN (5, 6, 0) THEN daily_missing_count END) as avg_missing_late_week,
            MIN(daily_missing_count) as min_missing_in_week,
            MAX(daily_missing_count) as max_missing_in_week
        FROM daily_missing
        GROUP BY week_start, country, city
    )
SELECT
   week_start,
   country,
   city,
   COALESCE(avg_missing_early_week, 0) as avg_missing_early_week,
   COALESCE(avg_missing_late_week, 0) as avg_missing_late_week,
   min_missing_in_week,
   max_missing_in_week,
   COALESCE(avg_missing_early_week, 0) - COALESCE(avg_missing_late_week, 0) as weekly_improvement,
   CASE
       WHEN avg_missing_early_week > 0 THEN
           ROUND(((COALESCE(avg_missing_early_week, 0) - COALESCE(avg_missing_late_week, 0)) * 100.0 / avg_missing_early_week), 2)
       ELSE 0
       END as improvement_percentage,
   country || ' - ' || city as location_label
FROM weekly_comparison
WHERE avg_missing_early_week > 0 OR avg_missing_late_week > 0
ORDER BY week_start DESC, improvement_percentage DESC;





---========August 29, 2025===----
---India subscription charges---
select * from partners_data_daily.mv_uber_harmonized_payments_order limit 10;

select * from partners_data_daily.mv_uber_harmonized_payments_order
where lower(country) = 'india'
and source_file_date = '2025-08-18' and paidtoyou is not null
order by source_file_date desc;

---The two columns are 
--The Uber subscription charge will be added as an additional column on Recon 
--(summing two columns - paidtoyou__tripbalance__expenses__driversubscriptioncharge 
--and paidtoyou__tripbalance__expenses__igstsupportservices from the Uber payment data)



----India unassigned drivers still on Recon issue

----First Issue Raised----
with base as (
select * from recon_india.daily_reconciliation
order by week, day desc
),
maximum as (
select drn, max(day)last_appearance_date from recon_india.daily_reconciliation
where drn in ('MVIN16478',
'MVIN17129','MVIN17124','MVIN17115','MVIN17048','MVIN16786','MVIN16657',
'MVIN08949','MVIN16778','MVIN16952','MVIN16977','MVIN16744','MVIN16794',
'MVIN16381','MVIN16705','MVIN16709','MVIN16737','MVIN16751','MVIN16973',
'MVIN16976','MVIN17008','MVIN17026','MVIN17181','MVIN17193','MVIN17195',
'MVIN17266','MVIN16158')
group by drn
),
assignment as (
select * from (
SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rk
  FROM dbt.core__vehicle_driver_assignment)
  WHERE rk = 1
)
select
m.last_appearance_date, 
a.vehicle_assignment_start_date, a.vehicle_assignment_end_date,
case
	when a.vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status, 
b.*
from maximum m
left join base b
on m.drn = b.drn and b.day = m.last_appearance_date
left join assignment a
on m.drn = a.drn
where last_appearance_date is not null ;



----Second Issue Raised----
with base as (
select * from recon_india.daily_reconciliation
order by week, day desc
),
maximum as (
select drn, max(day)last_appearance_date from recon_india.daily_reconciliation
where drn in ('MVIN17763', 'MVIN17487','MVIN17460','MVIN17429','MVIN17406','MVIN17404',
'MVIN17393','MVIN17357','MVIN17308','MVIN17281','MVIN17266','MVIN17206','MVIN17204',
'MVIN17198','MVIN17195','MVIN17193','MVIN17192','MVIN17181','MVIN17169','MVIN17166',
'MVIN17159','MVIN17158','MVIN17129','MVIN17124','MVIN17115','MVIN17091','MVIN17068',
'MVIN17054','MVIN17053','MVIN17048','MVIN17029','MVIN17026','MVIN17008','MVIN17006',
'MVIN16976','MVIN16973','MVIN16933','MVIN16929','MVIN16812','MVIN16803','MVIN16791',
'MVIN16786','MVIN16777','MVIN16773','MVIN16752','MVIN16751','MVIN16750','MVIN16748',
'MVIN16747','MVIN16743','MVIN16737','MVIN16731','MVIN16729','MVIN16722','MVIN16709',
'MVIN16705','MVIN16697','MVIN16675','MVIN16657','MVIN16381','MVIN16086','MVIN15444',
'MVIN15284','MVIN08949','MVIN02930','MVIN14715','MVIN09426','MVIN17212','MVIN17120',
'MVIN17116','MVIN17083','MVIN16977','MVIN16952','MVIN16794','MVIN16744','MVIN17067',
'MVIN12908','MVIN17229','MVIN17414','MVIN01792','MVIN16616','MVIN16738','MVIN00793',
'MVIN01016')
group by drn
),
assignment as (
select * from (
SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rk
  FROM dbt.core__vehicle_driver_assignment)
  WHERE rk = 1
)
select
m.last_appearance_date, 
a.vehicle_assignment_start_date, a.vehicle_assignment_end_date,
case
	when a.vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status, 
b.*
from maximum m
left join base b
on m.drn = b.drn and b.day = m.last_appearance_date
left join assignment a
on m.drn = a.drn
where last_appearance_date is not null ;




---Deep Dives----
WITH assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
select *, --drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from assignments
where rn = 1 and drn = 'MVIN01792';


select * from recon_india.daily_reconciliation
where drn in ('MVIN01792' )
order by day desc;

is_assigned_today

---COlombia Payment Aggregator
select driver_number as drn, transaction_date as date, sum(amount) as payins  
from  payments_aggregator.aggregated_transactions 
where country_code = 'CO' and payment_type = 'PAYIN' 
and status = 'SUCCESS' 
group by driver_number, transaction_date  ;





--------------------------------------------------------------------------------------------
---Weekend AUg 31, 2025---India Missing Earnings Issue---
----Investigations---


'3035d1e1-d2df-4291-9880-b7954db8ffdd'

select distinct org_id
from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date >= '2025-08-01'
--and org_id like '%IND%';

select distinct org_id
from partners_data_daily.mv_uber_harmonized_payments_order where source_file_date = '2025-08-30'
and org_id like '%IND%';



select org_id, count(driveruuid)
from persistence_uber_api_reports_daily.payments_order_report
where source_file_date = '2025-08-31'
and org_id like '%IND%'
group by org_id
order by org_id;

select org_id, count(distinct driveruuid)unique_driveruuid
from persistence_uber_api_reports_daily.payments_order_report
where source_file_date > '2025-01-01'
and org_id like '%IND%'
group by org_id
order by org_id;



-----------------------------------------
--===Sep 01, 2025===----
----Colombia Payins Comparison


select * from dbt_recon.recon_input__uber_payments_data limit 100;



select driver_number as drn, transaction_date as date, sum(amount) as payins  
from  payments_aggregator.aggregated_transactions 
where country_code = 'CO' and payment_type = 'PAYIN' 
and status = 'SUCCESS' 
group by driver_number, transaction_date;

select * from dbt_recon.recon_input__uber_payments_cols_mapping limit 100;

reconciliation_data.payments

select * from reconciliation_data.recon_inputs__payments limit 100;

select distinct date from reconciliation_data.recon_inputs__payments
order by date desc;



select driver_number as drn, transaction_date as date,sum(amount) as payins  
from  payments_aggregator.aggregated_transactions 
where country_code = 'CO' and payment_type = 'PAYIN' 
and status = 'SUCCESS' and transaction_date >= '2024-12-30' --and '2025-08-25';
and driver_number = 'MVCO00832'
group by driver_number, transaction_date
order by driver_number, transaction_date;

----Check Summary--
select  
SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins
from recon.daily_recon_output
where country = 'Colombia' and day between '2025-07-07' and '2025-08-25';


---Check per Driver on Recon--
select  country, week, day,drn,
SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins
from recon.daily_recon_output
where country = 'Colombia' and day >= '2024-12-30' --and '2025-08-25'
group by country, week, day,drn
having SUM(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) >0
order by day, drn desc;



---------------------------------------
---Sep 2, 2025---
---SA Recon---



select * from recon_south_africa.reconciliation limit 10;

select week, sum(bank_statement)bank_statement from recon_south_africa.reconciliation
where week = '2025-08-18'
group by week;


select * from recon_south_africa.reconciliation
where week = '2025-08-18' and
drn = 'MVS20287';


select week, count(drn)drn_count, sum(net_earning)net_earning, sum(cash_collected)cash_collected, sum(uber_balance)uber_balance,
sum(bank_statement)bank_statement from recon_south_africa.reconciliation
where week = '2025-08-18'
group by week;





---------------------------------
---Sep 2 2025---
--NG Payins----

select drn, max(payment_date)  
from (
select driver_number as drn, created as payment_date, SUM(amount) as payins  
from payments_aggregator.aggregated_transactions
where country_code = 'NG' and payment_type = 'PAYIN' 
and status = 'SUCCESS'
group by driver_number, created 
order by created desc
)
where drn in ('DRN002103',
'DRN006684',
'DRN005426',
'DRN001006',
'DRN000515',
'DRN000583',
'DRN000951',
'DRN001312',
'DRN001357',
'DRN001608',
'DRN001758',
'DRN001938',
'DRN001186',
'DRN001212',
'DRN001302',
'DRN002096',
'DRN002094',
'DRN002016',
'DRN002247',
'DRN002529',
'DRN002530',
'DRN002331',
'DRN002464',
'DRN002598',
'DRN002612',
'DRN002659',
'DRN002664',
'DRN002694',
'DRN002713',
'DRN002576',
'DRN002596',
'DRN003688',
'DRN003511',
'DRN003914',
'DRN004376',
'DRN004788',
'DRN004959',
'DRN004478',
'DRN004752',
'DRN005359',
'DRN005062',
'DRN005714',
'DRN005445',
'DRN005753',
'DRN007808',
'DRN008243',
'DRN011862')
group by drn;



select * ---driver_number as drn, transaction_date as date,sum(amount) as payins  
from  payments_aggregator.aggregated_transactions 
where country_code = 'NG' and payment_type = 'PAYIN' 
and status = 'SUCCESS' and transaction_date >= '2024-12-30' --and '2025-08-25';
and driver_number = 'MVCO00832'
group by driver_number, transaction_date
order by driver_number, transaction_date;



select driver_number as drn,
(created AT TIME ZONE 'UTC')::date as "date",
sum(amount) as payments_aggregator_payins,
status,
country_code 
from  payments_aggregator.aggregated_transactions 
where payment_type = 'PAYIN' 
group by driver_number, (created AT TIME ZONE 'UTC')::date , status, country_code




--NG---

select * from tmp_loan_book.stg_fct_raw_recon
WHERE country='Nigeria' limit 100;

SELECT *
    FROM tmp_loan_book.stg_fct_driver_payment
    WHERE country='Nigeria' limit 100;

SELECT *
    FROM tmp_loan_book.fct_vehicle_loan_book_v1
    WHERE country='Nigeria' limit 100;


---------------------------------------
   --Sep 4, 2025---
   
   select * from persistence_uber_api.drivers limit 10;
   
  select * from persistence_uber_api.drivers
  where driver_id IN ('03b1cd69-2164-4001-8f96-ca8936b4ec88', '78d56390-af1f-428f-a0fa-e7640b7c8cc8');
  
  SELECT DISTINCT
       driver_id as driver_uuid
       
       
select MIN(week) as min_week from
(SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where drn = 'MVS11116';




-------------------------------------------
--Check India Subcription charge & platform fee addition to India recon---

select 
count(distinct driveruuid)count_driveruuid,
NVL(SUM(paidtoyou__tripbalance__expenses__driversubscriptioncharge + paidtoyou__tripbalance__expenses__igstsupportservices),0.0) as all_subscription_charge ,
NVL(SUM(paidtoyou__tripbalance__expenses__driversubscriptioncharge),0.0) as subscription_charge ,
NVL(SUM(paidtoyou__tripbalance__expenses__igstsupportservices),0.0) as iglts
from 
partners_data_daily.mv_uber_harmonized_payments_order
where org_id LIKE '%IND%' and source_file_date = '2025-09-02';


select driveruuid,
--count(distinct driveruuid)count_driveruuid,
NVL(SUM(paidtoyou__tripbalance__expenses__driversubscriptioncharge + paidtoyou__tripbalance__expenses__igstsupportservices),0.0) as all_subscription_charge ,
NVL(SUM(paidtoyou__tripbalance__expenses__driversubscriptioncharge),0.0) as subscription_charge ,
NVL(SUM(paidtoyou__tripbalance__expenses__igstsupportservices),0.0) as iglts
from 
partners_data_daily.mv_uber_harmonized_payments_order
where org_id LIKE '%IND%' and source_file_date = '2025-09-02'
and driveruuid  in ('c204eac2-bbf6-4523-8e99-076556f1e5e3','5f776a31-4be7-44e1-8fc0-478c33792081')
group by driveruuid;



---------------------------------------------------------------------------------------------------------

--Sep 8 2025----
----South africa Vehicle Loan Analysis----
select * FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%'
order by week desc limit 1000;

select NVL(SUM(total_received_fees),0.00) as emi_paid, 
NVL(SUM(total_received_emi),0.00) as opex_paid,
NVL(SUM(surplus_deficit_total_received_total_remitted_for_the_loan),0.00) as surplus_deficit,
sum(total_remitted_for_the_loan_emi_opex_)total_remitted_for_the_loan_emi_opex_
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%';


WITH unified_loanwaterfall AS (
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION)
FROM fivetran_gsheets.sa_historical_loanwaterfall
union all
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION)
FROM fivetran_gsheets.sa_historical_loanwaterfall_2 shl2
  WHERE CAST(week AS DATE) >= '2023-10-02'
union all
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION)
FROM fivetran_gsheets.sa_historical_loanwaterfall_3 shl3
  where week NOT LIKE '%/%' and CAST(week AS DATE) >= '2024-07-01'
 union ALL
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION)
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%')
-- Final filter and sort
SELECT *
FROM unified_loanwaterfall
WHERE drn = '{driver_drn}'   --week >= '2024-01-01' AND
ORDER BY week;




------------------------------------
---Mexico Rental Payment Issue Check---
--Sep 8 2025


with rental_master as (with 
	uber_id_drn_map as (
	select *,
	rank()over(partition by uber_id order by created_date desc, updated_date desc ) as rnk
	from public.bridge_drn_uber_id
	)
select source_file_date, drn, termsuuid, driverfirstname, driverlastname, type, description, sum(amount) as Payment_Amount 
from persistence_uber_api_reports_weekly.rental_payments_transaction 
left join uber_id_drn_map on uber_id = termsuuid 
where source_file_date = '2025-08-25' and type = 'Payment'
group by source_file_date, termsuuid, drn, driverfirstname, driverlastname, type, description
order by drn asc)
select source_file_date,drn,termsuuid,Payment_Amount,'Uber_Rental_Payments' as source,'Operations' as Category
from rental_master
--where termsuuid ilike 'e67dcadd-8823-4d0f-8403-4740a61af311'
order by drn,source_file_date desc;


select * from recon.raw_daily_recon_output limit 10;

select drn, uber_id, week, payments_breakdown, NVL(sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float),0.00) as payins 
from recon.raw_daily_recon_output
where lower(country) = 'mexico' and drn = 'MVMX00158' and week = '2025-08-25'
group by week, uber_id, drn,payments_breakdown
order by WEEK;

select *
from recon.raw_daily_recon_output
where lower(country) = 'mexico' and drn = 'MVMX00158' and week = '2025-08-25'
order by WEEK;


sum(JSON_EXTRACT_PATH_TEXT(payments_breakdown, 'payins')::float) as payins

--New Recon Tables for LatAm
refer below the updated list of views in recon
recon.recon_input__driver_profile -  driver assignments info
recon.recon_input__uber_trips_data - driver trips info
recon.recon_input__uber_rental_payments_data - driver uber rental payments
recon.recon_input__driver_extra_charges - driver extra charges sourced from copilot
recon.recon_input__uber_payments_data - driver uber payments info
recon.recon_input__driver_ineffective_days - driver ineffective days info sourced from copilot
recon.recon_output__mexico_payouts - view for mexico payouts data
recon.recon_output__colombia_payouts - view for columbia payouts data
recon.recon_output__income_statement - view for unloading income statement data
recon.recon_output__colombia_mailchimp_output - view for columbia mailchimp payout
recon.recon_output__weekly_summary - recon weekly aggregated data
cc - @Sophia Uwoziya @vitalii.badion



select * FROM dbt.core__vehicle_driver_assignment
where drn = 'DRN004555';


select * FROM dbt.core__vehicle_driver_assignment
where registration_no = 'EPE329HR';



SELECT *
    FROM tmp_loan_book.stg_fct_contract
    WHERE country='Nigeria'
        AND status='Active' and drn in ('DRN007177','DRN007819','DRN017092','DRN013386','DRN015699','DRN004469');


select * from recon_south_africa.days_adjustments limit 10;

select Min(reconciliation_date)min_date, MAX(reconciliation_date)max_date 
from recon_south_africa.days_adjustments;

select reconciliation_date, sum(days_off)days_off from recon_south_africa.days_adjustments
where reconciliation_date >= '2025-01-01' 
group by reconciliation_date
order by reconciliation_date desc;


recon_south_africa.extra_charges
recon_south_africa.payins
recon_south_africa.amount_adjustments



---------------------------------------

---Sep 9, 2025--

----South africa Vehicle Loan Analysis----
select * FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%'
order by week desc limit 1000

select max(week)max_week FROM fivetran_gsheets.sa_current_loanwaterfall;

select NVL(SUM(total_received_fees),0.00) as emi_paid, 
NVL(SUM(total_received_emi),0.00) as opex_paid,
NVL(SUM(surplus_deficit_total_received_total_remitted_for_the_loan),0.00) as surplus_deficit,
sum(total_remitted_for_the_loan_emi_opex_)total_remitted_for_the_loan_emi_opex_
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%';

---UPDATED BASE QUERY--
SELECT
  CAST(week AS DATE) AS week,
  drn,
  CAST(total_remitted_for_the_loan_emi_opex_ AS double precision) AS total_loan_repaid,
  CAST(total_received_emi AS double precision) AS total_emi_repaid,
  CAST(total_received_fees AS double precision) AS total_fees_repaid,
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision) AS surplus_deficit
FROM fivetran_gsheets.sa_historical_loanwaterfall
UNION all
SELECT
  CAST(week AS DATE) AS week,
  drn,
  CAST(total_remitted_for_the_loan_emi_opex_ AS double precision) AS total_loan_repaid,
  CAST(total_received_emi AS double precision) AS total_emi_repaid,
  CAST(total_received_fees AS double precision) AS total_fees_repaid,
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision) AS surplus_deficit
FROM fivetran_gsheets.sa_historical_loanwaterfall_2 shl2
  WHERE CAST(week AS DATE) >= '2023-10-02'
UNION all
  SELECT
  CAST(week AS DATE) AS week,
  drn,
  CAST(total_remitted_for_the_loan_emi_opex_ AS double precision) AS total_loan_repaid,
  CAST(total_received_emi AS double precision) AS total_emi_repaid,
  CAST(total_received_fees AS double precision) AS total_fees_repaid,
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision) AS surplus_deficit
FROM fivetran_gsheets.sa_historical_loanwaterfall_3 shl3
  where week NOT LIKE '%/%' and CAST(week AS DATE) >= '2024-07-01'
UNION all
  SELECT
  CAST(week AS DATE) AS week,
  drn,
  CAST(total_remitted_for_the_loan_emi_opex_ AS double precision) AS total_loan_repaid,
  CAST(total_received_emi AS double precision) AS total_emi_repaid,
  CAST(total_received_fees AS double precision) AS total_fees_repaid,
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision) AS surplus_deficit
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week NOT LIKE '%/%'
  AND CAST(week AS DATE) >= '2025-03-03'
ORDER BY week limit 200;


--UPDATED DRIVER QUERY---
WITH unified_loanwaterfall AS (
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION),
  CAST(total_received_emi AS double precision),
  CAST(total_received_fees AS double precision),
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision)
FROM fivetran_gsheets.sa_historical_loanwaterfall
union all
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION),
  CAST(total_received_emi AS double precision),
  CAST(total_received_fees AS double precision),
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision)
FROM fivetran_gsheets.sa_historical_loanwaterfall_2 shl2
  WHERE CAST(week AS DATE) >= '2023-10-02'
union all
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION),
  CAST(total_received_emi AS double precision),
  CAST(total_received_fees AS double precision),
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision)
FROM fivetran_gsheets.sa_historical_loanwaterfall_3 shl3
  where week NOT LIKE '%/%' and CAST(week AS DATE) >= '2024-07-01'
 union ALL
SELECT
  CAST(week AS DATE) AS week,
  drn, name, product, city, vehicle_model,
  effective_days,
  CAST(uber_balance AS DOUBLE PRECISION),
  CAST(payins AS DOUBLE PRECISION),
  CAST(payouts AS DOUBLE PRECISION),
  CAST(extra_charges AS DOUBLE PRECISION),
  CAST(total_week_outstanding AS DOUBLE PRECISION),
  CAST(expected_remittance AS DOUBLE PRECISION),
  CAST(total_received AS DOUBLE PRECISION),
  CAST(total_remitted_for_the_loan_emi_opex_ AS DOUBLE PRECISION),
  CAST(total_received_emi AS double precision),
  CAST(total_received_fees AS double precision),
  CAST(surplus_deficit_total_received_total_remitted_for_the_loan AS double precision)
FROM fivetran_gsheets.sa_current_loanwaterfall
WHERE week >= '2025-03-03' AND week NOT LIKE '%/%') -- Final filter and sort
SELECT *
FROM unified_loanwaterfall
WHERE drn = 'MVS12818'   --week >= '2024-01-01' AND
ORDER BY week;




-----------------------------------------
--Sep 10 2025---
--- South Africa Remit Comparison with that on Driver Profile/Copilot.
select * from recon.recon_input__driver_profile
where lower(country) = 'south africa' limit 200;

--Checking Driver Profile records---
select * from recon.recon_input__driver_profile
where lower(country) = 'south africa' 
and week between '2025-08-04' and '2025-09-01';

--Getting Recon records---
select * from recon_south_africa.reconciliation
where week between '2025-08-04' and '2025-09-01';

select * from recon_south_africa.reconciliation
where week = '2025-08-04';

--Getting Driver Profile records---
select 
dp.country, dp.city, week, date, final_license_plate, drn, plan_code, original_remit, 
(cvd.make ||' '||cvd.model_name)as vehicle_model, contract_type, moove_product_code, 
vehicle_assignment_start_date, vehicle_assignment_end_date, first_assignment_date
from recon.recon_input__driver_profile dp
left join
dbt.core__vehicle_domain cvd
on dp.final_license_plate = cvd.registration_no
where lower(dp.country) = 'south africa'
and dp.week between '2025-08-04' and '2025-09-01';


select *
FROM dbt.core__vehicle_driver_assignment limit 5;

select *
FROM dbt.core__vehicle_domain limit 5;





select * from recon.raw_daily_recon_output limit 5;



------------------------------------------
--Sep 11 2025----

reconciliation_proxy_current.drivers_outstanding_report_uberx_lagos

---------------------------------------------
---Sep 11 2025

select * from (
select * from recon_nigeria.reconciliation_alto
union all
select * from recon_nigeria.reconciliation_spresso)
where drn = 'DRN010634'
order by day desc;

select * from partners_data_daily.mv_uber_driver_aggr limit 5;

select * from partners_data_daily.mv_uber_driver_aggr 
where drn = 'DRN010634' and event_date = '2025-08-31';

select * from partners_data_daily.mv_uber_driver_aggr 
where drn = 'DRN010634' and event_date = '2025-08-31';


---Investigating Recon-Uber Net Earnings Gap on Aug 31, 2025 for Nigeria.
with NG_RECON as (
select day,drn, product, NVL(sum(net_earning),0.00)net_earning from (
select * from recon_nigeria.reconciliation_alto
union all
select * from recon_nigeria.reconciliation_spresso)
where day >= '2025-08-25'
group by day,drn, product
order by day desc),
UBER_Data as(
select event_date, drn, org_id, NVL(sum(net_earning),0.00)net_earning from partners_data_daily.mv_uber_driver_aggr 
where event_date >= '2025-08-25'
group by event_date, drn, org_id),
Comparison as(
select nr.day, nr.drn, nr.product, ub.org_id, nr.net_earning as recon_net_earning, 
ub.net_earning as uber_net_earning, (nr.net_earning - ub.net_earning) as earnings_gap
from NG_RECON nr
left join UBER_Data ub
on nr.drn = ub.drn and nr.day = ub.event_date)
select day, drn, product, org_id, recon_net_earning, uber_net_earning, earnings_gap
from Comparison
where earnings_gap <> 0;




----------------------------------------------------------------
------Sep 12, 2025---
--===SA driver plan correction on copilot | Data Extraction====-----



--Getting Driver Profile records---
select * from recon.recon_input__driver_profile
where lower(country) = 'south africa' 
and week between '2025-08-04' and '2025-09-01';

select * from recon_south_africa.reconciliation
where week between '2025-08-04' and '2025-09-01';

select * from recon_south_africa.reconciliation
where week = '2025-09-01' and drn = 'MVS19951';


--Getting Recon records---
select 
dp.country, dp.city, week, date, final_license_plate, drn, plan_code, original_remit, 
(cvd.make ||' '||cvd.model_name)as vehicle_model, contract_type, moove_product_code, 
vehicle_assignment_start_date, vehicle_assignment_end_date, first_assignment_date
from recon.recon_input__driver_profile dp
left join
dbt.core__vehicle_domain cvd
on dp.final_license_plate = cvd.registration_no
where lower(dp.country) = 'south africa'
and dp.week = '2025-09-01';


select * from recon.recon_input__driver_profile 
where week = '2025-09-01' and drn = 'MVS10675';

dbt.core__vehicle_domain


--Unassigned Drivers---
with recon_records as ( 
select distinct drn, city, week, uber_id, uber_name, product, vehicle_type,
COALESCE(sum(remittance)/nullif(SUM(effective_days),0)*6,0) as Weekly_Remit, nvl(sum(trips),0) as uber_trips
from recon_south_africa.reconciliation
where week = '2025-09-01' --and drn = 'MVS10382'
group by drn, uber_id, city, week, uber_name, product, vehicle_type),
-------Most recent vehicle assignment
assignments AS (
select * from ( 
  SELECT
    vda.drn, vda.registration_no, vda.vehicle_assignment_start_date, vda.vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment vda)
  WHERE rn = 1 --and drn = 'MVS10382'
),
uber_vehicle as(
--select distinct drn, week_no, licenseplate, carco 
--from partners_data_weekly.mv_uber_driver_aggr
--where week_no = '2025-09-01' and licenseplate is not null --and drn = 'MVS11042'
---Getting Uber License Plate----
select
distinct driveruuid as uber_driver_id,
licenseplate as uber_registration_no,
source_file_date as event_date,
country,
count(distinct tripuuid) as number_of_trips,
row_number()over(partition by uber_driver_id, event_date order by number_of_trips desc) as rnk
from partners_data_weekly.mv_uber_harmonized_trip_activity
where lower(country) in ('southafrica')  
--and driveruuid = '8e43654b-0812-4cef-90c4-26966405a53e' and source_file_date = '2025-09-01'
group by
driveruuid, licenseplate, source_file_date, country 
),
driver_profile as (
select 
dp.country, dp.city, week, date, final_license_plate, drn, plan_code as copilot_plan_code, original_remit as copilot_original_remit, 
(cvd.make ||' '||cvd.model_name)as copilot_vehicle_model, contract_type, moove_product_code,
vehicle_assignment_start_date, vehicle_assignment_end_date, first_assignment_date
from (select *, 
ROW_NUMBER() OVER (
      PARTITION BY week, drn
      ORDER BY date DESC
    ) AS rk
    from recon.recon_input__driver_profile) dp
left join
dbt.core__vehicle_domain cvd
on dp.final_license_plate = cvd.registration_no
where lower(dp.country) = 'south africa' and dp.rk = 1 --and drn = 'MVS10382'
and dp.week = '2025-09-01')
---Final Select----
select rr.*, a.registration_no, a.vehicle_assignment_start_date, a.vehicle_assignment_end_date,
dp.first_assignment_date, dp.copilot_plan_code, dp.copilot_original_remit, dp.copilot_vehicle_model, 
uv.uber_registration_no as uber_registration_no
from recon_records rr
left join 
assignments a 
on rr.drn = a.drn 
left join uber_vehicle uv
on rr.uber_id = uv.uber_driver_id and rr.week = uv.event_date 
left join driver_profile dp
on rr.drn = dp.drn and rr.week = dp.week;
--where rr.drn = 'MVS10382';



current vehicle model on copilot 	
current plan id on copilot 	
current remit on copilot





select * from 
reconciliation_history.drivers_data_reconciliation_ubergo_lagos_dto48_altos limit 10;


select * from 
reconciliation_proxy_current.drivers_data_reconciliation_ubergo_lagos_dto48_altos limit 10;


---Sep 15 2025 [Cont'd]----
select * from partners_data_weekly.mv_uber_harmonized_trip_activity limit 10;

---Getting Uber License Plate----
,uber_trips_data as (select
distinct driveruuid as uber_driver_id,
licenseplate as uber_registration_no,
source_file_date as event_date,
country,
count(distinct tripuuid) as number_of_trips,
row_number()over(partition by uber_driver_id, event_date order by number_of_trips desc) as rnk
from partners_data_daily.mv_uber_harmonized_trip_activity
where country in ('south africa')
group by
driveruuid, licenseplate, source_file_date, country )

select * from 
partners_data_weekly.mv_uber_harmonized_payments_order limit 10;

---Contains records of All Drivers whether on Bridge Table or not---
select * --distinct drn, week_no, licenseplate, carco 
from partners_data_weekly.mv_uber_driver_aggr 
where week_no = '2025-09-01' and drn = 'MVS11042';


---Contains records of only Drivers on Bridge Table---
select * --distinct drn, week_no, licenseplate, carco 
from partners_data_weekly.vw_uber_driver_aggr 
where week_no = '2025-09-01' and drn = 'MVS11042';


----Getting the Vehicle Assignment Records for the Nigeria 144 drivers missing Contract details----
-------Most recent vehicle assignment
WITH assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
select drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from assignments
where rn = 1 and drn IN ('DRN007177',
'DRN007819',
'DRN017092',
'DRN013386',
'DRN015699',
'DRN004469',
'DRN017692',
'DRN017689',
'DRN017712',
'DRN017763',
'DRN017346',
'DRN000401',
'DRN017886',
'DRN017874',
'DRN015197',
'DRN003211',
'DRN004238',
'DRN019126',
'DRN005064',
'DRN018630',
'DRN018409',
'DRN018759',
'DRN018665',
'DRN018397',
'DRN018566',
'DRN018380',
'DRN018915',
'DRN019335',
'DRN018923',
'DRN019209',
'DRN019376',
'DRN019000',
'DRN018683',
'DRN019191',
'DRN009918',
'DRN010446',
'DRN008825',
'DRN011618',
'DRN012140',
'DRN012615',
'DRN014368',
'DRN014719',
'DRN014706',
'DRN015159',
'DRN015103',
'DRN015291',
'DRN015183',
'DRN015317',
'DRN001144',
'DRN012699',
'DRN013477',
'DRN005696',
'DRN015547',
'DRN003353',
'DRN015835',
'DRN015689',
'DRN015846',
'DRN000635',
'DRN010746',
'DRN004507',
'DRN016123',
'DRN007698',
'DRN013143',
'DRN015834',
'DRN003416',
'DRN016223',
'DRN016908',
'DRN016954',
'DRN015149',
'DRN001689',
'DRN004184',
'DRN016787',
'DRN016883',
'DRN017001',
'DRN016704',
'DRN016301',
'DRN017073',
'DRN016326',
'DRN017098',
'DRN016340',
'DRN017101',
'DRN016856',
'DRN008334',
'DRN017298',
'DRN016886',
'DRN014257',
'DRN017041',
'DRN003715',
'DRN017321',
'DRN017355',
'DRN017326',
'DRN017491',
'DRN013192',
'DRN006184',
'DRN017354',
'DRN004611',
'DRN017126',
'DRN017926',
'DRN017782',
'DRN018495',
'DRN018321',
'DRN018349',
'DRN018073',
'DRN018541',
'DRN008831',
'DRN018063',
'DRN018286',
'DRN018606',
'DRN018643',
'DRN018400',
'DRN019413',
'DRN018857',
'DRN018370',
'DRN018415',
'DRN018393',
'DRN018342',
'DRN018364',
'DRN018466',
'DRN018310',
'DRN018858',
'DRN018939',
'DRN019350',
'DRN018437',
'DRN018184',
'DRN018279',
'DRN018504',
'DRN018898',
'DRN018230',
'DRN018402',
'DRN018632',
'DRN018386',
'DRN018391',
'DRN018631',
'DRN018919',
'DRN019329',
'DRN018937',
'DRN018435',
'DRN018521',
'DRN018131',
'DRN018355',
'DRN019132',
'DRN018678',
'DRN019133',
'DRN019223');



----------------------------------------------------
---Sep 16 2025----
---Checking for drivers whose current product is StopGap---
select distinct drn, product, vehicle_type, max(day) 
from recon_nigeria.reconciliation_alto
group by drn, product, vehicle_type;

--having (max(day)) = '2025-09-15';

----Checking if the remit reversal was applied for Altos--- 
select distinct drn, week, day, product, remittance
from recon_nigeria.reconciliation_alto
where week >= '2025-09-08';

----Checking if the remit reversal was applied for Spresso--- 
select distinct drn, week, day, product, remittance
from recon_nigeria.reconciliation_spresso
where week >= '2025-09-08';

recon_nigeria.reconciliation_spresso

----Checking if the new remit reflects only for Sep 15 for Spresso--- 
select distinct day, week, max(remittance) as remittance
from recon_nigeria.reconciliation_spresso
where week >= '2025-09-08'
group by day, week
order by day desc;


----Checking if the new remit reflects only for Sep 15 for Altos--- 
select distinct day, week, remittance
---max(remittance) as max_remittance, min(remittance) as min_remittance
from recon_nigeria.reconciliation_alto
where week >= '2025-09-08'
order by day desc;


select distinct drn , remittance
from recon_nigeria.reconciliation_alto
where week = '2025-09-15' and remittance = '8400';



------------------------------------------
---Sep 17 2025---

select * from partners_data_daily.vw_uber_driver_aggr
where driveruuid = '3e26ade0-c5aa-48f0-8a54-8298ccd64bc9'
limit 100;


select drn, day, product from ( 
select drn, day, product, MAX(day) as max_day
from ( 
select * from 
(SELECT DISTINCT drn, day, product 
FROM recon_nigeria.reconciliation_spresso  
union ALL
select distinct drn, day, product
from recon_nigeria.reconciliation_alto)
ORDER BY drn asc, "day" desc)
group by drn, day, product)
where day = max_day
order by drn asc, day desc;




select drn, max_day, product from 
(SELECT drn, product, MAX(day) as max_day 
FROM recon_nigeria.reconciliation_spresso 
group by drn, product
union ALL
select drn, product, MAX(day) as max_day
from recon_nigeria.reconciliation_alto
group by drn, product
)
ORDER BY drn asc, max_day desc;



---------------------------------------------------------------------------------
-----Sep 26 2025-----
---India Uber Data Investigation-----


select * from recon_india.daily_reconciliation limit 10;

select week, day, drn, uber_id, trips, net_earning, cash_collected, uber_balance 
from recon_india.daily_reconciliation 
where week = '2025-09-22' and drn = 'MVIN15431';


select source_file_date, driveruuid,  count(transactionuuid )trips, sum(paidtoyou__yourearnings)net_earning,
sum(paidtoyou__tripbalance__payouts__cashcollected)cash_collected, sum(paidtoyou)uber_balance
from partners_data_daily.mv_uber_harmonized_payments_order
where driveruuid = '60c8477e-65a7-4140-934f-a878cdc97d3b' and source_file_date ;


select source_file_date, driveruuid,  transactionuuid, paidtoyou__yourearnings as net_earning,
paidtoyou__tripbalance__payouts__cashcollected as cash_collected, paidtoyou as uber_balance
from partners_data_daily.mv_uber_harmonized_payments_order
where driveruuid = '60c8477e-65a7-4140-934f-a878cdc97d3b' and source_file_date >= '2025-09-22';





-----------------------------------------------------------------
---Sep 29 2025----
select * from recon.raw_daily_recon_output
order by day desc limit 200;




SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,  'Cape Town' as City
FROM reconciliation_history.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Johannesburg' as City
FROM reconciliation_history.drivers_data_reconciliation_johannesburg
UNION ALL
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type, 'Cape Town' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
union all
SELECT week_no, week, drn, "name", product, vehicle_type, trips, supply_hours, net_earnings, cash_collection, uber_balance, toll, effective_days, amount_due, management_fee, extra_charges, incentive, settlement, bank_statement, total_refund, week_outstanding, adjustment, adustment_desc, prev_outstanding, cumm_outstanding, income_payable, income_paid, adjustment_type,'Johannesburg' as City
FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg


-----------------------------------
----Sep 30, 2025----
---Investigating recon columns---

select drn, week, trips, net_earning, cash_collected, uber_balance, remittance, 
moove_balance, amount_due, outstanding, prev_outstanding, cum_outstanding 
from recon_south_africa.reconciliation


select * from recon_south_africa.reconciliation limit 10;

select * from recon_south_africa.reconciliation
where drn = 'MVS21824' and week >= '2025-09-08';

select * from reconciliation_proxy_current.drivers_data_reconciliation_johannesburg
where drn = 'MVS21824' and week >= '2025-09-08';




uber_id_drn_map as (
	select *,
	rank()over(partition by uber_id order by created_date desc, updated_date desc ) as rnk
	from public.bridge_drn_uber_id
	)

	
--------------------------------------
	---Oct 3rd 2025----
	
---Anne's Code
select distinct drn, week, prev_outstanding, previous_closing_balance from
    (select drn, week, prev_outstanding,
            lag(outstanding) OVER (PARTITION by drn ORDER BY week) as previous_closing_balance
     from recon_south_africa.reconciliation) where previous_closing_balance  <> prev_outstanding;

recon_south_africa.reconciliation

--Joseph's code
select distinct drn, week, prev_outstanding, previous_closing_balance from
    (select drn, week, prev_outstanding,
            lag(cum_outstanding) OVER (PARTITION by drn ORDER BY week) as previous_closing_balance
     from recon_south_africa.reconciliation) where (previous_closing_balance  - prev_outstanding) > 2
     order by week desc;

---Correct Code
select distinct drn, week, ROUND(prev_outstanding,0), ROUND(previous_closing_balance,0), (ROUND(prev_outstanding,0) - ROUND(previous_closing_balance,0)) as Gap 
from
    (select drn, week, prev_outstanding,
            lag(cum_outstanding) OVER (PARTITION by drn ORDER BY week) as previous_closing_balance
     from recon_south_africa.reconciliation) 
    where ROUND(prev_outstanding,0) <> ROUND(previous_closing_balance,0);
   
   
---Corrected & Updated Code - Table 1
SELECT 
    t.drn,
    t.week,
    ROUND(t.prev_outstanding, 0) AS prev_outstanding,
    ROUND(t.previous_closing_balance, 0) AS previous_closing_balance,
    ROUND(t.prev_outstanding, 0) - ROUND(t.previous_closing_balance, 0) AS gap
FROM (
    SELECT 
        drn,
        week,
        prev_outstanding,
        LAG(cumm_outstanding) OVER (PARTITION BY drn ORDER BY week ASC) AS previous_closing_balance
    FROM 
    (select * from (
    SELECT week, drn, prev_outstanding, cumm_outstanding FROM reconciliation_history.drivers_data_reconciliation_cape_town 
    union all
    SELECT week, drn, prev_outstanding, cumm_outstanding FROM reconciliation_history.drivers_data_reconciliation_johannesburg 
    UNION all
    SELECT week, drn, prev_outstanding, cumm_outstanding FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
    union all
    SELECT week, drn, prev_outstanding, cumm_outstanding FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
    order by week, drn asc)
) t
WHERE ABS(ROUND(t.prev_outstanding, 0) - ROUND(t.previous_closing_balance, 0)) >1
--and drn = 'MVS10103'
ORDER BY t.drn ASC, t.week ASC;
    

   
---Corrected & Updated Code - Table 2
SELECT 
    t.drn,
    t.week,
    ROUND(t.prev_outstanding, 0) AS prev_outstanding,
    ROUND(t.previous_closing_balance, 0) AS previous_closing_balance,
    ROUND(t.prev_outstanding, 0) - ROUND(t.previous_closing_balance, 0) AS gap
FROM (
    SELECT 
        drn,
        week,
        prev_outstanding,
        LAG(cum_outstanding) OVER (PARTITION BY drn ORDER BY week ASC) AS previous_closing_balance
    FROM recon_south_africa.reconciliation where week >= '2023-10-01'
) t
WHERE ABS(ROUND(t.prev_outstanding, 0) - ROUND(t.previous_closing_balance, 0)) >1
---and drn = 'MVS10103'
ORDER BY t.drn ASC, t.week ASC;




---UPDATED DRIVER BALANCE CHECK SCRIPT
---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon_south_africa.reconciliation
    WHERE week < '2025-09-22' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < '2025-09-22' ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.prev_outstanding, r.cum_outstanding
FROM recon_south_africa.reconciliation r
JOIN (
    select drn, min(day) as min_day
    FROM recon_south_africa.reconciliation
    WHERE week = '2025-09-22' ---get the Monday date of last week.
    --and status = 'PUBLISHED'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-09-22' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.cum_outstanding as previous_last_driver_closing_balance, a.prev_outstanding as this_week_driver_opening_balance,
    case 
        when ABS(ROUND(b.cum_outstanding,0) - ROUND(a.prev_outstanding,0)) <= 1 then 'ok'
        else 'fail'
    end as balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;



--------
---Checks---

select drn, week, prev_outstanding, cum_outstanding from recon_south_africa.reconciliation
where drn = 'MVS10103'
order by drn, week asc;

select distinct week from recon_south_africa.reconciliation
order by week asc;

select * from recon_south_africa.reconciliation
where week in ('2022-12-30', '2022-12-31')
order by week asc;




------------------------------------------------------
-----Oct 06, 2025----

select * from core_dimensions.fact_driver_extra_charges limit 100;
select * from core_dimensions.fact_extra_charge_details limit 100;
select * from core_dimensions.dim_extra_charge_reason limit 100;
select * from core_dimensions.dim_extra_charge_reason_hist limit 100;


SELECT d.driver_name, r.reason, SUM(f.total_amount) as total
FROM core_dimensions.fact_driver_extra_charges f
JOIN core_dimensions.dim_driver d ON f.driver_sk = d.driver_sk
JOIN core_dimensions.dim_extra_charge_reason r ON f.reason_sk = r.reason_sk
WHERE f.created_on >= CURRENT_DATE - 30;

-- Historical accuracy query (point-in-time dimensions)  
SELECT d.drn, r.reason, f.total_amount
FROM core_dimensions.fact_driver_extra_charges f
JOIN core_dimensions.dim_driver_hist d ON f.driver_hist_sk = d.driver_hist_sk
JOIN core_dimensions.dim_extra_charge_reason_hist r ON f.reason_hist_sk = r.reason_history_sk
WHERE f.created_on BETWEEN '2023-01-01' AND '2023-12-31';



select * from recon_south_africa.reconciliation
where week = '2025-09-29' limit 100;


select * from recon_south_africa.reconciliation
where vehicle_type = 'Suzuki_S-Presso_CPT_1885_GT200000KM';

--------------------------------------------------------
---------Oct 06, 2025-----------
--Checking the new SA implementation ---Unassigned with Uber data should not be charged ---vehicle assignments check

-------Most recent vehicle assignment
WITH assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
),
sa_recon as (
select * from recon_south_africa.reconciliation
where week >= '2025-09-22' 
),
merged as (
select week, sr.drn, trips, net_earning, cash_collected, uber_balance, effective_days, remittance,
vehicle_assignment_start_date, vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from sa_recon sr
left join (select * from assignments where rn = 1) a
on sr.drn = a.drn
order by week)
select * from merged
where assignment_status = 'unassigned' and net_earning<>0 and remittance >0;





-------------------------------------------------------------------------
-----October 7 2025----
----South Africa Unassigned But Still Charged on Recon Issue-------
----Segun's Interpretation----
with  vehicle_assign as (
	select   drn,
	        vehicle_assignment_start_date,
	        vehicle_assignment_end_date,
	         ROW_NUMBER() OVER (
      		PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
    from dbt.core__vehicle_driver_assignment
),
sa_recon as (
	select  week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_history.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_history.drivers_data_reconciliation_johannesburg
			UNION ALL
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg
),
merged as (
select week, sr.drn, trips, net_earning, cash_collected, uber_balance, effective_days,remittance,sr.adjustment,adustment_desc,
vehicle_assignment_start_date, vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from sa_recon sr
left join (select * from vehicle_assign where rn = 1) a
on sr.drn = a.drn
order by week)
select *,
      LEAST((vehicle_assignment_end_date::date - week::date), 6) AS Expected_Effective_Days
from merged
where assignment_status = 'unassigned' and net_earning<>0 and remittance >0 and week <> '2025-09-29';




----What I need-----
----South Africa Unassigned But Still Charged on Recon Issue-------
with  vehicle_assign as (
	select   drn,
	        vehicle_assignment_start_date,
	        vehicle_assignment_end_date,
	        case
		        when vehicle_assignment_end_date is null then 'assigned'
		        else 'unassigned'
		        end as assignment_status,
	         ROW_NUMBER() OVER (
      		PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
    from dbt.core__vehicle_driver_assignment
),
sa_recon as (
	select  week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_history.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_history.drivers_data_reconciliation_johannesburg
			UNION ALL
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn, trips, supply_hours, net_earnings as net_earning, cash_collection as cash_collected, uber_balance, effective_days, amount_due as remittance, adjustment, adustment_desc,adjustment_type
			FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg
),
merged as (
select week, sr.drn, trips, net_earning, cash_collected, uber_balance, effective_days,remittance,sr.adjustment,adustment_desc,adjustment_type,
vehicle_assignment_start_date, vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from sa_recon sr
left join (select * from vehicle_assign where rn = 1) a
on sr.drn = a.drn
order by week),
--select *,
--      LEAST((vehicle_assignment_end_date::date - week::date), 6) AS Expected_Effective_Days
--from merged
--where assignment_status = 'unassigned' and remittance >0 and week < '2025-09-29'
unassigned_periods AS (
  SELECT
    drn,
    vehicle_assignment_end_date AS unassigned_start,
    LEAD(vehicle_assignment_start_date) OVER (PARTITION BY drn ORDER BY vehicle_assignment_start_date) AS next_assignment_start
  FROM vehicle_assign
  WHERE assignment_status = 'unassigned'
),
charged_while_unassigned AS (
  SELECT
    sr.drn,
    sr.week,
    sr.remittance,
    sr.effective_days,
    sr.assignment_status,
    u.unassigned_start, u.next_assignment_start,
    sr.adjustment,
    sr.adustment_desc,
    sr.adjustment_type
  FROM merged sr
  LEFT JOIN unassigned_periods u
    ON sr.drn = u.drn
   AND sr.week BETWEEN u.unassigned_start AND COALESCE(u.next_assignment_start, CURRENT_DATE)
  WHERE sr.assignment_status = 'unassigned' and sr.remittance > 0
)
--select * from merged   ----charged_while_unassigned
--where drn = 'MVS10204';
,
adjustment_weeks AS (
  SELECT distinct
    drn,
    TO_CHAR(week, 'YYYY-MM-DD') AS adjustment_week
  FROM charged_while_unassigned
  WHERE adjustment <> 0
),
counts AS (
  SELECT
    drn,
    COUNT(distinct week) AS times_charged_unassigned
  FROM charged_while_unassigned
  GROUP BY drn
)
select * from charged_while_unassigned
where drn = 'MVS10023' order by week;



SELECT
  c.drn, ct.times_charged_unassigned,
  LISTAGG(a.adjustment_week, ', ') WITHIN GROUP (ORDER BY a.adjustment_week) AS adjustment_weeks
FROM charged_while_unassigned c
LEFT JOIN adjustment_weeks a
  ON c.drn = a.drn
LEFT JOIN counts ct
  ON c.drn = ct.drn
GROUP BY c.drn, ct.times_charged_unassigned
ORDER BY ct.times_charged_unassigned DESC;



SELECT
  c.drn,
  COUNT(DISTINCT c.week) AS times_charged_unassigned,
  STRING_AGG(DISTINCT 
    CASE 
      WHEN c.adjustment_amount <> 0 THEN TO_CHAR(c.week, 'YYYY-MM-DD') 
    END, ', ' 
    ORDER BY TO_CHAR(c.week, 'YYYY-MM-DD')
  ) AS adjustment_weeks
  --STRING_AGG(DISTINCT CASE WHEN c.adjustment <> 0 THEN TO_CHAR(c.week, 'YYYY-MM-DD') END, ', ' ORDER BY TO_CHAR(c.week, 'YYYY-MM-DD')) AS adjustment_weeks
FROM charged_while_unassigned c
GROUP BY c.drn
ORDER BY times_charged_unassigned DESC;






WITH unassigned_periods AS (
  SELECT
    id,
    vehicle_assignment_end_date AS unassigned_start,
    LEAD(vehicle_assignment_start_date) OVER (PARTITION BY id ORDER BY vehicle_assignment_start_date) AS next_assignment_start
  FROM assignments
  WHERE assignment_status = 'unassigned'
),

charged_while_unassigned AS (
  SELECT
    r.id,
    r.week,
    r.remit,
    r.adjustment_amount,
    r.adjustment_description,
    r.adjustment_type
  FROM recon r
  LEFT JOIN unassigned_periods u
    ON r.id = u.id
   AND r.week BETWEEN u.unassigned_start AND COALESCE(u.next_assignment_start, CURRENT_DATE)
  WHERE r.remit > 0
)

SELECT
  c.id,
  COUNT(DISTINCT c.week) AS times_charged_unassigned,
  STRING_AGG(DISTINCT CASE WHEN c.adjustment_amount <> 0 THEN CAST(c.week AS STRING) END, ', ') AS adjustment_weeks
FROM charged_while_unassigned c
GROUP BY c.id
ORDER BY times_charged_unassigned DESC;




---------------------------------------------------------------------
select 


---Check 3: Driver opening balance = driver last previous day's closing balance----
with output_previous_weeks as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, MAX(day) as max_day
    FROM recon.daily_recon_output
    WHERE week < '2025-07-28' ---get the Monday date of last week.
    and status = 'PUBLISHED'
    GROUP BY drn
) latest
ON r.drn = latest.drn AND r.day = latest.max_day
WHERE r.week < '2025-07-28' ---get the Monday date of last week.
order by drn
),
output_this_week as (
select r.drn, r.week, r.day, r.driver_opening_balance, r.driver_closing_balance
FROM recon.daily_recon_output r
JOIN (
    select drn, min(day) as min_day
    FROM recon.daily_recon_output
    WHERE week = '2025-07-28' ---get the Monday date of last week.
    and status = 'PUBLISHED'
    GROUP BY drn
) earliest
ON r.drn = earliest.drn AND r.day = earliest.min_day
WHERE r.week = '2025-07-28' ---get the Monday date of last week.
order by drn
),
balance_equality_check as (select a.drn, b.driver_closing_balance as previous_last_driver_closing_balance, a.driver_opening_balance as this_week_driver_opening_balance,
    case 
        when b.driver_closing_balance = a.driver_opening_balance then 'ok'
        else 'fail'
    end as  balance_equality_check
from output_this_week a
join output_previous_weeks b
ON a.drn = b.drn
)
select * from balance_equality_check
where balance_equality_check = 'fail'
order by drn;



select * from reconciliation_proxy_current.drivers_data_reconciliation_cape_town limit 10;

select drn, week, prev_outstanding, cumm_outstanding from (
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where week >= '2025-09-22';



select week, count(drn)drn, sum(amount_due)remittance, sum(effective_days)effective_days,
sum(trips)trips, sum(net_earnings)net_earnings, sum(cash_collection)cash_collection, sum(uber_balance)uber_balance, sum(toll)toll,
sum(extra_charges)extra_charges, 
sum(adjustment)adjustment, sum(bank_statement)bank_statement, sum(income_paid)payouts, sum(income_payable) payables, 
sum(week_outstanding)week_outstanding 
from (
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where week >= '2025-08-01'
group by week
order by week;



SELECT SUM(outstanding)
FROM recon_south_africa.reconciliation
where week = '2025-09-29'
  AND outstanding > 0;



 
 
 
 -------Most recent vehicle assignment
WITH assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS rn
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
select drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
end as assignment_status
from assignments
where rn = 1 and drn IN ('MVS10010',
'MVS10017',
'MVS10023',
'MVS10047',
'MVS10159',
'MVS10186',
'MVS10267',
'MVS10846',
'MVS10946',
'MVS10982',
'MVS11207',
'MVS11270',
'MVS12881',
'MVS13045',
'MVS13125',
'MVS13153',
'MVS13189',
'MVS13208',
'MVS13283',
'MVS13396',
'MVS13818',
'MVS14056',
'MVS14232',
'MVS14782',
'MVS14879',
'MVS15000',
'MVS15013',
'MVS15043',
'MVS15351',
'MVS16071',
'MVS17637',
'MVS17867',
'MVS17949',
'MVS18031',
'MVS18283',
'MVS19032',
'MVS19247',
'MVS19282',
'MVS19350',
'MVS19363',
'MVS19574',
'MVS19593',
'MVS20403',
'MVS20629',
'MVS20779',
'MVS20875',
'MVS21070',
'MVS21246',
'MVS21282',
'MVS21500',
'MVS21510',
'MVS21606',
'MVS21821',
'MVS21854',
'MVS22061',
'MVS22089',
'MVS22165',
'MVS22340',
'MVS22678',
'MVS22795',
'MVS22811',
'MVS22813',
'MVS22814',
'MVS22816');


---------------------------------
---Oct 8 2025-
---SA Urgent ANalysis

select *  FROM persistence_uber_api_reports_daily.uber_driver_aggr limit 10;

-- New Vehicle Assignment & Status From CORE 
WITH assignments AS (
  SELECT drn, 
         registration_no, 
         vehicle_assignment_start_date AS effective_start_date, 
         vehicle_assignment_end_date AS effective_end_date, 
         vehicle_updated_by
  FROM dbt.core__vehicle_driver_assignment
  where vehicle_assignment_end_date <= '2025-10-05' or vehicle_assignment_end_date is null
), 
vehicleAssign AS (
    SELECT ROW_NUMBER() OVER (PARTITION BY drn ORDER BY effective_start_date DESC) AS row_num,
           *
    FROM assignments
),
sa_recon as (
select distinct drn, max(week) as max_recon_appearance_date from (
	select  week, drn FROM reconciliation_history.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn FROM reconciliation_history.drivers_data_reconciliation_johannesburg
			UNION ALL
			SELECT week, drn FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT week, drn FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
	group by drn
)
SELECT
--  v.country,
va.drn,  
v.city,
va.registration_no AS "Plate Number",
CAST(effective_start_date AS TEXT) AS effective_start_date,
CAST(effective_end_date AS TEXT) AS effective_end_date,
email,
phone_number,
last_work_date, max_recon_appearance_date,
v.carco_name AS car_co,
vp.partner_product_name AS vehicle_plan,
--  v.vin AS vin_no,
--  dd.first_name AS "Driver Name",
v.vehicle_status,
vehicle_updated_by AS "Who Assigned the Vehicle"
FROM
  vehicleAssign va
LEFT JOIN dbt.core__driver_domain dd ON dd.drn = va.drn
LEFT JOIN dbt.core__vehicle_domain v ON va.registration_no = v.registration_no
left join sa_recon sr on va.drn = sr.drn
LEFT JOIN dbt.core__vehicle_product_plan_assignment vp ON va.registration_no = vp.registration_no
LEFT JOIN (
  SELECT drn, 
         MAX(event_date) AS last_work_date 
  FROM persistence_uber_api_reports_daily.uber_driver_aggr 
  where perf_trips >0 and event_date <= '2025-10-05'
  GROUP BY drn
) a ON va.drn = a.drn
WHERE LOWER(v.country) IN ('south africa') 
  AND effective_start_date IS NOT null
  and va.drn in (
  'MVS17730',
'MVS13002',
'MVS18520',
'MVS19434',
'MVS20542',
'MVS20979',
'MVS21419',
'MVS21809',
'MVS22498',
'MVS20340',
'MVS20636',
'MVS21897',
'MVS22496',
'MVS21730',
'MVS14564',
'MVS15197',
'MVS17395',
'MVS18822',
'MVS19742',
'MVS20496',
'MVS20930',
'MVS20994',
'MVS22390',
'MVS22440',
'MVS15981',
'MVS10968',
'MVS11476',
'MVS17132',
'MVS17458',
'MVS17964',
'MVS18022',
'MVS18550',
'MVS18611',
'MVS19526',
'MVS19883',
'MVS19986',
'MVS20564',
'MVS21300',
'MVS21307',
'MVS21748',
'MVS21940',
'MVS22048',
'MVS22056',
'MVS22068',
'MVS22123',
'MVS22164',
'MVS22224',
'MVS22254',
'MVS22259',
'MVS22298',
'MVS22310',
'MVS22408',
'MVS22435',
'MVS22707',
'MVS21293',
'MVS20252',
'MVS14520',
'MVS15832',
'MVS15917',
'MVS20085',
'MVS20812',
'MVS20931',
'MVS21171',
'MVS21198',
'MVS21390',
'MVS21465',
'MVS21798',
'MVS21872',
'MVS22120',
'MVS22156',
'MVS22228',
'MVS22352',
'MVS22365',
'MVS22476',
'MVS22484',
'MVS22522',
'MVS22584',
'MVS22681',
'MVS22074',
'MVS15405',
'MVS21847',
'MVS22699',
'MVS11116',
'MVS16613',
'MVS16992',
'MVS17358',
'MVS17518',
'MVS17593',
'MVS17989',
'MVS18310',
'MVS18695',
'MVS18789',
'MVS20508',
'MVS20685',
'MVS20711',
'MVS20718',
'MVS20856',
'MVS21306',
'MVS21626',
'MVS21790',
'MVS21939',
'MVS21974',
'MVS21989',
'MVS22034',
'MVS22065',
'MVS22162',
'MVS22183',
'MVS22431',
'MVS22472',
'MVS22547',
'MVS22651',
'MVS22099',
'MVS21528',
'MVS22328',
'MVS21214',
'MVS10585',
'MVS10698',
'MVS11630',
'MVS14346',
'MVS17516',
'MVS19445',
'MVS19713',
'MVS20433',
'MVS20715',
'MVS21013',
'MVS21073',
'MVS22274',
'MVS22387',
'MVS22581',
'MVS18350',
'MVS10814',
'MVS11431',
'MVS16109',
'MVS16167',
'MVS16398',
'MVS17170',
'MVS17328',
'MVS17565',
'MVS17695',
'MVS18615',
'MVS19462',
'MVS19810',
'MVS20202',
'MVS20817',
'MVS21295',
'MVS21303',
'MVS21387',
'MVS21621',
'MVS21653',
'MVS21689',
'MVS21972',
'MVS21976',
'MVS21982',
'MVS22172',
'MVS22234',
'MVS22295',
'MVS22397',
'MVS22443',
'MVS22475',
'MVS22564',
'MVS22675',
'MVS16865',
'MVS22523'  )
ORDER BY effective_start_date DESC, 
         effective_end_date desc;
         
         

        
 ----------------------------------------------
 --10-10-2025
 select * from recon_south_africa.reconciliation where uber_id is null limit 100;

select * from recon_south_africa.reconciliation where uber_id is null;


---South Africa Analysis----Unassigned Drivers Wrongfully Charged----
select * from recon_south_africa.reconciliation limit 100;

with sa_Recon as (
select * from recon_south_africa.reconciliation where week >= '2025-08-04'
),
assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS assignment_rank,
    case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
	end as assignment_status
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
),
combination as (
SELECT
  sr.city, sr.drn,
  sr.week,
  a.vehicle_assignment_start_date,
  a.vehicle_assignment_end_date,
  a.assignment_status,
  a.assignment_rank,
  sr.uber_id,
  sr.is_assigned, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance, toll, 
  sr.remittance, extra_charges, adjustment_amount, bank_statement, payouts, moove_balance, 
  sr.outstanding, prev_outstanding, cum_outstanding
FROM sa_recon sr
LEFT JOIN assignments a
  ON sr.drn = a.drn
  AND sr.week >= a.vehicle_assignment_start_date
  AND (sr.week <= a.vehicle_assignment_end_date OR a.vehicle_assignment_end_date IS NULL)
ORDER BY sr.drn, sr.week)
--select * from combination;
--Collections & Outstanding--
select week, COUNT(distinct drn) as unique_drn_count,
--COUNT(DISTINCT CASE WHEN net_earning IS NOT NULL AND net_earning <>0 THEN drn END) AS with_earnings,
--COUNT(DISTINCT CASE WHEN net_earning is null or net_earning = 0 THEN drn END) AS without_earnings,
--COUNT(DISTINCT CASE WHEN trips IS NOT NULL AND trips <>0 THEN drn END) AS with_trips,
--COUNT(DISTINCT CASE WHEN trips is null or trips = 0 THEN drn END) AS without_trips,
--COUNT(DISTINCT CASE WHEN supply_hours IS NOT NULL AND supply_hours <>0 THEN drn END) AS with_supply_hours,
--COUNT(DISTINCT CASE WHEN supply_hours is null or supply_hours = 0 THEN drn END) AS without_supply_hours
SUM( CASE WHEN outstanding IS NOT NULL AND outstanding <0 THEN drn END) AS outstanding_credit,
SUM( CASE WHEN outstanding is null or outstanding = 0 THEN drn END) AS zero_outstanding,
SUM( CASE WHEN outstanding is null or outstanding > 0 THEN drn END) AS gtzero_outstanding,
COUNT(DISTINCT CASE WHEN adjustment_amount IS NOT NULL AND adjustment_amount <>0 THEN drn END) AS with_adjustment_amount,
COUNT(DISTINCT CASE WHEN adjustment_amount is null or adjustment_amount = 0 THEN drn END) AS without_adjustment_amount,
COUNT(DISTINCT CASE WHEN payouts IS NOT NULL AND payouts <>0 THEN drn END) AS with_payouts,
COUNT(DISTINCT CASE WHEN payouts is null or payouts = 0 THEN drn END) AS without_payouts
from combination
GROUP BY week
ORDER BY week;
---Basic Checks---
--select week, COUNT(distinct drn) as unique_drn_count,
----COUNT(DISTINCT CASE WHEN net_earning IS NOT NULL AND net_earning <>0 THEN drn END) AS with_earnings,
----COUNT(DISTINCT CASE WHEN net_earning is null or net_earning = 0 THEN drn END) AS without_earnings,
----COUNT(DISTINCT CASE WHEN trips IS NOT NULL AND trips <>0 THEN drn END) AS with_trips,
----COUNT(DISTINCT CASE WHEN trips is null or trips = 0 THEN drn END) AS without_trips,
----COUNT(DISTINCT CASE WHEN supply_hours IS NOT NULL AND supply_hours <>0 THEN drn END) AS with_supply_hours,
----COUNT(DISTINCT CASE WHEN supply_hours is null or supply_hours = 0 THEN drn END) AS without_supply_hours
--COUNT(DISTINCT CASE WHEN extra_charges IS NOT NULL AND extra_charges <>0 THEN drn END) AS with_extra_charges,
--COUNT(DISTINCT CASE WHEN extra_charges is null or extra_charges = 0 THEN drn END) AS without_extra_charges,
--COUNT(DISTINCT CASE WHEN adjustment_amount IS NOT NULL AND adjustment_amount <>0 THEN drn END) AS with_adjustment_amount,
--COUNT(DISTINCT CASE WHEN adjustment_amount is null or adjustment_amount = 0 THEN drn END) AS without_adjustment_amount,
--COUNT(DISTINCT CASE WHEN payouts IS NOT NULL AND payouts <>0 THEN drn END) AS with_payouts,
--COUNT(DISTINCT CASE WHEN payouts is null or payouts = 0 THEN drn END) AS without_payouts
--from combination
--GROUP BY week
--ORDER BY week;
---Assignment Status By Week---
--SELECT
--  week,
--  COUNT(distinct drn) as unique_drn_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status is null THEN drn END) AS null_count
--FROM combination
--GROUP BY week
--ORDER BY week;
---Overall Assignment Status By Week | Remit Charged or Not
--SELECT
--  week,
--  COUNT(DISTINCT drn) AS unique_drn_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL THEN drn END) AS null_count,
--  COUNT(DISTINCT CASE WHEN remittance > 0 THEN drn END) AS charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN remittance <= 0 THEN drn END) AS non_charged_remittance_count
--FROM combination
--GROUP BY week
--ORDER BY week;
---Assignment Status & Remit Status---
--SELECT
--  week,
--   ASSIGNED
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance > 0 THEN drn END) AS assigned_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance <= 0 THEN drn END) AS assigned_non_charged_remittance_count,
--   UNASSIGNED
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN drn END) AS unassigned_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN drn END) AS unassigned_non_charged_remittance_count,
--   NULL / UNKNOWN STATUS
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL THEN drn END) AS null_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance > 0 THEN drn END) AS null_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance <= 0 THEN drn END) AS null_non_charged_remittance_count
--FROM combination
--GROUP BY week
--ORDER BY week;















select * FROM dbt.core__vehicle_driver_assignment
where drn = 'MVS19087';

---OVERALL---
select week, count(drn)drn, sum(amount_due)remittance, sum(effective_days)effective_days,
sum(trips)trips, sum(supply_hours)supply_hours, sum(net_earnings)net_earnings, sum(cash_collection)cash_collection, sum(uber_balance)uber_balance, sum(toll)toll,
sum(extra_charges)extra_charges, 
sum(adjustment)adjustment, sum(bank_statement)bank_statement, sum(income_paid)payouts, sum(income_payable) payables, 
sum(week_outstanding)week_outstanding 
from (
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where week >= '2025-08-01'
group by week
order by week;


---COLLECTIONS---
select week, count(drn)drn, sum(amount_due)remittance, sum(effective_days)effective_days,
sum(trips)trips, sum(supply_hours)supply_hours, sum(net_earnings)net_earnings, sum(cash_collection)cash_collection, sum(uber_balance)uber_balance, sum(toll)toll,
sum(extra_charges)extra_charges, 
sum(adjustment)adjustment, sum(bank_statement)bank_statement, sum(income_paid)payouts, sum(income_payable) payables, 
sum(week_outstanding)week_outstanding 
from (
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_cape_town
			union all
			SELECT * FROM reconciliation_proxy_current.drivers_data_reconciliation_johannesburg)
where week >= '2025-08-01'
group by week
order by week;





---Updated SA Analysis Version----
----Assigned and Unassigned Segmentation Analysis----
with sa_Recon as (
select * from recon_south_africa.reconciliation where week >= '2025-08-04'
),
assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS assignment_rank,
    case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
	end as assignment_status
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
, week_assignments AS (
  SELECT 
    sr.city,
    sr.drn, sr.week,
    a.vehicle_assignment_start_date,
    a.vehicle_assignment_end_date,
    a.assignment_status,
  a.assignment_rank,
  sr.uber_id,
  sr.is_assigned, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance, toll, 
  sr.remittance, extra_charges, adjustment_amount, adjustment_type, adjustment_description, bank_statement, payouts, moove_balance, 
  sr.outstanding, prev_outstanding, cum_outstanding,
    --a.vehicle_plate,
    -- Rank assignments so the most recent before the week is chosen if none overlap
    ROW_NUMBER() OVER (
      PARTITION BY sr.drn, sr.week
      ORDER BY
        CASE 
          WHEN a.vehicle_assignment_start_date <= (sr.week + INTERVAL '6 day')
           AND (a.vehicle_assignment_end_date IS NULL OR a.vehicle_assignment_end_date >= sr.week)
          THEN 0 ELSE 1 END,  -- 0 means it overlaps the week
        a.vehicle_assignment_end_date DESC NULLS LAST
--      ORDER BY 
--        CASE 
--          WHEN sr.week BETWEEN a.vehicle_assignment_start_date AND COALESCE(a.vehicle_assignment_end_date, sr.week)
--          THEN 0 ELSE 1 END,
--        ABS(EXTRACT(EPOCH FROM (sr.week - a.vehicle_assignment_end_date))) NULLS LAST
    ) AS rk
  FROM sa_recon sr
  LEFT JOIN assignments a
    ON sr.drn = a.drn
)
--SELECT 
--  *
--FROM week_assignments
--WHERE rk = 1 ---and drn = 'MVS10010'
--ORDER BY drn, week;
---Basic Checks---
select week, COUNT(distinct drn) as unique_drn_count,
COUNT(DISTINCT CASE WHEN net_earning IS NOT NULL AND net_earning <>0 THEN drn END) AS with_earnings,
COUNT(DISTINCT CASE WHEN net_earning is null or net_earning = 0 THEN drn END) AS without_earnings,
COUNT(DISTINCT CASE WHEN trips IS NOT NULL AND trips <>0 THEN drn END) AS with_trips,
COUNT(DISTINCT CASE WHEN trips is null or trips = 0 THEN drn END) AS without_trips,
COUNT(DISTINCT CASE WHEN supply_hours IS NOT NULL AND supply_hours <>0 THEN drn END) AS with_supply_hours,
COUNT(DISTINCT CASE WHEN supply_hours is null or supply_hours = 0 THEN drn END) AS without_supply_hours,
COUNT(DISTINCT CASE WHEN extra_charges IS NOT NULL AND extra_charges <>0 THEN drn END) AS with_extra_charges,
COUNT(DISTINCT CASE WHEN extra_charges is null or extra_charges = 0 THEN drn END) AS without_extra_charges,
COUNT(DISTINCT CASE WHEN adjustment_amount IS NOT NULL AND adjustment_amount <>0 THEN drn END) AS with_adjustment_amount,
COUNT(DISTINCT CASE WHEN adjustment_amount is null or adjustment_amount = 0 THEN drn END) AS without_adjustment_amount,
COUNT(DISTINCT CASE WHEN payouts IS NOT NULL AND payouts <>0 THEN drn END) AS with_payouts,
COUNT(DISTINCT CASE WHEN payouts is null or payouts = 0 THEN drn END) AS without_payouts
from week_assignments
GROUP BY week
ORDER BY week;
---Assignment Status By Week---
--SELECT
--  week,
--  COUNT(distinct drn) as unique_drn_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status is null THEN drn END) AS null_count
--FROM week_assignments
--WHERE rk = 1
--GROUP BY week
--ORDER BY week;
---Overall Assignment Status By Week | Remit Charged or Not
--SELECT
--  week,
--  COUNT(DISTINCT drn) AS unique_drn_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL THEN drn END) AS null_count,
--  COUNT(DISTINCT CASE WHEN remittance > 0 THEN drn END) AS charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN remittance <= 0 THEN drn END) AS non_charged_remittance_count
--FROM week_assignments
--WHERE rk = 1
--GROUP BY week
--ORDER BY week;
---Assignment Status & Remit Status---
--SELECT
--  week,
--   --ASSIGNED
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance > 0 THEN drn END) AS assigned_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance <= 0 THEN drn END) AS assigned_non_charged_remittance_count,
--   --UNASSIGNED
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN drn END) AS unassigned_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN drn END) AS unassigned_non_charged_remittance_count,
--   --NULL / UNKNOWN STATUS
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL THEN drn END) AS null_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance > 0 THEN drn END) AS null_charged_remittance_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance <= 0 THEN drn END) AS null_non_charged_remittance_count
--FROM week_assignments
--WHERE rk = 1
--GROUP BY week
--ORDER BY week;




---------------------------------------------
---Oct 13 2025---

---Updated SA Analysis Version----
----Assigned and Unassigned Segmentation Analysis----
with sa_Recon as (
select * from recon_south_africa.reconciliation where week >= '2025-08-04'
),
assignments AS (
  SELECT
    drn, vehicle_assignment_start_date,vehicle_assignment_end_date,
    ROW_NUMBER() OVER (
      PARTITION BY drn
      ORDER BY vehicle_assignment_start_date DESC
    ) AS assignment_rank,
    case
	when vehicle_assignment_end_date is null then 'assigned'
	else 'unassigned'
	end as assignment_status
  FROM dbt.core__vehicle_driver_assignment
  --WHERE LOWER(country) = 'nigeria' and rn = 1
)
, week_assignments AS (
  SELECT 
    sr.city,
    sr.drn, sr.week,
    a.vehicle_assignment_start_date,
    a.vehicle_assignment_end_date,
    a.assignment_status,
  a.assignment_rank,
  sr.uber_id,
  sr.is_assigned, days_off, effective_days, trips, supply_hours, net_earning, cash_collected,uber_balance, toll, 
  sr.remittance, extra_charges, adjustment_amount, adjustment_type, adjustment_description, bank_statement, payouts, moove_balance, 
  sr.outstanding, prev_outstanding, cum_outstanding,
    --a.vehicle_plate,
    -- Rank assignments so the most recent before the week is chosen if none overlap
    ROW_NUMBER() OVER (
      PARTITION BY sr.drn, sr.week
      ORDER BY
        CASE 
          WHEN a.vehicle_assignment_start_date <= (sr.week + INTERVAL '6 day')
           AND (a.vehicle_assignment_end_date IS NULL OR a.vehicle_assignment_end_date >= sr.week)
          THEN 0 ELSE 1 END,  -- 0 means it overlaps the week
        a.vehicle_assignment_end_date DESC NULLS LAST
    ) AS rk
  FROM sa_recon sr
  LEFT JOIN assignments a
    ON sr.drn = a.drn
)
---Assignment Status & Remit Status---
--SELECT
--  week,
--   ASSIGNED COUNT & SUM
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' THEN drn END) AS assigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance > 0 THEN drn END) AS assigned_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'assigned' AND remittance > 0 THEN remittance END) AS assigned_charged_remittance_sum,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'assigned' AND remittance <= 0 THEN drn END) AS assigned_non_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'assigned' AND remittance <= 0 THEN remittance END) AS assigned_non_charged_remittance_sum,
--   UNASSIGNED COUNT & SUM
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN drn END) AS unassigned_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN remittance END) AS unassigned_charged_remittance_sum,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN drn END) AS unassigned_non_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN remittance END) AS unassigned_non_charged_remittance_sum,
--   NULL / UNKNOWN STATUS
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL THEN drn END) AS null_count,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance > 0 THEN drn END) AS null_charged_remittance_count,
--  SUM( CASE WHEN assignment_status IS NULL AND remittance > 0 THEN remittance END) AS null_charged_remittance_sum,
--  COUNT(DISTINCT CASE WHEN assignment_status IS NULL AND remittance <= 0 THEN drn END) AS null_non_charged_remittance_count,
--  SUM( CASE WHEN assignment_status IS NULL AND remittance <= 0 THEN remittance END) AS null_non_charged_remittance_sum
--FROM week_assignments
--WHERE rk = 1
--GROUP BY week
--ORDER BY week;
---can we quantify how much money we’ve paid on drivers who are not with us anymore? it’s a great loophole for drivers
--These are unassigned drivers charged a remit while unassigned and had a positive Uber balance | Also received a payout.
--Get unassigned, charged a remit, has positive uber balance
--Get unassigned, charged a remit, has positive uber balance received payouts
--SELECT
--  week,
--   --UNASSIGNED COUNT & SUM
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN drn END) AS unassigned_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN remittance END) AS unassigned_charged_remittance_sum,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN drn END) AS unassigned_non_charged_remittance_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN remittance END) AS unassigned_non_charged_remittance_sum,
--  ----Uber Balance---
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 THEN drn END) AS unassigned_positive_uberbalance_drn_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 THEN uber_balance END) AS unassigned_positive_uberbalance_sum,
--  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 and payouts>0 THEN drn END) AS unassigned_positive_uberbalance_with_payouts_drn_count,
--  SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 and payouts>0 THEN uber_balance END) AS unassigned_positive_uberbalance_with_payouts_sum
--FROM week_assignments
--WHERE rk = 1
--GROUP BY week
--ORDER BY week;
---Summary---
select 
   --UNASSIGNED COUNT & SUM
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN drn END) AS unassigned_charged_remittance_count,
  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance > 0 THEN remittance END) AS unassigned_charged_remittance_sum,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN drn END) AS unassigned_non_charged_remittance_count,
  SUM( CASE WHEN assignment_status = 'unassigned' AND remittance <= 0 THEN remittance END) AS unassigned_non_charged_remittance_sum,
  ----Positive Uber Balance---
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 THEN drn END) AS unassigned_positive_uberbalance_drn_count,
  SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 THEN uber_balance END) AS unassigned_positive_uberbalance_sum,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 and payouts>0 THEN drn END) AS unassigned_positive_uberbalance_with_payouts_drn_count,
  SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance > 0 and payouts>0 THEN uber_balance END) AS unassigned_positive_uberbalance_with_payouts_sum,
  ----Negative Uber Balance---
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' THEN drn END) AS unassigned_count,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance < 0 THEN drn END) AS unassigned_negative_uberbalance_drn_count,
  NVL(SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance < 0 THEN uber_balance END),0.0) AS unassigned_negative_uberbalance_sum,
  COUNT(DISTINCT CASE WHEN assignment_status = 'unassigned' AND uber_balance < 0 and payouts>0 THEN drn END) AS unassigned_negative_uberbalance_with_payouts_drn_count,
  NVL(SUM( CASE WHEN assignment_status = 'unassigned' AND uber_balance < 0 and payouts>0 THEN uber_balance END),0.0) AS unassigned_negative_uberbalance_with_payouts_sum
FROM week_assignments
WHERE rk = 1 and week < '2025-09-29';



---can we quantify how much money we’ve paid on drivers who are not with us anymore? it’s a great loophole for drivers
--These are unassigned drivers charged a remit while unassigned and had a positive Uber balance | Also received a payout.
--Get unassigned, charged a remit, has positive uber balance
--Get unassigned, charged a remit, has positive uber balance received payouts





